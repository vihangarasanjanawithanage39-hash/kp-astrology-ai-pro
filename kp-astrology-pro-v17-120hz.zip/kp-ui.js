/* ==========================================================================
   KP ASTROLOGY AI PRO v10 — MIDNIGHT CYAN-BLACK UI ENGINE + EXTRA KP TOOLS
   ========================================================================== */
(function () {
  if (!window.KPB || /[?&]plain\b/.test(location.search)) return;
  with (window.KPB) {
    var SI = /[\u0D80-\u0DFF]/.test((typeof NAV !== 'undefined' && NAV[0] && NAV[0][0]) || '');
    var T = function (a, b) { return SI ? a : b; };
    var E = function (i) { return document.getElementById(i); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
    var ok = function (f) { try { return f(); } catch (e) { if (window.console) console.warn('kp-ui', e); } };

    // Default to Midnight-Black & Light-Blue Dark Theme (kpt_v10)
    try {
      if (!localStorage.getItem('kpt_v10')) {
        document.documentElement.dataset.t = 'dark';
        localStorage.setItem('kpt_v10', 'dark');
      }
    } catch (e) {}

    function syncThemeIcon() {
      var btn = E('th');
      if (!btn) return;
      btn.textContent = document.documentElement.dataset.t === 'light' ? '🌙' : '☀️';
      btn.setAttribute('aria-label', T('තේමාව මාරු කරන්න', 'Toggle theme'));
    }
    syncThemeIcon();
    if (E('th')) E('th').addEventListener('click', function () { setTimeout(syncThemeIcon, 10); });

    if (SI) { document.body.classList.add('si'); var flk = document.createElement('link'); flk.rel = 'stylesheet'; flk.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Sinhala:wght@400;600;700&display=swap'; document.head.appendChild(flk); }
    if (E('lgb')) E('lgb').textContent = SI ? 'සිං/EN' : 'EN/සිං';
    var ayEl = E('aysub');
    if (ayEl) ayEl.textContent = T('KP පද්ධතිය · Offline', 'KP Stellar System · Offline');

    var SGN = SI
      ? ['මේෂ','වෘෂභ','මිථුන','කටක','සිංහ','කන්‍යා','තුලා','වෘශ්චික','ධනු','මකර','කුම්භ','මීන']
      : ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
    var NKN = SI
      ? ['අස්විද','බරණ','කැති','රෙහෙණ','මුවසිරස','අද','පුනාවස','පුස','ඇසළ','මා','පුවපල්','උත්තරපල්','හත','සිත','සා','විසා','අනුර','දෙට','මුල','පුරාසල','උතුරුසල','සුවණ','දෙනට','සියාවස','පුව පුටුප','උතුරු පුටුප','රේවතී']
      : ['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','P.Phalguni','U.Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','P.Ashadha','U.Ashadha','Shravana','Dhanishta','Shatabhisha','P.Bhadrapada','U.Bhadrapada','Revati'];
    var PLN = SI
      ? ['කේතු','සිකුරු','රවි','චන්ද්‍ර','කුජ','රාහු','ගුරු','ශනි','බුධ']
      : ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
    var DAY_LORD = SI
      ? ['රවි','චන්ද්‍ර','කුජ','බුධ','ගුරු','සිකුරු','ශනි']
      : ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
    var HORA_SEQ = SI
      ? ['රවි','සිකුරු','බුධ','චන්ද්‍ර','ශනි','ගුරු','කුජ']
      : ['Sun','Venus','Mercury','Moon','Saturn','Jupiter','Mars'];
    var DAY_TO_HORA = [0, 3, 6, 2, 5, 1, 4];
    // Authentic KP Gems, Colors & Metals (Strictly for 1st & 11th CSL avoiding 6, 8, 12)
    var KP_GEMS = {
      Su: { si:'රවි', en:'Sun', gemSi:'Ruby (මාණික්‍ය)', gemEn:'Ruby', colSi:'තැඹිලි හෝ තද රතු', colEn:'Orange or Deep Red', metSi:'Gold & Copper (රන් සහ තඹ)', metEn:'Gold & Copper' },
      Mo: { si:'චන්ද්‍ර', en:'Moon', gemSi:'Pearl (මුතු)', gemEn:'Pearl', colSi:'සුදු, රිදී පාට', colEn:'White, Silvery', metSi:'Silver (රිදී)', metEn:'Silver' },
      Ma: { si:'කුජ', en:'Mars', gemSi:'Coral (පබළු)', gemEn:'Coral', colSi:'තද රතු', colEn:'Deep Red', metSi:'Copper / Iron (තඹ / යකඩ)', metEn:'Copper / Iron' },
      Me: { si:'බුධ', en:'Mercury', gemSi:'Emerald (පච්ච / මරකත)', gemEn:'Emerald', colSi:'අළු මිශ්‍ර කොළ පාට', colEn:'Greyish Green', metSi:'Quick-Silver (රසදිය)', metEn:'Quick-Silver' },
      Ju: { si:'ගුරු', en:'Jupiter', gemSi:'Topaz (පුෂ්පරාග)', gemEn:'Topaz', colSi:'දම්, වයලට්, නිල්, සුදු', colEn:'Purple, Violet, Blue, White', metSi:'Tin (ටින්)', metEn:'Tin' },
      Ve: { si:'සිකුරු', en:'Venus', gemSi:'Diamond (දියමන්ති)', gemEn:'Diamond', colSi:'කහ, ලා නිල්, සුදුත් නෙවෙයි කළුත් නෙවෙයි', colEn:'Yellow, Light Blue, Neutral Off-White', metSi:'Silver & Copper (රිදී සහ තඹ)', metEn:'Silver & Copper' },
      Sa: { si:'ශනි', en:'Saturn', gemSi:'Sapphire (නීල)', gemEn:'Sapphire', colSi:'දුඹුරු, ඉන්ඩිගෝ, කළු', colEn:'Brown, Indigo, Black', metSi:'Lead (ඊයම්)', metEn:'Lead' },
      Ra: { si:'රාහු', en:'Rahu', gemSi:'Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)', gemEn:'Agate or Turquoise', colSi:'මිශ්‍ර පාට', colEn:'Mixed Colors', metSi:'Alloy (මිශ්‍ර ලෝහ)', metEn:'Alloy' },
      Ke: { si:'කේතු', en:'Ketu', gemSi:'Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)', gemEn:'Agate or Turquoise', colSi:'මිශ්‍ර පාට', colEn:'Mixed Colors', metSi:'Alloy (මිශ්‍ර ලෝහ)', metEn:'Alloy' }
    };
    var WD = SI ? ['ඉ','ස','අ','බ','බ්‍ර','සි','සෙ'] : ['S','M','T','W','T','F','S'];
    var PC = { Su:'#f59e0b',Mo:'#94a3b8',Ma:'#ef4444',Me:'#10b981',Ju:'#eab308',Ve:'#ec4899',Sa:'#6366f1',Ra:'#a855f7',Ke:'#b45309',Ur:'#06b6d4',Ne:'#06b6d4',Pl:'#06b6d4' };
    var S = { c: null, day: null, clockTimer: null, installPrompt: null };

    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault(); S.installPrompt = e;
      var btn = E('kp-install-btn'); if (btn) btn.classList.add('show');
    });
    window.addEventListener('appinstalled', function () {
      S.installPrompt = null;
      var btn = E('kp-install-btn'); if (btn) btn.classList.remove('show');
      ok(function () { mnToast(T('✓ KP Astrology AI Pro ඇප් එක ස්ථාපනය විය!', '✓ KP Astrology AI Pro installed!')); });
    });

    function today() {
      var n = new Date();
      return n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0');
    }
    function dms(deg) {
      var d = Math.floor(deg), mF = (deg - d) * 60, m = Math.floor(mF), s = Math.floor((mF - m) * 60);
      return d + '°' + String(m).padStart(2, '0') + "'" + String(s).padStart(2, '0') + '"';
    }
    function livePanchanga() {
      var now = new Date(), dow = now.getDay(), hr = now.getHours(), mn = now.getMinutes();
      var effDow = hr < 6 ? (dow + 6) % 7 : dow;
      var hrsSinceSunrise = (hr + 24 - 6) % 24;
      var idx = (DAY_TO_HORA[effDow] + hrsSinceSunrise) % 7;
      var minsLeftHora = 60 - mn;
      return {
        dayLord: DAY_LORD[effDow],
        horaLord: HORA_SEQ[idx],
        horaLeft: minsLeftHora + 'm',
        time: now.toTimeString().slice(0, 5)
      };
    }
    function dayScore(x) {
      var g = kpDay(x);
      var r = TOP.map(function (t, i) {
        return PCT(g.segs.reduce(function (s, y) { return s + y.f[i] * (y.t1 - y.t0); }, 0) / 24);
      });
      return { g: g, r: r, avg: Math.round(r.reduce(function (a, b) { return a + b; }, 0) / r.length) };
    }
    function curDashaObj() {
      var now = Date.now() / 864e5 + 2440587.5;
      var f = function (x) { return now >= x[1] && now < x[1] + x[2]; };
      var m = mainL.find(f), a = m && kids(m).find(f), p = a && kids(a).find(f);
      return {
        names: [m, a, p].filter(Boolean).map(function (x) { return PLN[x[0]]; }),
        end: p ? dt(p[1] + p[2]) : (a ? dt(a[1] + a[2]) : '')
      };
    }
    function ringSvg(p, sz) {
      var r = sz / 2 - 8, L = 2 * Math.PI * r, h = sz / 2;
      var col = p >= 55 ? '#10b981' : p >= 40 ? '#38bdf8' : '#f43f5e';
      return '<svg class="kring" viewBox="0 0 ' + sz + ' ' + sz + '">'
        + '<circle cx="' + h + '" cy="' + h + '" r="' + r + '" stroke="rgba(125,211,252,0.16)"/>'
        + '<circle cx="' + h + '" cy="' + h + '" r="' + r + '" stroke="' + col + '" stroke-linecap="round" stroke-dasharray="' + (L * p / 100) + ' ' + L + '" transform="rotate(-90 ' + h + ' ' + h + ')"/>'
        + '<text x="' + h + '" y="' + (h + 7) + '" text-anchor="middle">' + p + '%</text></svg>';
    }

    function computePillars() {
      var _sg = ok(function () { return signif(c); });
      var sig = _sg && (_sg.out || _sg);
      if (!sig) return [];
      var defs = [
        [T('ධනය', 'Wealth'), 1, [2, 6, 10, 11], [5, 8, 12], 't17'],
        [T('රැකියාව', 'Career'), 9, [2, 6, 10, 11], [5, 8, 12], 't15'],
        [T('විවාහය', 'Marriage'), 6, [2, 7, 11], [1, 6, 10], 't8'],
        [T('අධ්‍යාපන', 'Education'), 3, [4, 9, 11], [3, 8, 12], 't5'],
        [T('විදේශ', 'Foreign'), 11, [3, 9, 12], [2, 4, 11], 't17'],
        [T('සෞඛ්‍යය', 'Health'), 0, [1, 5, 11], [6, 8, 12], 't14']
      ];
      return defs.map(function (df) {
        var cslCode = P[lords(c.cs[df[1]]).sl];
        var levels = sig[cslCode] || [[], [], [], [], []];
        var w = [4, 3, 2, 1.5, 1], pos = 0, neg = 0, tot = 0;
        levels.forEach(function (arr, li) {
          (arr || []).forEach(function (h) {
            tot += w[li];
            if (df[2].indexOf(h) !== -1) pos += w[li];
            if (df[3].indexOf(h) !== -1) neg += w[li];
          });
        });
        var raw = tot > 0 ? Math.round(50 + ((pos - neg) / (tot + 2)) * 55) : 50;
        var pct = Math.max(18, Math.min(96, raw));
        return { label: df[0], pct: pct, csl: PLN[lords(c.cs[df[1]]).sl], tab: df[4] };
      });
    }

    // Authentic KP Gem / Color / Metal Eligibility:
    // ONLY 1st Cusp Sub-Lord (CSL) or 11th Cusp Sub-Lord (CSL), strictly IF it does NOT signify 6, 8, or 12.
    function computeKPGems() {
      var _sg = ok(function () { return signif(c); });
      var sig = _sg && (_sg.out || _sg);
      if (!sig || !c || !c.cs || c.cs.length < 11) return null;
      function evalCsl(cuspIdx, labelSi, labelEn) {
        var slIdx = lords(c.cs[cuspIdx]).sl;
        var code = P[slIdx];
        var lv = sig[code] || [[], [], [], []];
        var allH = [];
        [0, 1, 2, 3].forEach(function (i) {
          (lv[i] || []).forEach(function (h) { if (allH.indexOf(h) === -1) allH.push(h); });
        });
        allH.sort(function (a, b) { return a - b; });
        var bad = allH.filter(function (h) { return h === 6 || h === 8 || h === 12; });
        return {
          cusp: cuspIdx + 1,
          label: SI ? labelSi : labelEn,
          code: code,
          meta: KP_GEMS[code],
          houses: allH,
          bad: bad,
          ok: bad.length === 0
        };
      }
      var c1 = evalCsl(0, '1 වන භාව උප-අධිපති (ලග්න)', '1st Cusp Sub-Lord (Lagna)');
      var c11 = evalCsl(10, '11 වන භාව උප-අධිපති (ලාභ)', '11th Cusp Sub-Lord (Gains)');
      var eligible = [];
      if (c1.ok && c11.ok && c1.code === c11.code) {
        c1.both = true;
        eligible.push(c1);
      } else {
        if (c1.ok) eligible.push(c1);
        if (c11.ok) eligible.push(c11);
      }
      return { c1: c1, c11: c11, eligible: eligible };
    }

    /* ---------- Clean Glowing Cyan SVG Icons (Lanka Bus Bento Style) ---------- */
    var SVG_CHART = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 12h18M12 3v18M12 3l9 9-9 9-9-9z"/></svg>';
    var SVG_DASHA = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 1.5M5 3L2 6M22 6l-3-3M9 2h6"/></svg>';
    var SVG_AI = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="6" width="16" height="12" rx="3"/><path d="M12 2v4M9 11h.01M15 11h.01M9 15h6"/></svg>';
    var SVG_LIFE = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4z"/></svg>';
    var SVG_HORARY = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4M12 17h.01"/></svg>';
    var SVG_NOW = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';

    var WK_FULL = SI ? ['ඉරිදා','සඳුදා','අඟහරුවාදා','බදාදා','බ්‍රහස්පතින්දා','සිකුරාදා','සෙනසුරාදා']
                     : ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    function fmtLiveTime() {
      var n = new Date(), h = n.getHours(), m = String(n.getMinutes()).padStart(2, '0');
      var ap = SI ? (h >= 12 ? 'ප.ව.' : 'පෙ.ව.') : (h >= 12 ? 'PM' : 'AM');
      var h12 = (h % 12) || 12;
      var dStr = n.getFullYear() + '.' + String(n.getMonth() + 1).padStart(2, '0') + '.' + String(n.getDate()).padStart(2, '0');
      return {
        clock: SI ? (ap + ' ' + h12 + ':' + m) : (h12 + ':' + m + ' ' + ap),
        date: WK_FULL[n.getDay()] + ' ' + dStr
      };
    }

    /* ---------- 0 · Compact Bento Welcome Screen (Lanka Bus Style) ---------- */
    function buildWelcome() {
      if (E('kp-welcome')) return;
      var tp = E('tp'); if (!tp) return;
      var lt = fmtLiveTime(), pn = livePanchanga();
      var w = document.createElement('div');
      w.id = 'kp-welcome';
      w.innerHTML =
        '<div class="kb-hero">' +
          '<div class="kb-hero-row">' +
            '<button type="button" class="kb-gold-pill" id="kw-now">' +
              '<small>' + T('ක්ෂණික KP ගණනය ▾', 'Quick KP Chart ▾') + '</small>' +
              '<b>⚡ ' + T('දැන් වේලාවෙන් පත්‍රය', 'Instant Chart Now') + '</b>' +
            '</button>' +
            '<div class="kb-clock"><b id="kw-clk">' + lt.clock + '</b><small>' + lt.date + '</small></div>' +
          '</div>' +
          '<div class="kb-ticker">' +
            '<div class="kb-ticker-main"><span class="kb-dot r"></span>' + T('දින අධිපති: ', 'Day: ') + '<b>' + pn.dayLord + '</b> · <span class="kb-dot b"></span>' + T('හෝරාව: ', 'Hora: ') + '<b>' + pn.horaLord + '</b> · <span class="kb-dot g"></span>' + T('100% නොමිලේ', '100% Free') + '</div>' +
            '<div class="kb-ticker-r">KP<br>Offline</div>' +
          '</div>' +
        '</div>' +

        '<button type="button" id="kp-install-btn">📲 ' + T('ඇප් එක දුරකථනයට ස්ථාපනය කරන්න (Install App)', 'Install KP AI Pro App') + '</button>' +

        '<div class="kb-grid">' +
          '<button type="button" class="kb-tile" id="kw-form">' +
            '<div class="kb-tile-top"><span class="kb-badge rose">' + T('ජන්ම පත්‍රය', 'CHART') + '</span>' + SVG_CHART + '</div>' +
            '<div><span class="kb-tile-t">' + T('උපන් පත්‍රය සාදන්න', 'Birth Chart') + '</span><span class="kb-tile-s">' + T('Lagna, භාව & Signif.', 'Lagna, Houses & Signif.') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="kw-ai">' +
            '<div class="kb-tile-top"><span class="kb-badge purp">AI</span>' + SVG_AI + '</div>' +
            '<div><span class="kb-tile-t">' + T('KP AI ගුරු', 'KP AI Guru') + '</span><span class="kb-tile-s">' + T('ඕනෑම ප්‍රශ්නයක් අසන්න', 'Ask Anything · Offline') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="kw-hor">' +
            '<div class="kb-tile-top"><span class="kb-badge blue">1–249</span>' + SVG_HORARY + '</div>' +
            '<div><span class="kb-tile-t">' + T('Horary ප්‍රශ්න', 'Horary 1–249') + '</span><span class="kb-tile-s">' + T('KP අංකයෙන් පිළිතුරු', 'KP Number Prediction') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="kw-now2">' +
            '<div class="kb-tile-top"><span class="kb-badge teal">LIVE</span>' + SVG_NOW + '</div>' +
            '<div><span class="kb-tile-t">' + T('දැන් Ruling RP', 'Live Ruling RP') + '</span><span class="kb-tile-s">' + T('ක්ෂණික පාලක ග්‍රහයන්', 'Instant Ruling Planets') + '</span></div>' +
          '</button>' +
        '</div>';
      tp.insertAdjacentElement('afterend', w);

      // Add compact developer footer card below the birth form on Home screen
      if (!E('kp-devfoot')) {
        var df = document.createElement('div');
        df.id = 'kp-devfoot';
        df.innerHTML =
          '<div><small>Developed by</small><b>W. Vihanga Rasanjana Withanage</b></div>' +
          '<button type="button" id="kp-appshare">📤 ' + T('බෙදාගන්න', 'Share App') + '</button>';
        var resEl = E('res');
        if (resEl && resEl.parentNode) resEl.parentNode.insertBefore(df, resEl);
        E('kp-appshare').onclick = function () {
          var txt = T('✦ KP Astrology AI Pro — ක්‍රිෂ්ණමූර්ති පද්ධති ජන්ම පත්‍රය, KP AI ගුරු සහ ජීවිත පලාපල!', '✦ KP Astrology AI Pro — Birth Chart, KP AI Guru & Life Predictions!');
          if (navigator.share) navigator.share({ title: 'KP Astrology AI Pro', text: txt, url: location.href }).catch(function () {});
          else window.open('https://wa.me/?text=' + encodeURIComponent(txt + ' ' + location.href), '_blank');
        };
      }

      if (S.installPrompt) E('kp-install-btn').classList.add('show');
      E('kp-install-btn').onclick = function () {
        if (!S.installPrompt) return;
        S.installPrompt.prompt();
        S.installPrompt.userChoice.finally(function () { S.installPrompt = null; E('kp-install-btn').classList.remove('show'); });
      };

      function castNowAndGo(targetTab) {
        if (E('now')) E('now').click();
        if (E('la') && !E('la').value) { E('la').value = '6.9271'; E('lo').value = '79.8612'; E('tz').value = '5.5'; if (E('pl')) E('pl').value = 'Colombo'; }
        if (E('b1')) E('b1').click();
        if (targetTab) setTimeout(function () { if (c) nvB(targetTab, ''); }, 150);
      }

      E('kw-now').onclick = function () { castNowAndGo(''); };
      E('kw-now2').onclick = function () { castNowAndGo('t16'); };
      E('kw-form').onclick = function () {
        var fc = document.querySelector('.kp-form-card') || E('nm');
        if (fc) fc.scrollIntoView({ behavior: 'smooth', block: 'start' });
        if (E('nm')) E('nm').focus();
      };
      E('kw-ai').onclick = function () {
        if (!c) castNowAndGo('t18'); else nvB('t18', '');
      };
      E('kw-hor').onclick = function () {
        if (E('now')) E('now').click();
        var adv = $$('details.adv').find(function (d) { return d.textContent.indexOf('Horary') !== -1; });
        if (adv) {
          var stepBtn = document.querySelector('.kprog span[data-i="2"]');
          if (stepBtn) stepBtn.click();
          adv.open = true;
          adv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      };

      var hb = E('hb');
      if (hb && !E('kp-rand-hn')) {
        var rb = document.createElement('button');
        rb.id = 'kp-rand-hn';
        rb.type = 'button';
        rb.textContent = '🎲 ' + T('අහඹු අංකයක් (1–249)', 'Random 1–249');
        rb.onclick = function () {
          var n = Math.floor(Math.random() * 249) + 1;
          if (E('hn')) E('hn').value = n;
          if (E('now')) E('now').click();
          mnToast(T('🎲 KP Horary අංකය: ', '🎲 KP Horary Number: ') + n);
        };
        hb.parentNode.insertBefore(rb, hb);
      }
    }

    var MORE_TABS = [
      ['t2', '🏠 ' + T('භාව', 'Houses'), ''],
      ['t3', '⭐ Signif.', ''],
      ['t4', '⏳ ' + T('දශා', 'Dasha'), ''],
      ['t10', '📅 ' + T('දශා ඵල', 'Dasha+'), ''],
      ['t6', '🌍 ' + T('ගෝචර', 'Transits'), ''],
      ['t7', '🍀 ' + T('සුබ දින', '42-Day'), ''],
      ['t16', '🔱 ' + T('Ruling RP', 'Live RP'), ''],
      ['t13', '🎯 Horary', ''],
      ['t9', '🕰️ BTR', ''],
      ['t15', '💼 ' + T('වෘත්ති', 'Career'), ''],
      ['t8', '💍 ' + T('විවාහ', 'Match'), ''],
      ['t14', '🧰 KP+', 'kpPlus'],
      ['t11', '📜 ' + T('අතීත', 'Past'), ''],
      ['', '📄 PDF', 'pdf'],
      ['__share', '📤 WhatsApp', '']
    ];

    /* ---------- 1 · Compact Bento Results Dashboard (Lanka Bus Style!) ---------- */
    function buildSum() {
      var res = E('res'); if (!res || !c) return;
      var d = ok(function () { return dayScore(today()); });
      var lg = Math.floor(c.cs[0] / 30), lgDeg = dms(c.cs[0] % 30);
      var lgL = ok(function () { return lords(c.cs[0]); });
      var mo = c.pl.Mo, mn = Math.floor(mo / 30);
      var nk = Math.floor(mo / (40 / 3)), pd = Math.floor((mo / (40 / 3) % 1) * 4) + 1;
      var ds = ok(curDashaObj) || { names: [], end: '' };
      var pn = livePanchanga(), lt = fmtLiveTime();
      var nm = (E('nm') && E('nm').value.trim()) || T('ජන්ම පත්‍රය', 'Birth Chart');
      var avg = d ? d.avg : 50;
      var moodCls = avg >= 55 ? 'ok' : avg >= 40 ? 'mid' : 'bad';
      var pillars = ok(computePillars) || [];
      var kpGems = ok(computeKPGems);

      var card = E('ksum');
      if (!card) {
        card = document.createElement('div');
        card.id = 'ksum';
        res.insertBefore(card, E('nv') || res.firstChild);
      }

      card.innerHTML =
        '<div class="kb-hero">' +
          '<div class="kb-hero-row">' +
            '<button type="button" class="kb-gold-pill" id="kb-lagna-pill">' +
              '<small>' + esc(nm) + ' · ' + T('ලග්නය', 'Lagna') + '</small>' +
              '<b>' + SGN[lg] + ' ' + lgDeg + '</b>' +
            '</button>' +
            '<div class="kb-clock">' +
              '<b id="kp-live-clk">' + lt.clock + '</b>' +
              '<span class="kb-score-chip ' + moodCls + '">' + T('අද ', 'Today ') + avg + '%</span>' +
            '</div>' +
          '</div>' +
          '<div class="kb-ticker">' +
            '<div class="kb-ticker-main">' +
              '<span class="kb-dot r"></span>' + SGN[mn] + ' · ' + NKN[nk % 27] + ' (' + pd + ') · ' +
              '<span class="kb-dot b"></span>' + (ds.names.join('-') || '—') +
              (lgL ? ' · <span class="kb-dot g"></span>SL:' + PLN[lgL.sl] + ' SSL:' + PLN[lgL.ssl] : '') +
            '</div>' +
            '<div class="kb-ticker-r">' + pn.horaLord + '<br><span style="font-size:9px;color:var(--mu)">' + T('හෝරාව', 'Hora') + '</span></div>' +
          '</div>' +
        '</div>' +

        '<div class="kb-grid" id="kb-main4">' +
          '<button type="button" class="kb-tile" data-qt="t1">' +
            '<div class="kb-tile-top"><span class="kb-badge rose">' + T('KP පත්‍රය', 'CHART') + '</span>' + SVG_CHART + '</div>' +
            '<div><span class="kb-tile-t">' + T('ජන්ම පත්‍රය', 'Birth Chart') + '</span><span class="kb-tile-s">' + T('ලග්න, භාව & ග්‍රහයන්', 'Lagna, South & North') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" data-qt="t5">' +
            '<div class="kb-tile-top"><span class="kb-badge blue">' + T('5-මට්ටම', 'KP+') + '</span>' + SVG_DASHA + '</div>' +
            '<div><span class="kb-tile-t">' + T('දශා සහ පලාපල', 'Forecast & Dasha') + '</span><span class="kb-tile-s">' + T('මහා → ප්‍රාණ KP+ ලකුණු', 'Maha → Prana KP+') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" data-qt="t18">' +
            '<div class="kb-tile-top"><span class="kb-badge purp">AI</span>' + SVG_AI + '</div>' +
            '<div><span class="kb-tile-t">' + T('KP AI ගුරු', 'KP AI Guru') + '</span><span class="kb-tile-s">' + T('ප්‍රශ්න අසන්න · Offline', 'Ask Anything · AI') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" data-qt="t17">' +
            '<div class="kb-tile-top"><span class="kb-badge teal">' + T('සවිස්තර', 'LIFE') + '</span>' + SVG_LIFE + '</div>' +
            '<div><span class="kb-tile-t">' + T('ජීවිත පලාපල', 'Life Predictions') + '</span><span class="kb-tile-s">' + T('සිදුවෙනවාද / නැද්ද & කාල', 'Detailed KP Life Guide') + '</span></div>' +
          '</button>' +
        '</div>' +

        '<details class="kb-more" id="kb-more-box">' +
          '<summary>✨ ' + T('තවත් KP සේවා (14) — භාව, Signif., BTR, විවාහ, KP+, මැණික්', 'More KP Tools (14) — Houses, Signif., BTR, Match, KP+, Gems') + '</summary>' +
          '<div class="kb-more-body">' +
            '<div class="kb-mini-grid" id="kp-qstrip">' +
              MORE_TABS.map(function (q) {
                return '<button type="button" class="kb-mini-btn" data-qt="' + q[0] + '" data-qf="' + q[2] + '">' + q[1] + '</button>';
              }).join('') +
            '</div>' +

            (pillars.length ? '<div class="kb-subhd">✦ ' + T('ප්‍රධාන භාව උප-අධිපති පොරොන්දුව (CSL)', 'KP Cuspal Sub-Lord Promise') + '</div>' +
              '<div class="kp-pgrid">' +
                pillars.map(function (pl) {
                  var cls = pl.pct >= 60 ? 'ok' : pl.pct >= 42 ? 'mid' : 'bad';
                  var bg = pl.pct >= 60 ? '#10b981' : pl.pct >= 42 ? '#38bdf8' : '#f43f5e';
                  return '<div class="kp-pitem" data-ptab="' + pl.tab + '">' +
                    '<span class="plb">' + pl.label + ' (' + pl.csl + ')</span>' +
                    '<span class="pval ' + cls + '">' + pl.pct + '%</span>' +
                    '<div class="pbar"><i style="width:' + pl.pct + '%;background:' + bg + '"></i></div>' +
                  '</div>';
                }).join('') +
              '</div>' : '') +

            (kpGems ? '<div class="kb-subhd">💎 ' + T('KP මැණික්, සුබ වර්ණ & ලෝහ (1 / 11 උප-අධිපති)', 'KP Gems, Colors & Metals (1st / 11th CSL)') + '</div>' +
              '<div class="kl-grid">' +
                [kpGems.c1, kpGems.c11].map(function (it) {
                  return '<div class="kl-box"><small>' + it.label + '</small>' +
                    '<b style="color:' + (it.ok ? 'var(--hl)' : 'var(--hn)') + '">' + (SI ? it.meta.si : it.meta.en) + ' — ' + (it.ok ? T('✅ සුදුසුයි', '✅ Eligible') : T('❌ නුසුදුසුයි', '❌ Avoid')) + '</b>' +
                    '<small style="margin-top:2px">' + T('භාව: ', 'Houses: ') + (it.houses.join(', ') || '—') + (it.bad.length ? ' (' + T('6/8/12 ඇත: ', 'Has: ') + it.bad.join(',') + ')' : '') + '</small>' +
                  '</div>';
                }).join('') +
              '</div>' +
              (kpGems.eligible.length
                ? kpGems.eligible.map(function (it) {
                    var m = it.meta;
                    return '<div class="kl-rec">' +
                      '<div class="kl-rec-hd">✨ ' + (SI ? m.si : m.en) + ' (' + (it.both ? T('1 සහ 11 භාව උප-අධිපති', '1st & 11th CSL') : (it.cusp === 1 ? T('1 වන භාව උප-අධිපති', '1st CSL') : T('11 වන භාව උප-අධිපති', '11th CSL'))) + ')</div>' +
                      '<div class="kl-grid">' +
                        '<div class="kl-box"><small>💎 ' + T('සුදුසු මැණික', 'Gemstone') + '</small><b style="color:var(--pl)">' + (SI ? m.gemSi : m.gemEn) + '</b></div>' +
                        '<div class="kl-box"><small>🎨 ' + T('ග්‍රහයාට අයත් පාට', 'Color') + '</small><b>' + (SI ? m.colSi : m.colEn) + '</b></div>' +
                        '<div class="kl-box" style="grid-column:1/-1"><small>⚙️ ' + T('පාලනය කරන ලෝහය', 'Metal Ruled') + '</small><b>' + (SI ? m.metSi : m.metEn) + '</b></div>' +
                      '</div>' +
                    '</div>';
                  }).join('')
                : '<div class="kl-warn">⚠️ ' + T('මෙම ජන්ම පත්‍රයේ 1 වන සහ 11 වන උප-අධිපතීන් දෙදෙනාම 6, 8 හෝ 12 භාව සම්බන්ධ කරන බැවින්, ක්‍රිෂ්ණමූර්ති (KP) සිද්ධාන්තය අනුව මැණික් පැළඳීම නිර්දේශ නොකෙරේ.', 'Both 1st and 11th Cuspal Sub-Lords signify 6, 8, or 12 in this chart, so KP rules advise against wearing a gemstone.') + '</div>') +
              '<div class="kl-note">' + T('KP සිද්ධාන්තය: මැණිකක් පැළඳීමට සුදුසු වන්නේ 1 වන හෝ 11 වන භාව උප-අධිපති 6, 8, 12 භාව ලබා නොදෙන්නේ නම් පමණි.', 'KP Rule: A gemstone is recommended ONLY for the 1st or 11th Cuspal Sub-Lord, and strictly if it does NOT signify 6, 8, or 12.') + '</div>' : '') +
          '</div>' +
        '</details>';

      E('kb-lagna-pill').onclick = function () { nvB('t1', ''); };
      E('kb-main4').onclick = function (e) {
        var b = e.target.closest('button[data-qt]');
        if (!b || !c) return;
        nvB(b.dataset.qt, '');
      };
      E('kp-qstrip').onclick = function (e) {
        var b = e.target.closest('button[data-qt]');
        if (!b || !c) return;
        if (b.dataset.qt === '__share') { share(); return; }
        var mb = E('kb-more-box'); if (mb) mb.open = false;
        nvB(b.dataset.qt, b.dataset.qf || '');
      };
      $$('.kp-pitem', card).forEach(function (el) {
        el.onclick = function () {
          if (!c) return;
          var mb = E('kb-more-box'); if (mb) mb.open = false;
          nvB(el.dataset.ptab, el.dataset.ptab === 't14' ? 'kpPlus' : '');
        };
      });

      if (S.clockTimer) clearInterval(S.clockTimer);
      S.clockTimer = setInterval(function () {
        var nt = fmtLiveTime().clock;
        ['kp-live-clk', 'kw-clk'].forEach(function (id) {
          var ck = E(id);
          if (ck && ck.textContent !== nt) {
            if (ob) ob.disconnect();
            ck.textContent = nt;
            if (ob) ob.observe(document.body, OBC);
          }
        });
      }, 30000);

      S.day = d;
    }

    /* ---------- 2 · Midnight-Cyan WhatsApp Share Card ---------- */
    function share() {
      var go = function () { ok(drawShare); };
      if (document.fonts && document.fonts.load) document.fonts.load('700 40px "Noto Sans Sinhala"').then(go, go);
      else go();
    }
    function drawShare() {
      var W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      var x = cv.getContext('2d'), F = '"Noto Sans Sinhala","Inter",system-ui,sans-serif';
      var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#060d14'); g.addColorStop(1, '#0c2436');
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      var rg = x.createRadialGradient(W * 0.8, 0, 20, W * 0.8, 0, 560);
      rg.addColorStop(0, 'rgba(56,189,248,0.28)'); rg.addColorStop(1, 'transparent');
      x.fillStyle = rg; x.fillRect(0, 0, W, H);

      var d = S.day || dayScore(today()), nm = (E('nm') && E('nm').value) || '', lg = Math.floor(c.cs[0] / 30), mn = Math.floor(c.pl.Mo / 30), nk = Math.floor(c.pl.Mo / (40 / 3)) % 27;
      function tx(s, px, py, sz, col, w, al, mx) {
        x.font = (w || 600) + ' ' + sz + 'px ' + F; x.fillStyle = col; x.textAlign = al || 'left'; s = String(s);
        if (mx) while (x.measureText(s).width > mx && s.length > 2) s = s.slice(0, -2);
        x.fillText(s, px, py);
      }
      tx('✦ KP ASTROLOGY AI PRO', 60, 100, 44, '#38bdf8', 800);
      tx(today() + (nm ? '  ·  ' + nm : ''), 60, 158, 30, '#82a4b8', 500, 'left', 960);
      var cx = 215, cy = 380, r = 118, p = d.avg, col = p >= 55 ? '#10b981' : p >= 40 ? '#38bdf8' : '#f43f5e';
      x.lineWidth = 22; x.lineCap = 'round'; x.strokeStyle = 'rgba(125,211,252,0.18)'; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.stroke();
      x.strokeStyle = col; x.beginPath(); x.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p / 100); x.stroke();
      tx(p + '%', cx, cy + 22, 62, '#eef7fb', 700, 'center');
      tx(T('අද ලකුණු', 'TODAY'), cx, cy + r + 58, 28, '#82a4b8', 600, 'center');
      var ds = ok(curDashaObj) || { names: [] };
      var rows = [
        [T('ලග්නය', 'Lagna'), SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°'],
        [T('චන්ද්‍ර රාශිය', 'Moon'), SGN[mn]],
        [T('නැකත', 'Nakshatra'), NKN[nk]],
        [T('දශාව', 'Dasha'), ds.names.join(' - ') || '—']
      ];
      rows.forEach(function (r2, i) { var y = 290 + i * 58; tx(r2[0], 440, y, 26, '#82a4b8', 500); tx(r2[1], 650, y, 30, '#eef7fb', 700, 'left', 370); });
      tx(T('අද ප්‍රබල ක්ෂේත්‍ර', 'TOP FIELDS TODAY'), 60, 640, 34, '#38bdf8', 800);
      var top = d.r.map(function (v, i) { return [v, i]; }).sort(function (a, b) { return b[0] - a[0]; }).slice(0, 6);
      top.forEach(function (t, i) {
        var y = 705 + i * 86;
        tx(TOP[t[1]][0], 60, y, 30, '#eef7fb', 500, 'left', 550);
        x.fillStyle = 'rgba(125,211,252,0.16)'; x.fillRect(640, y - 24, 240, 16);
        x.fillStyle = t[0] >= 55 ? '#10b981' : t[0] >= 40 ? '#38bdf8' : '#f43f5e';
        x.fillRect(640, y - 24, 240 * t[0] / 100, 16);
        tx(t[0] + '%', 1020, y, 28, '#eef7fb', 700, 'right');
      });
      tx(T('ක්‍රිෂ්ණමූර්ති පද්ධතිය (KP) අනුව ගණනය කරන ලදී', 'Calculated with Krishnamurti Paddhati (KP)'), W / 2, H - 48, 24, '#648599', 500, 'center');
      cv.toBlob(function (b) {
        if (!b) return;
        var f; try { f = new File([b], 'kp-ai-pro-forecast.png', { type: 'image/png' }); } catch (e) {}
        var dl = function () {
          var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'kp-ai-pro-forecast.png';
          document.body.appendChild(a); a.click(); a.remove();
          mnToast(T('පින්තූරය සුරැකිණි — WhatsApp එකෙන් යවන්න', 'Image saved — share on WhatsApp'));
        };
        if (f && navigator.canShare && navigator.canShare({ files: [f] })) {
          navigator.share({ files: [f], title: 'KP Astrology AI Pro' }).catch(function (e) { if (!e || e.name !== 'AbortError') dl(); });
        } else dl();
      }, 'image/png');
    }

    /* ---------- 3 · Bottom Bar (with 🤖 AI ගුරු center highlight) ---------- */
    function buildBar() {
      var b = document.createElement('nav'); b.id = 'kbar';
      var it = [
        ['🪐', T('පත්‍රය', 'Chart'), 't1'],
        ['🔮', T('පලාපල', 'Forecast'), 't5'],
        ['🤖', T('AI ගුරු', 'AI Guru'), 't18'],
        ['🌟', T('ජීවිත', 'Life'), 't17'],
        ['☰', T('මෙනුව', 'Menu'), '']
      ];
      b.innerHTML = it.map(function (x) { return '<button data-t="' + x[2] + '"><i>' + x[0] + '</i>' + x[1] + '</button>'; }).join('');
      b.onclick = function (e) {
        var q = e.target.closest('button'); if (!q) return;
        var t = q.dataset.t; if (!t) return mnO();
        if (!c) return; nvB(t, ''); window.scrollTo(0, 0);
      };
      document.body.appendChild(b);
    }
    function barState(t) {
      $$('#kbar button').forEach(function (b) { b.classList.toggle('on', !!b.dataset.t && b.dataset.t === t); });
      $$('#kb-main4 button, #kp-qstrip button').forEach(function (b) { b.classList.toggle('on', !!b.dataset.qt && b.dataset.qt === t); });
    }

    /* ---------- 4 · Drawer Tiles, Tables, Charts, Heatmap, Wizard ---------- */
    var ICO = { t1:'🪐',t2:'🏠',t3:'⭐',t4:'⏳',t9:'🕰️',t5:'🔮',t12:'📊',t6:'🌍',t7:'🍀',t15:'💼',t8:'💍',t10:'📅',t11:'📜',t16:'🔱',t13:'🎯',t17:'🌟',t18:'🤖',pdf:'📄',kpPlus:'🧰' };
    function tiles() {
      $$('#dw .pn button[onclick^="mnB"]').forEach(function (b) {
        if (b.querySelector('.ti')) return;
        var m = /mnB\('([^']*)','([^']*)'\)/.exec(b.getAttribute('onclick') || '');
        var k = m && (m[1] || m[2]), tx = b.textContent.trim().replace(/\s*🔒\s*$/, '');
        var em = /^(\p{Extended_Pictographic}\uFE0F?)\s*/u.exec(tx), ic = em ? em[1] : (ICO[k] || '✦');
        if (em) tx = tx.slice(em[0].length);
        b.innerHTML = '<span class="ti">' + ic + '</span><span>' + tx + '</span>';
      });
    }

    var RX = /^(AS|Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)(\(R\))?$/;
    function tables(root) {
      if (!root) return;
      $$('table', root).forEach(function (t) {
        if (!t.parentNode.classList.contains('tw')) {
          var w = document.createElement('div'); w.className = 'tw'; t.parentNode.insertBefore(w, t); w.appendChild(t);
        }
        if (t.dataset.kDone === String(t.rows.length)) return;
        t.dataset.kDone = String(t.rows.length);
        $$('td', t).forEach(function (td) {
          if (td.dataset.k) return; td.dataset.k = 1;
          var m = RX.exec(td.textContent.trim());
          if (m && td.children.length === 0) td.innerHTML = '<span class="pc pc-' + m[1] + '">' + m[1] + (m[2] ? '<sup>R</sup>' : '') + '</span>';
        });
      });
    }

    var SPOS = { 11:[0,0],0:[1,0],1:[2,0],2:[3,0],10:[0,1],3:[3,1],9:[0,2],4:[3,2],8:[0,3],7:[1,3],6:[2,3],5:[3,3] };
    function paint(sv) {
      $$('text', sv).forEach(function (t) {
        var m = /^(Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)/.exec(t.textContent);
        if (m && t.getAttribute('fill') !== 'var(--hn)') t.style.fill = PC[m[1]];
      });
    }
    function south() {
      var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 400 400'); s.setAttribute('class', 'ks');
      var lg = Math.floor(c.cs[0] / 30), by = {}, h = '<g fill="none" stroke="rgba(125,211,252,0.34)">';
      Object.keys(c.pl).forEach(function (p) { var sg = Math.floor(c.pl[p] / 30); (by[sg] = by[sg] || []).push([p, Math.floor(c.pl[p] % 30), !!(c.rt[p] || p == 'Ra' || p == 'Ke')]); });
      for (var sg = 0; sg < 12; sg++) { var q = SPOS[sg]; h += '<rect x="' + (q[0] * 100) + '" y="' + (q[1] * 100) + '" width="100" height="100"' + (sg == lg ? ' stroke="#38bdf8" stroke-width="2.8"' : '') + '/>'; }
      h += '</g>';
      for (sg = 0; sg < 12; sg++) {
        q = SPOS[sg]; var x0 = q[0] * 100 + 7, y0 = q[1] * 100;
        h += '<text x="' + (x0 + 86) + '" y="' + (y0 + 14) + '" text-anchor="end" fill="#82a4b8" style="font-size:9px;font-weight:500">' + SGN[sg].slice(0, 3) + '</text>';
        var L = (sg == lg ? [['As', null, 0]] : []).concat(by[sg] || []);
        L.forEach(function (e, i) {
          h += '<text x="' + x0 + '" y="' + (y0 + 30 + i * 14) + '" fill="' + (e[0] == 'As' ? '#38bdf8' : (PC[e[0]] || '#eef7fb')) + '" style="font-size:12px;font-weight:700">' + e[0] + (e[2] ? '*' : '') + (e[1] != null && e[0] != 'As' ? ' ' + e[1] : '') + '</text>';
        });
      }
      h += '<text x="200" y="196" text-anchor="middle" fill="#38bdf8" style="font-size:14px;font-weight:800">' + T('රාශි සටහන', 'Rasi Chart') + '</text>';
      h += '<text x="200" y="216" text-anchor="middle" fill="#82a4b8" style="font-size:11px;font-weight:500">' + SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°</text>';
      s.innerHTML = h; return s;
    }
    function charts() {
      var t1 = E('t1');
      if (t1 && c) {
        var sv = t1.querySelector('svg:not(.ks)');
        if (sv && !t1.querySelector('.kct')) {
          var bar = document.createElement('div'); bar.className = 'kct';
          bar.innerHTML = '<button data-s="S">▦ South (KP)</button><button data-s="N">◇ North</button>';
          sv.parentNode.insertBefore(bar, sv); var so = south(); sv.parentNode.insertBefore(so, sv.nextSibling);
          var ap = function (m) { sv.style.display = m == 'S' ? 'none' : ''; so.style.display = m == 'S' ? '' : 'none'; $$('button', bar).forEach(function (b) { b.className = b.dataset.s == m ? 'p' : ''; }); };
          bar.onclick = function (e) { var b = e.target.closest('button'); if (!b) return; try { localStorage.setItem('kpCs', b.dataset.s); } catch (x) {} ap(b.dataset.s); };
          ap((function () { try { return localStorage.getItem('kpCs') || 'S'; } catch (x) { return 'S'; } })());
        }
      }
      $$('.tab svg').forEach(function (sv) {
        if (sv.dataset.k || sv.getAttribute('viewBox') !== '0 0 400 400') return;
        sv.dataset.k = 1; paint(sv);
        sv.addEventListener('click', function () {
          var z = E('czm');
          if (!z) { z = document.createElement('div'); z.id = 'czm'; z.onclick = function () { z.classList.remove('on'); }; document.body.appendChild(z); }
          z.innerHTML = '<i>✕</i>'; var cl = sv.cloneNode(true); cl.style.display = ''; cl.removeAttribute('class'); z.appendChild(cl); z.classList.add('on');
        });
      });
    }

    var HM = { c: null, d: {}, busy: 0 };
    function days42() { var n = new Date(), a = []; for (var i = 0; i < 42; i++) a.push(new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate() + i)).toISOString().slice(0, 10)); return a; }
    function heatRender() {
      var box = E('khm'); if (!box) return;
      var ds = days42(), v = ds.map(function (x) { return HM.d[x]; }).filter(function (z) { return z != null; });
      var mn = Math.min.apply(0, v), mx = Math.max.apply(0, v), first = new Date(ds[0] + 'T00:00:00Z').getUTCDay();
      var h = '<h3>' + T('දින 42 සුබ-අසුබ සිතියම', '42-Day KP Heatmap') + '</h3><div class="khw">' + WD.map(function (w) { return '<i>' + w + '</i>'; }).join('');
      for (var i = 0; i < first; i++) h += '<b class="e"></b>';
      ds.forEach(function (x, i) {
        var s = HM.d[x]; if (s == null) { h += '<b class="sk"></b>'; return; }
        var t = mx > mn ? (s - mn) / (mx - mn) : 0.5;
        h += '<b class="' + (i == 0 ? 'td' : '') + '" data-d="' + x + '" data-v="' + s + '" style="background:hsl(' + Math.round(4 + 145 * t) + ' 65% var(--kl))">' + (+x.slice(8)) + '<small>' + s + '%</small></b>';
      });
      box.innerHTML = h + '</div><div class="khl"><span>' + T('අඩු', 'Low') + '</span><i></i><span>' + T('ඉහළ', 'High') + '</span></div>';
    }
    function heat() {
      var t7 = E('t7'); if (!t7 || t7.style.display !== 'block' || !c) return;
      if (!E('khm')) {
        var b = document.createElement('div'); b.id = 'khm'; b.className = 'card';
        b.onclick = function (e) { var q = e.target.closest('b[data-d]'); if (q) mnToast(q.dataset.d + ' — ' + q.dataset.v + '%'); };
        t7.insertBefore(b, t7.firstChild); heatRender();
      }
      if (HM.c !== c) HM = { c: c, d: {}, busy: 0 };
      var h = HM; if (h.busy) return;
      var todo = days42().filter(function (x) { return h.d[x] == null; }); if (!todo.length) return;
      h.busy = 1;
      var sched = window.requestIdleCallback
        ? function (fn) { window.requestIdleCallback(fn, { timeout: 60 }); }
        : function (fn) { requestAnimationFrame(fn); };
      (function step() {
        if (h.c !== c) return;
        if (scrolling) { setTimeout(step, 90); return; }
        var x = todo.shift();
        if (x != null) {
          h.d[x] = ok(function () { return dayScore(x).avg; });
          if (h.d[x] == null) h.d[x] = 50;
          if (!todo.length || todo.length % 4 === 0) heatRender();
        }
        if (todo.length) sched(step); else { heatRender(); h.busy = 0; }
      })();
    }

    function chips() {
      var box = E('pfc');
      if (!box) {
        box = document.createElement('div'); box.id = 'pfc';
        var anchor = E('kp-welcome') || E('tp');
        anchor.insertAdjacentElement('afterend', box);
      }
      var a = []; try { a = pg(); } catch (e) {}
      box.innerHTML = a.length ? '<div class="kpl">' + a.map(function (x, i) { return '<button class="kc" onclick="pfl(' + i + ')">👤 ' + esc(x.nm || '—') + '</button>'; }).join('') + '</div>' : '';
    }

    function wizard() {
      var card = $$('body > .card').find(function (el) { return $$('.sec', el).length >= 3; });
      if (!card || card.dataset.w) return;
      card.dataset.w = 1;
      card.classList.add('kp-form-card');
      var P3 = [0, 1, 2].map(function () { var d = document.createElement('div'); d.className = 'kstep'; return d; }), cur = 0, seen = 0;
      Array.prototype.slice.call(card.childNodes).forEach(function (n) {
        if (n.nodeType == 1 && n.classList.contains('sec')) cur = Math.min(seen++, 2);
        P3[cur].appendChild(n);
      });
      var nm = [T('පුද්ගල', 'Person'), T('දිනය/වේලාව', 'Date & Time'), T('ස්ථානය', 'Place')], pr = document.createElement('div');
      pr.className = 'kprog';
      pr.innerHTML = nm.map(function (n, i) { return '<span data-i="' + i + '"><b>' + (i + 1) + '</b>' + n + '</span>'; }).join('');
      card.appendChild(pr);
      P3.forEach(function (p, i) {
        var k = document.createElement('div'); k.className = 'kn';
        if (i > 0) k.innerHTML += '<button type="button" data-g="' + (i - 1) + '">⬅ ' + T('ආපසු', 'Back') + '</button>';
        if (i < 2) k.innerHTML += '<button type="button" class="p" data-g="' + (i + 1) + '">' + T('ඊළඟ', 'Next') + ' ➜</button>';
        p.appendChild(k); card.appendChild(p);
      });
      function set(n) {
        P3.forEach(function (p, i) { p.classList.toggle('on', i == n); });
        $$('span', pr).forEach(function (s, i) { s.className = i == n ? 'on' : i < n ? 'done' : ''; });
      }
      card.addEventListener('click', function (e) {
        var g = e.target.closest('[data-g]'), s = e.target.closest('.kprog span');
        if (g) set(+g.dataset.g); else if (s) set(+s.dataset.i);
      });
      set(0);
    }

    function skeleton() {
      var sk = document.createElement('div'); sk.id = 'ksk'; sk.innerHTML = '<div class="ksb"></div><div class="ksb"></div><div class="ksb"></div>'; document.body.appendChild(sk);
      document.addEventListener('click', function (e) {
        var b = e.target.closest && e.target.closest('#b1'); if (!b || b.dataset.go) return;
        e.stopImmediatePropagation(); e.preventDefault(); sk.classList.add('on');
        requestAnimationFrame(function () { setTimeout(function () { b.dataset.go = 1; try { b.click(); } finally { delete b.dataset.go; sk.classList.remove('on'); } }, 35); });
      }, true);
      var pl = window.pfl;
      if (pl) {
        window.pfl = function (i) {
          sk.classList.add('on');
          requestAnimationFrame(function () { setTimeout(function () { try { pl(i); } finally { sk.classList.remove('on'); } }, 35); });
        };
      }
    }

    var ob, tm, curTab = null, activeEl = null, pfSig = '', scrolling = false, scTm = null;
    window.addEventListener('scroll', function () {
      scrolling = true;
      clearTimeout(scTm);
      scTm = setTimeout(function () { scrolling = false; }, 110);
    }, { passive: true });
    function sync() {
      if (c && S.c !== c) { S.c = c; ok(buildSum); }
      var el0 = null, tabs = document.getElementsByClassName('tab');
      for (var i = 0; i < tabs.length; i++) { if (tabs[i].style.display === 'block') { el0 = tabs[i]; break; } }
      activeEl = el0;
      var t = el0 ? el0.id : '';
      if (t !== curTab) {
        curTab = t; barState(t);
        if (el0) { el0.classList.remove('kfade'); requestAnimationFrame(function () { el0.classList.add('kfade'); }); }
      }
    }
    function pfSync() {
      if (document.body.classList.contains('rv')) return;
      var s = ''; try { s = JSON.stringify(pg().map(function (x) { return x.nm; })); } catch (e) {}
      if (s !== pfSig) { pfSig = s; chips(); }
    }
    var OBC = { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] };
    function tick() {
      if (scrolling) { clearTimeout(tm); tm = setTimeout(tick, 120); return; }
      if (ob) ob.disconnect();
      ok(sync);
      var dw = E('dw');
      if (dw && !dw.querySelector('.ti')) ok(tiles);
      ok(pfSync);
      if (activeEl) { ok(function () { tables(activeEl); }); ok(charts); }
      if (curTab === 't7') ok(heat);
      if (ob) ob.observe(document.body, OBC);
    }

    ok(buildWelcome); ok(buildBar); ok(chips); ok(wizard); ok(skeleton);

    var RSK = ['g','nm','dt','tm','pl','la','lo','tz','ay','ao'];
    document.addEventListener('click', function (e) {
      if (!(e.target.closest && e.target.closest('#lgb')) || !c) return;
      var o = { t: curTab }; RSK.forEach(function (k) { if (E(k)) o[k] = E(k).value; });
      try { sessionStorage.setItem('kpRs', JSON.stringify(o)); } catch (x) {}
    }, true);
    ok(function () {
      var r = null; try { r = JSON.parse(sessionStorage.getItem('kpRs') || 'null'); sessionStorage.removeItem('kpRs'); } catch (x) {}
      if (!r) return;
      RSK.forEach(function (k) { if (E(k) && r[k] != null) E(k).value = r[k]; });
      ['la', 'lo'].forEach(function (k) { if (E(k)) E(k).dispatchEvent(new Event('input')); });
      setTimeout(function () {
        if (E('b1')) E('b1').click();
        var n = 0, iv = setInterval(function () {
          if (c || ++n > 60) { clearInterval(iv); if (c && r.t) ok(function () { nvB(r.t, ''); }); }
        }, 100);
      }, 60);
    });

    document.addEventListener('click', function (e) {
      if (e.target && e.target.closest && (e.target.closest('.hbt') || e.target.closest('#kbar button[data-t=""]'))) {
        requestAnimationFrame(function () { var dw = E('dw'); if (dw && !dw.querySelector('.ti')) ok(tiles); });
      }
    });
    ob = new MutationObserver(function (muts) {
      var real = false;
      for (var i = 0; i < muts.length; i++) {
        var tg = muts[i].target;
        if (tg && tg.id === 'kp-live-clk') continue;
        real = true; break;
      }
      if (!real) return;
      clearTimeout(tm); tm = setTimeout(tick, 80);
    });
    tick();
  }
})();
