/* ==========================================================================
   KP ASTROLOGY AI PRO v20 — TRUE MULTI-SCREEN NATIVE ANDROID 120HZ UI ENGINE
   Screens: home | form | horary | profiles | settings | page
   ========================================================================== */
(function () {
  if (!window.KPB || /[?&]plain\b/.test(location.search)) return;
  with (window.KPB) {
    var SI = /[\u0D80-\u0DFF]/.test((typeof NAV !== 'undefined' && NAV[0] && NAV[0][0]) || '');
    var T = function (a, b) { return SI ? a : b; };
    var E = function (i) { return document.getElementById(i); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
    var ok = function (f) { try { return f(); } catch (e) { if (window.console) console.warn('kp-ui', e); } };

    // Default Midnight-Cyan Dark Theme
    try {
      if (!localStorage.getItem('kpt_v10')) {
        document.documentElement.dataset.t = 'dark';
        localStorage.setItem('kpt_v10', 'dark');
      }
    } catch (e) {}

    function syncThemeIcon() {
      var btn = E('th');
      if (!btn) return;
      btn.textContent = document.documentElement.dataset.t === 'light' ? '🌙' : '☀️';
      btn.setAttribute('aria-label', T('තේමාව මාරු කරන්න', 'Toggle theme'));
    }
    syncThemeIcon();
    if (E('th')) E('th').addEventListener('click', function () { setTimeout(syncThemeIcon, 10); });

    if (SI) {
      document.body.classList.add('si');
      var flk = document.createElement('link');
      flk.rel = 'stylesheet';
      flk.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Sinhala:wght@400;600;700&display=swap';
      document.head.appendChild(flk);
    }
    if (E('lgb')) E('lgb').textContent = SI ? 'සිං/EN' : 'EN/සිං';
    if (E('aysub')) E('aysub').textContent = T('KP පද්ධතිය · Offline', 'KP Stellar System · Offline');

    // Add 💎 KP Gems & Colors (t19) into Drawer Menu NAV under Forecast/Life group
    try {
      var grp = NAV.find(function (x) { return x[1].some(function (y) { return y[1] === 't5'; }); }) || NAV[1];
      if (grp && !grp[1].some(function (y) { return y[1] === 't19'; })) {
        grp[1].push([T('💎 KP මැණික් & පාට', '💎 KP Gems & Colors'), 't19']);
      }
    } catch (e) {}

    var SGN = SI
      ? ['මේෂ','වෘෂභ','මිථුන','කටක','සිංහ','කන්‍යා','තුලා','වෘශ්චික','ධනු','මකර','කුම්භ','මීන']
      : ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
    var NKN = SI
      ? ['අස්විද','බරණ','කැති','රෙහෙණ','මුවසිරස','අද','පුනාවස','පුස','ඇසළ','මා','පුවපල්','උත්තරපල්','හත','සිත','සා','විසා','අනුර','දෙට','මුල','පුරාසල','උතුරුසල','සුවණ','දෙනට','සියාවස','පුව පුටුප','උතුරු පුටුප','රේවතී']
      : ['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','P.Phalguni','U.Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','P.Ashadha','U.Ashadha','Shravana','Dhanishta','Shatabhisha','P.Bhadrapada','U.Bhadrapada','Revati'];
    var PLN = SI
      ? ['කේතු','සිකුරු','රවි','චන්ද්‍ර','කුජ','රාහු','ගුරු','ශනි','බුධ']
      : ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
    var DAY_LORD = SI
      ? ['රවි','චන්ද්‍ර','කුජ','බුධ','ගුරු','සිකුරු','ශනි']
      : ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
    var HORA_SEQ = SI
      ? ['රවි','සිකුරු','බුධ','චන්ද්‍ර','ශනි','ගුරු','කුජ']
      : ['Sun','Venus','Mercury','Moon','Saturn','Jupiter','Mars'];
    var DAY_TO_HORA = [0, 3, 6, 2, 5, 1, 4];
    var WK_FULL = SI
      ? ['ඉරිදා','සඳුදා','අඟහරුවාදා','බදාදා','බ්‍රහස්පතින්දා','සිකුරාදා','සෙනසුරාදා']
      : ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

    var KP_GEMS = {
      Su: { si:'රවි', en:'Sun', gemSi:'Ruby (මාණික්‍ය)', gemEn:'Ruby', colSi:'තැඹිලි හෝ තද රතු', colEn:'Orange or Deep Red', metSi:'Gold & Copper (රන් සහ තඹ)', metEn:'Gold & Copper' },
      Mo: { si:'චන්ද්‍ර', en:'Moon', gemSi:'Pearl (මුතු)', gemEn:'Pearl', colSi:'සුදු, රිදී පාට', colEn:'White, Silvery', metSi:'Silver (රිදී)', metEn:'Silver' },
      Ma: { si:'කුජ', en:'Mars', gemSi:'Coral (පබළු)', gemEn:'Coral', colSi:'තද රතු', colEn:'Deep Red', metSi:'Copper / Iron (තඹ / යකඩ)', metEn:'Copper / Iron' },
      Me: { si:'බුධ', en:'Mercury', gemSi:'Emerald (පච්ච / මරකත)', gemEn:'Emerald', colSi:'අළු මිශ්‍ර කොළ පාට', colEn:'Greyish Green', metSi:'Quick-Silver (රසදිය)', metEn:'Quick-Silver' },
      Ju: { si:'ගුරු', en:'Jupiter', gemSi:'Topaz (පුෂ්පරාග)', gemEn:'Topaz', colSi:'දම්, වයලට්, නිල්, සුදු', colEn:'Purple, Violet, Blue, White', metSi:'Tin (ටින්)', metEn:'Tin' },
      Ve: { si:'සිකුරු', en:'Venus', gemSi:'Diamond (දියමන්ති)', gemEn:'Diamond', colSi:'කහ, ලා නිල්, සුදුත් නෙවෙයි කළුත් නෙවෙයි', colEn:'Yellow, Light Blue, Neutral Off-White', metSi:'Silver & Copper (රිදී සහ තඹ)', metEn:'Silver & Copper' },
      Sa: { si:'ශනි', en:'Saturn', gemSi:'Sapphire (නීල)', gemEn:'Sapphire', colSi:'දුඹුරු, ඉන්ඩිගෝ, කළු', colEn:'Brown, Indigo, Black', metSi:'Lead (ඊයම්)', metEn:'Lead' },
      Ra: { si:'රාහු', en:'Rahu', gemSi:'Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)', gemEn:'Agate or Turquoise', colSi:'මිශ්‍ර පාට', colEn:'Mixed Colors', metSi:'Alloy (මිශ්‍ර ලෝහ)', metEn:'Alloy' },
      Ke: { si:'කේතු', en:'Ketu', gemSi:'Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)', gemEn:'Agate or Turquoise', colSi:'මිශ්‍ර පාට', colEn:'Mixed Colors', metSi:'Alloy (මිශ්‍ර ලෝහ)', metEn:'Alloy' }
    };

    var WD = SI ? ['ඉ','ස','අ','බ','බ්‍ර','සි','සෙ'] : ['S','M','T','W','T','F','S'];
    var PC = { Su:'#f59e0b',Mo:'#94a3b8',Ma:'#ef4444',Me:'#10b981',Ju:'#eab308',Ve:'#ec4899',Sa:'#6366f1',Ra:'#a855f7',Ke:'#b45309',Ur:'#06b6d4',Ne:'#06b6d4',Pl:'#06b6d4' };
    var S = { c: null, day: null, clockTimer: null, installPrompt: null, scr: 'home' };

    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault(); S.installPrompt = e;
      var btn = E('kp-install-btn'); if (btn) btn.classList.add('show');
    });
    window.addEventListener('appinstalled', function () {
      S.installPrompt = null;
      var btn = E('kp-install-btn'); if (btn) btn.classList.remove('show');
      ok(function () { mnToast(T('✓ KP Astrology AI Pro ස්ථාපනය විය!', '✓ KP Astrology AI Pro installed!')); });
    });

    /* ---------- Time & KP Helpers ---------- */
    function today() {
      var n = new Date();
      return n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0');
    }
    function dms(deg) {
      var d = Math.floor(deg), mF = (deg - d) * 60, m = Math.floor(mF), s = Math.floor((mF - m) * 60);
      return d + '°' + String(m).padStart(2, '0') + "'" + String(s).padStart(2, '0') + '"';
    }
    function fmtLiveTime() {
      var n = new Date(), h = n.getHours(), m = String(n.getMinutes()).padStart(2, '0');
      var ap = SI ? (h >= 12 ? 'ප.ව.' : 'පෙ.ව.') : (h >= 12 ? 'PM' : 'AM');
      var h12 = (h % 12) || 12;
      var dStr = n.getFullYear() + '.' + String(n.getMonth() + 1).padStart(2, '0') + '.' + String(n.getDate()).padStart(2, '0');
      return { clock: SI ? (ap + ' ' + h12 + ':' + m) : (h12 + ':' + m + ' ' + ap), date: WK_FULL[n.getDay()] + ' ' + dStr };
    }
    function livePanchanga() {
      var now = new Date(), dow = now.getDay(), hr = now.getHours(), mn = now.getMinutes();
      var effDow = hr < 6 ? (dow + 6) % 7 : dow;
      var idx = (DAY_TO_HORA[effDow] + ((hr + 24 - 6) % 24)) % 7;
      return { dayLord: DAY_LORD[effDow], horaLord: HORA_SEQ[idx], horaLeft: (60 - mn) + 'm' };
    }
    function dayScore(x) {
      var g = kpDay(x);
      var r = TOP.map(function (t, i) { return PCT(g.segs.reduce(function (s, y) { return s + y.f[i] * (y.t1 - y.t0); }, 0) / 24); });
      return { g: g, r: r, avg: Math.round(r.reduce(function (a, b) { return a + b; }, 0) / r.length) };
    }
    function curDashaObj() {
      var now = Date.now() / 864e5 + 2440587.5;
      var f = function (x) { return now >= x[1] && now < x[1] + x[2]; };
      var m = mainL.find(f), a = m && kids(m).find(f), p = a && kids(a).find(f);
      return { names: [m, a, p].filter(Boolean).map(function (x) { return PLN[x[0]]; }), end: p ? dt(p[1] + p[2]) : (a ? dt(a[1] + a[2]) : '') };
    }
    function computePillars() {
      var _sg = ok(function () { return signif(c); });
      var sig = _sg && (_sg.out || _sg);
      if (!sig) return [];
      var defs = [
        [T('ධනය', 'Wealth'), 1, [2, 6, 10, 11], [5, 8, 12], 't17'],
        [T('රැකියාව', 'Career'), 9, [2, 6, 10, 11], [5, 8, 12], 't15'],
        [T('විවාහය', 'Marriage'), 6, [2, 7, 11], [1, 6, 10], 't8'],
        [T('අධ්‍යාපන', 'Education'), 3, [4, 9, 11], [3, 8, 12], 't5'],
        [T('විදේශ', 'Foreign'), 11, [3, 9, 12], [2, 4, 11], 't17'],
        [T('සෞඛ්‍යය', 'Health'), 0, [1, 5, 11], [6, 8, 12], 't14']
      ];
      return defs.map(function (df) {
        var cslCode = P[lords(c.cs[df[1]]).sl];
        var levels = sig[cslCode] || [[], [], [], [], []];
        var w = [4, 3, 2, 1.5, 1], pos = 0, neg = 0, tot = 0;
        levels.forEach(function (arr, li) {
          (arr || []).forEach(function (h) {
            tot += w[li];
            if (df[2].indexOf(h) !== -1) pos += w[li];
            if (df[3].indexOf(h) !== -1) neg += w[li];
          });
        });
        var pct = Math.max(18, Math.min(96, tot > 0 ? Math.round(50 + ((pos - neg) / (tot + 2)) * 55) : 50));
        return { label: df[0], pct: pct, csl: PLN[lords(c.cs[df[1]]).sl], tab: df[4] };
      });
    }
    function computeKPGems() {
      var _sg = ok(function () { return signif(c); });
      var sig = _sg && (_sg.out || _sg);
      if (!sig || !c || !c.cs || c.cs.length < 11) return null;
      function evalCsl(cuspIdx, labelSi, labelEn) {
        var slIdx = lords(c.cs[cuspIdx]).sl, code = P[slIdx], lv = sig[code] || [[], [], [], []], allH = [];
        [0, 1, 2, 3].forEach(function (i) { (lv[i] || []).forEach(function (h) { if (allH.indexOf(h) === -1) allH.push(h); }); });
        allH.sort(function (a, b) { return a - b; });
        var bad = allH.filter(function (h) { return h === 6 || h === 8 || h === 12; });
        return { cusp: cuspIdx + 1, label: SI ? labelSi : labelEn, code: code, meta: KP_GEMS[code], houses: allH, bad: bad, ok: bad.length === 0 };
      }
      var c1 = evalCsl(0, '1 වන භාව උප-අධිපති (ලග්න)', '1st Cusp Sub-Lord (Lagna)');
      var c11 = evalCsl(10, '11 වන භාව උප-අධිපති (ලාභ)', '11th Cusp Sub-Lord (Gains)');
      var eligible = [];
      if (c1.ok && c11.ok && c1.code === c11.code) { c1.both = true; eligible.push(c1); }
      else { if (c1.ok) eligible.push(c1); if (c11.ok) eligible.push(c11); }
      return { c1: c1, c11: c11, eligible: eligible };
    }

    /* ==========================================================================
       TRUE MULTI-SCREEN ROUTER (home | form | horary | profiles | settings | page)
       ========================================================================== */
    var SCR_TITLES = {
      form:     '🪐 ' + T('ජන්ම පත්‍රය සාදන්න', 'New Birth Chart'),
      horary:   '🔮 ' + T('KP Horary (1–249)', 'KP Horary (1–249)'),
      profiles: '👥 ' + T('සුරැකි කේන්දර', 'Saved Charts'),
      settings: '⚙️ ' + T('සැකසුම් (Ayanamsha)', 'Settings & Ayanamsha')
    };

    function updateResumePill() {
      var p = E('kp-resume-pill');
      if (!p) return;
      if (c) {
        var nm = (E('nm') && E('nm').value.trim()) || T('ජන්ම පත්‍රය', 'Birth Chart');
        var lg = Math.floor(c.cs[0] / 30);
        p.innerHTML = '<span>📋 ' + T('දැන් පත්‍රය: ', 'Active Chart: ') + '<b>' + esc(nm) + ' (' + SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°)</b></span><b>➜</b>';
        p.classList.add('show');
      } else {
        p.classList.remove('show');
      }
    }

    function goScr(name, fromPop) {
      var prev = S.scr;
      S.scr = name;
      document.body.setAttribute('data-scr', name);
      if (name === 'page') document.body.classList.add('rv');
      else document.body.classList.remove('rv');

      var tEl = E('kp-scr-title');
      if (tEl && SCR_TITLES[name]) tEl.textContent = SCR_TITLES[name];

      if (name === 'horary') syncHoraryLoc();
      if (name === 'home') updateResumePill();

      if (!fromPop && name !== 'home' && prev === 'home') {
        try { history.pushState({ scr: name }, ''); } catch (e) {}
      }
      window.scrollTo(0, 0);
    }

    function openPage(tabId) {
      if (!c) return;
      var target = tabId === 'kpPlus' ? 't14' : (tabId || 't1');
      ok(buildSum);
      goScr('page', false);
      barState(target);
      window.scrollTo(0, 0);
    }

    function onPop() {
      if (S.scr !== 'home') {
        goScr('home', true);
      }
    }

    window.kpGoScr = goScr;
    window.kpOpenPage = openPage;
    window.kpOnPop = onPop;

    /* ==========================================================================
       DEDICATED SCREEN 1..5 BUILDERS (Isolate Form, Horary, Profiles, Settings!)
       ========================================================================== */
    var SVG_CHART = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 12h18M12 3v18M12 3l9 9-9 9-9-9z"/></svg>';
    var SVG_AI = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="6" width="16" height="12" rx="3"/><path d="M12 2v4M9 11h.01M15 11h.01M9 15h6"/></svg>';
    var SVG_HORARY = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4M12 17h.01"/></svg>';
    var SVG_RP = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';
    var SVG_PROF = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';
    var SVG_SET = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.26.6.85 1 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';

    function syncHoraryLoc() {
      var el = E('kh-loc-txt');
      if (!el) return;
      if (E('dt') && !E('dt').value && E('now')) E('now').click();
      if (E('la') && !E('la').value) {
        E('la').value = '6.9271'; E('lo').value = '79.8612'; E('tz').value = '5.5';
        if (E('pl')) E('pl').value = 'Colombo';
      }
      var pl = (E('pl') && E('pl').value) || 'Colombo';
      var dtS = (E('dt') && E('dt').value) || today();
      var tmS = (E('tm') && E('tm').value) || '';
      el.textContent = '📍 ' + pl + ' · ' + dtS + ' ' + tmS;
    }

    function castNowAndOpen(targetTab) {
      if (E('now')) E('now').click();
      if (E('la') && !E('la').value) { E('la').value = '6.9271'; E('lo').value = '79.8612'; E('tz').value = '5.5'; if (E('pl')) E('pl').value = 'Colombo'; }
      if (E('b1')) E('b1').click();
      setTimeout(function () {
        if (c) {
          if (targetTab && targetTab !== 't1') nvB(targetTab, '');
          openPage(targetTab || 't1');
        }
      }, 150);
    }

    function buildScreens() {
      var tp = E('tp');
      if (!tp || E('kp-home')) return;

      // 1. Sub-Screen Back Header Bar (shared by form / horary / profiles / settings)
      var sb = document.createElement('div');
      sb.id = 'kp-scr-bar';
      sb.innerHTML = '<button type="button" id="kp-scr-back">← ' + T('මුල් පිටුව', 'Home') + '</button><span id="kp-scr-title"></span>';
      tp.insertAdjacentElement('afterend', sb);
      E('kp-scr-back').onclick = function () {
        if (history.state && history.state.scr) history.back();
        else goScr('home', true);
      };

      // 2. Clean 1-Screen Home Dashboard (#kp-home)
      var lt = fmtLiveTime(), pn = livePanchanga();
      var hm = document.createElement('div');
      hm.id = 'kp-home';
      hm.innerHTML =
        '<div class="kb-hero">' +
          '<div class="kb-hero-row">' +
            '<button type="button" class="kb-gold-pill" id="kw-now">' +
              '<small>' + T('ක්ෂණික KP ගණනය', 'Quick KP Chart') + '</small>' +
              '<b>⚡ ' + T('දැන් වේලාවෙන් පත්‍රය', 'Instant Chart Now') + '</b>' +
            '</button>' +
            '<div class="kb-clock"><b id="kw-clk">' + lt.clock + '</b><small>' + lt.date + '</small></div>' +
          '</div>' +
          '<div class="kb-ticker">' +
            '<div class="kb-ticker-main"><span class="kb-dot r"></span>' + T('දින අධිපති: ', 'Day: ') + '<b>' + pn.dayLord + '</b> · <span class="kb-dot b"></span>' + T('හෝරාව: ', 'Hora: ') + '<b>' + pn.horaLord + '</b> · <span class="kb-dot g"></span>' + T('100% නොමිලේ', '100% Free') + '</div>' +
            '<div class="kb-ticker-r">KP<br>Offline</div>' +
          '</div>' +
        '</div>' +

        '<button type="button" id="kp-resume-pill"></button>' +
        '<button type="button" id="kp-install-btn">📲 ' + T('ඇප් එක දුරකථනයට ස්ථාපනය කරන්න', 'Install KP AI Pro App') + '</button>' +

        '<div class="kb-grid">' +
          '<button type="button" class="kb-tile" id="hm-form">' +
            '<div class="kb-tile-top"><span class="kb-badge rose">' + T('ජන්ම පත්‍රය', 'KUNDALI') + '</span>' + SVG_CHART + '</div>' +
            '<div><span class="kb-tile-t">' + T('ජන්ම පත්‍රය', 'KP Birth Chart') + '</span><span class="kb-tile-s">' + T('ලග්න, භාව, දශා & පලාපල', 'Lagna, Cusps & Dasha') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-hor">' +
            '<div class="kb-tile-top"><span class="kb-badge blue">1–249</span>' + SVG_HORARY + '</div>' +
            '<div><span class="kb-tile-t">' + T('KP Horary', 'KP Horary') + '</span><span class="kb-tile-s">' + T('ප්‍රශ්න අංකයෙන් පිළිතුරු', 'Question Number 1–249') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-rp">' +
            '<div class="kb-tile-top"><span class="kb-badge teal">LIVE</span>' + SVG_RP + '</div>' +
            '<div><span class="kb-tile-t">' + T('Ruling Planets', 'Ruling Planets') + '</span><span class="kb-tile-s">' + T('දැන් පාලක ග්‍රහයන්', 'Instant Ruling Planets') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-ai">' +
            '<div class="kb-tile-top"><span class="kb-badge purp">AI</span>' + SVG_AI + '</div>' +
            '<div><span class="kb-tile-t">' + T('KP AI ගුරු', 'KP AI Guru') + '</span><span class="kb-tile-s">' + T('ප්‍රශ්න අසන්න · Offline', 'Ask Anything · Offline') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-prof">' +
            '<div class="kb-tile-top"><span class="kb-badge amb">' + T('සුරැකි', 'SAVED') + '</span>' + SVG_PROF + '</div>' +
            '<div><span class="kb-tile-t">' + T('සුරැකි කේන්දර', 'Saved Charts') + '</span><span class="kb-tile-s">' + T('පැතිකඩ & Backup', 'Profiles & Backup') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-set">' +
            '<div class="kb-tile-top"><span class="kb-badge slat">KP</span>' + SVG_SET + '</div>' +
            '<div><span class="kb-tile-t">' + T('සැකසුම්', 'Settings') + '</span><span class="kb-tile-s">' + T('Ayanamsha & භාෂාව', 'Ayanamsha & Theme') + '</span></div>' +
          '</button>' +
        '</div>' +

        '<div class="kb-devfoot">' +
          '<div><small>Developed by</small><b>W. Vihanga Rasanjana Withanage</b></div>' +
          '<button type="button" id="kp-appshare">📤 ' + T('බෙදාගන්න', 'Share') + '</button>' +
        '</div>';

      sb.insertAdjacentElement('afterend', hm);

      // 3. Dedicated Horary Screen (#kp-scr-horary) — Move Horary controls out of birth form!
      var formCard = $$('body > .card').find(function (el) { return $$('.sec', el).length >= 3; });
      var horScr = document.createElement('div');
      horScr.id = 'kp-scr-horary';
      horScr.className = 'card';
      horScr.innerHTML =
        '<h3>🔮 ' + T('KP Horary (ප්‍රශ්න අංකය 1–249)', 'KP Horary (Question Number 1–249)') + '</h3>' +
        '<div class="kh-loc"><span id="kh-loc-txt"></span><button type="button" id="kh-now-btn">⏱ ' + T('දැන්', 'Now') + '</button></div>' +
        '<div id="kh-mount"></div>';
      hm.insertAdjacentElement('afterend', horScr);

      // 4. Dedicated Settings Screen (#kp-scr-settings) — Move Ayanamsha controls out of birth form!
      var setScr = document.createElement('div');
      setScr.id = 'kp-scr-settings';
      setScr.className = 'card';
      setScr.innerHTML =
        '<h3>⚙️ ' + T('Ayanamsha සහ ඇප් සැකසුම්', 'Ayanamsha & App Settings') + '</h3>' +
        '<div id="ks-mount"></div>' +
        '<div class="kh-row" style="margin-top:12px">' +
          '<button type="button" id="ks-lang">🌐 ' + T('ඉංග්‍රීසි (EN)', 'සිංහල (SI)') + '</button>' +
          '<button type="button" id="ks-theme">🌗 ' + T('තේමාව මාරු කරන්න', 'Toggle Theme') + '</button>' +
        '</div>';
      horScr.insertAdjacentElement('afterend', setScr);

      // Relocate Horary <details> and Ayanamsha <details> cleanly from Birth Form into their own dedicated screens!
      if (formCard) {
        $$('details.adv', formCard).forEach(function (det) {
          if (det.querySelector('#hb')) {
            var hmMount = E('kh-mount');
            Array.prototype.slice.call(det.childNodes).forEach(function (nd) {
              if (nd.nodeType === 1 && nd.tagName === 'SUMMARY') return;
              hmMount.appendChild(nd);
            });
            det.remove();
            // Style Horary buttons cleanly in a row
            var hb = E('hb');
            if (hb) {
              hb.className = 'p';
              var row = document.createElement('div'); row.className = 'kh-row';
              var rb = document.createElement('button'); rb.type = 'button'; rb.id = 'kp-rand-hn';
              rb.textContent = '🎲 ' + T('අහඹු (1–249)', 'Random 1–249');
              rb.onclick = function () {
                var n = Math.floor(Math.random() * 249) + 1;
                if (E('hn')) E('hn').value = n;
                if (E('now')) E('now').click();
                syncHoraryLoc();
                mnToast(T('🎲 KP Horary අංකය: ', '🎲 KP Horary Number: ') + n);
              };
              hb.parentNode.insertBefore(row, hb);
              row.appendChild(rb);
              row.appendChild(hb);
            }
          } else if (det.querySelector('#ay')) {
            var smMount = E('ks-mount');
            Array.prototype.slice.call(det.childNodes).forEach(function (nd) {
              if (nd.nodeType === 1 && nd.tagName === 'SUMMARY') return;
              smMount.appendChild(nd);
            });
            det.remove();
          }
        });
      }

      // Wire Home & Settings buttons
      E('kw-now').onclick = function () { castNowAndOpen('t1'); };
      E('hm-form').onclick = function () { goScr('form'); };
      E('hm-hor').onclick = function () { goScr('horary'); };
      E('hm-rp').onclick = function () { castNowAndOpen('t16'); };
      E('hm-ai').onclick = function () { if (!c) castNowAndOpen('t18'); else { nvB('t18', ''); openPage('t18'); } };
      E('hm-prof').onclick = function () { goScr('profiles'); };
      E('hm-set').onclick = function () { goScr('settings'); };
      E('kp-resume-pill').onclick = function () { if (c) openPage(curTab || 't1'); };
      E('kh-now-btn').onclick = function () { if (E('now')) E('now').click(); syncHoraryLoc(); mnToast(T('දැන් වේලාව සකසා ගති', 'Updated to current time')); };
      E('ks-lang').onclick = function () { if (E('lgb')) E('lgb').click(); };
      E('ks-theme').onclick = function () { if (E('th')) E('th').click(); };
      E('kp-appshare').onclick = function () {
        var txt = T('✦ KP Astrology AI Pro — ක්‍රිෂ්ණමූර්ති පද්ධති ජන්ම පත්‍රය, KP AI ගුරු සහ ජීවිත පලාපල!', '✦ KP Astrology AI Pro — Birth Chart, KP AI Guru & Life Predictions!');
        if (navigator.share) navigator.share({ title: 'KP Astrology AI Pro', text: txt, url: location.href }).catch(function () {});
        else window.open('https://wa.me/?text=' + encodeURIComponent(txt + ' ' + location.href), '_blank');
      };

      if (S.installPrompt) E('kp-install-btn').classList.add('show');
      E('kp-install-btn').onclick = function () {
        if (!S.installPrompt) return;
        S.installPrompt.prompt();
        S.installPrompt.userChoice.finally(function () { S.installPrompt = null; E('kp-install-btn').classList.remove('show'); });
      };
    }

    /* ==========================================================================
       SCREEN 6: SLIM 1-LINE CHART STRIP (#ksum) + DEDICATED KP GEMS PAGE (t19)
       ========================================================================== */
    function buildSum() {
      var res = E('res'); if (!res || !c) return;
      var d = ok(function () { return dayScore(today()); });
      var lg = Math.floor(c.cs[0] / 30), lgDeg = Math.floor(c.cs[0] % 30);
      var ds = ok(curDashaObj) || { names: [] };
      var nm = (E('nm') && E('nm').value.trim()) || T('ජන්ම පත්‍රය', 'Birth Chart');
      var avg = d ? d.avg : 50;
      var scCls = avg >= 55 ? 'sc-ok' : avg >= 40 ? 'sc-mid' : 'sc-bad';

      var card = E('ksum');
      if (!card) {
        card = document.createElement('div');
        card.id = 'ksum';
        res.insertBefore(card, E('nv') || res.firstChild);
      }

      card.innerHTML =
        '<div class="kp-mini-bar">' +
          '<div class="kp-mini-info">' +
            '<div class="kp-mini-l1">👤 ' + esc(nm) + ' · <b>' + SGN[lg] + ' ' + lgDeg + '°</b></div>' +
            '<div class="kp-mini-l2">' + T('දශාව: ', 'Dasha: ') + (ds.names.join('-') || '—') + ' · <span class="' + scCls + '">' + T('අද ', 'Today ') + avg + '%</span></div>' +
          '</div>' +
          '<div class="kp-mini-acts">' +
            '<button type="button" id="kmini-gem" title="' + T('KP මැණික් & පාට', 'KP Gems & Colors') + '">💎</button>' +
            '<button type="button" id="kmini-sh" title="WhatsApp">📤</button>' +
            '<button type="button" id="kmini-ed" title="' + T('උපන් විස්තර වෙනස් කරන්න', 'Edit Birth Data') + '">✏️</button>' +
          '</div>' +
        '</div>';

      E('kmini-gem').onclick = function () { nvB('t19', ''); openPage('t19'); };
      E('kmini-sh').onclick = share;
      E('kmini-ed').onclick = function () { goScr('form'); };

      S.day = d;
      updateResumePill();
    }

    // Dedicated Page t19: KP Gems, Colors & Metals (1st & 11th CSL) + 6-Pillar CSL Promise + Key Summary
    window.kpGemsTab = function () {
      var el = E('t19');
      if (!el || !c) return;
      var lg = Math.floor(c.cs[0] / 30), lgDeg = dms(c.cs[0] % 30), lgL = ok(function () { return lords(c.cs[0]); });
      var mo = c.pl.Mo, mn = Math.floor(mo / 30), moL = ok(function () { return lords(mo); });
      var nk = Math.floor(mo / (40 / 3)), pd = Math.floor((mo / (40 / 3) % 1) * 4) + 1;
      var ds = ok(curDashaObj) || { names: [], end: '' };
      var pillars = ok(computePillars) || [];
      var kpGems = ok(computeKPGems);

      el.innerHTML =
        '<h3>💎 ' + T('KP මැණික්, සුබ වර්ණ, ලෝහ & සාරාංශය', 'KP Gems, Colors, Metals & Summary') + '</h3>' +
        '<div class="kl-grid">' +
          '<div class="kl-box"><small>' + T('ලග්නය (RL / NL / SL / SSL)', 'LAGNA CHAIN') + '</small><b>' + SGN[lg] + ' ' + lgDeg + '</b><small>' + (lgL ? PLN[lgL.rl] + ' · ' + PLN[lgL.nl] + ' · ' + PLN[lgL.sl] + ' · ' + PLN[lgL.ssl] : '') + '</small></div>' +
          '<div class="kl-box"><small>' + T('චන්ද්‍ර රාශිය & නැකත', 'MOON & NAKSHATRA') + '</small><b>' + SGN[mn] + ' · ' + NKN[nk % 27] + '</b><small>' + T('පාදය ', 'Pada ') + pd + (moL ? ' · SSL ' + PLN[moL.ssl] : '') + '</small></div>' +
          '<div class="kl-box" style="grid-column:1/-1"><small>' + T('දැන් පවතින දශාව (DBA)', 'RUNNING DASHA (DBA)') + '</small><b style="color:var(--ac)">' + (ds.names.join(' → ') || '—') + '</b>' + (ds.end ? '<small>' + T('අවසන්: ', 'Until: ') + ds.end + '</small>' : '') + '</div>' +
        '</div>' +

        (kpGems ? '<div class="kb-subhd">💎 ' + T('KP මැණික්, සුබ වර්ණ & ලෝහ (1 / 11 උප-අධිපති)', 'KP Gems, Colors & Metals (1st / 11th CSL)') + '</div>' +
          '<div class="kl-grid">' +
            [kpGems.c1, kpGems.c11].map(function (it) {
              return '<div class="kl-box"><small>' + it.label + '</small>' +
                '<b style="color:' + (it.ok ? 'var(--hl)' : 'var(--hn)') + '">' + (SI ? it.meta.si : it.meta.en) + ' — ' + (it.ok ? T('✅ සුදුසුයි', '✅ Eligible') : T('❌ නුසුදුසුයි', '❌ Avoid')) + '</b>' +
                '<small style="margin-top:2px">' + T('භාව: ', 'Houses: ') + (it.houses.join(', ') || '—') + (it.bad.length ? ' (' + T('6/8/12 ඇත: ', 'Has: ') + it.bad.join(',') + ')' : '') + '</small>' +
              '</div>';
            }).join('') +
          '</div>' +
          (kpGems.eligible.length
            ? kpGems.eligible.map(function (it) {
                var m = it.meta;
                return '<div class="kl-rec">' +
                  '<div class="kl-rec-hd">✨ ' + (SI ? m.si : m.en) + ' (' + (it.both ? T('1 සහ 11 භාව උප-අධිපති', '1st & 11th CSL') : (it.cusp === 1 ? T('1 වන භාව උප-අධිපති', '1st CSL') : T('11 වන භාව උප-අධිපති', '11th CSL'))) + ')</div>' +
                  '<div class="kl-grid">' +
                    '<div class="kl-box"><small>💎 ' + T('සුදුසු මැණික', 'Gemstone') + '</small><b style="color:var(--pl)">' + (SI ? m.gemSi : m.gemEn) + '</b></div>' +
                    '<div class="kl-box"><small>🎨 ' + T('ග්‍රහයාට අයත් පාට', 'Color') + '</small><b>' + (SI ? m.colSi : m.colEn) + '</b></div>' +
                    '<div class="kl-box" style="grid-column:1/-1"><small>⚙️ ' + T('පාලනය කරන ලෝහය', 'Metal Ruled') + '</small><b>' + (SI ? m.metSi : m.metEn) + '</b></div>' +
                  '</div>' +
                '</div>';
              }).join('')
            : '<div class="kl-warn">⚠️ ' + T('මෙම ජන්ම පත්‍රයේ 1 වන සහ 11 වන උප-අධිපතීන් දෙදෙනාම 6, 8 හෝ 12 භාව සම්බන්ධ කරන බැවින්, ක්‍රිෂ්ණමූර්ති (KP) සිද්ධාන්තය අනුව මැණික් පැළඳීම නිර්දේශ නොකෙරේ.', 'Both 1st and 11th Cuspal Sub-Lords signify 6, 8, or 12 in this chart, so KP rules advise against wearing a gemstone.') + '</div>') +
          '<div class="kl-note">' + T('KP සිද්ධාන්තය: මැණිකක් පැළඳීමට සුදුසු වන්නේ 1 වන හෝ 11 වන භාව උප-අධිපති 6, 8, 12 භාව ලබා නොදෙන්නේ නම් පමණි.', 'KP Rule: A gemstone is recommended ONLY for the 1st or 11th Cuspal Sub-Lord, and strictly if it does NOT signify 6, 8, or 12.') + '</div>' : '') +

        (pillars.length ? '<div class="kb-subhd">✦ ' + T('ප්‍රධාන භාව උප-අධිපති පොරොන්දුව (CSL)', 'KP Cuspal Sub-Lord Promise') + '</div>' +
          '<div class="kp-pgrid">' +
            pillars.map(function (pl) {
              var cls = pl.pct >= 60 ? 'ok' : pl.pct >= 42 ? 'mid' : 'bad';
              var bg = pl.pct >= 60 ? '#10b981' : pl.pct >= 42 ? '#38bdf8' : '#f43f5e';
              return '<div class="kp-pitem" data-ptab="' + pl.tab + '">' +
                '<span class="plb">' + pl.label + ' (' + pl.csl + ')</span>' +
                '<span class="pval ' + cls + '">' + pl.pct + '%</span>' +
                '<div class="pbar"><i style="width:' + pl.pct + '%;background:' + bg + '"></i></div>' +
              '</div>';
            }).join('') +
          '</div>' : '');

      $$('.kp-pitem', el).forEach(function (it) {
        it.onclick = function () { var pt = it.dataset.ptab, qf = pt === 't14' ? 'kpPlus' : ''; nvB(pt, qf); openPage(pt); };
      });
    };

    /* ---------- WhatsApp Share Card ---------- */
    function share() {
      var go = function () { ok(drawShare); };
      if (document.fonts && document.fonts.load) document.fonts.load('700 40px "Noto Sans Sinhala"').then(go, go);
      else go();
    }
    function drawShare() {
      var W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      var x = cv.getContext('2d'), F = '"Noto Sans Sinhala","Inter",system-ui,sans-serif';
      var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#060d14'); g.addColorStop(1, '#0c2436');
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      var d = S.day || dayScore(today()), nm = (E('nm') && E('nm').value) || '', lg = Math.floor(c.cs[0] / 30), mn = Math.floor(c.pl.Mo / 30), nk = Math.floor(c.pl.Mo / (40 / 3)) % 27;
      function tx(s, px, py, sz, col, w, al, mx) {
        x.font = (w || 600) + ' ' + sz + 'px ' + F; x.fillStyle = col; x.textAlign = al || 'left'; s = String(s);
        if (mx) while (x.measureText(s).width > mx && s.length > 2) s = s.slice(0, -2);
        x.fillText(s, px, py);
      }
      tx('✦ KP ASTROLOGY AI PRO', 60, 100, 44, '#38bdf8', 800);
      tx(today() + (nm ? '  ·  ' + nm : ''), 60, 158, 30, '#82a4b8', 500, 'left', 960);
      var cx = 215, cy = 380, r = 118, p = d.avg, col = p >= 55 ? '#10b981' : p >= 40 ? '#38bdf8' : '#f43f5e';
      x.lineWidth = 22; x.lineCap = 'round'; x.strokeStyle = 'rgba(125,211,252,0.18)'; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.stroke();
      x.strokeStyle = col; x.beginPath(); x.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p / 100); x.stroke();
      tx(p + '%', cx, cy + 22, 62, '#eef7fb', 700, 'center');
      tx(T('අද ලකුණු', 'TODAY'), cx, cy + r + 58, 28, '#82a4b8', 600, 'center');
      var ds = ok(curDashaObj) || { names: [] };
      var rows = [
        [T('ලග්නය', 'Lagna'), SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°'],
        [T('චන්ද්‍ර රාශිය', 'Moon'), SGN[mn]],
        [T('නැකත', 'Nakshatra'), NKN[nk]],
        [T('දශාව', 'Dasha'), ds.names.join(' - ') || '—']
      ];
      rows.forEach(function (r2, i) { var y = 290 + i * 58; tx(r2[0], 440, y, 26, '#82a4b8', 500); tx(r2[1], 650, y, 30, '#eef7fb', 700, 'left', 370); });
      tx(T('අද ප්‍රබල ක්ෂේත්‍ර', 'TOP FIELDS TODAY'), 60, 640, 34, '#38bdf8', 800);
      var top = d.r.map(function (v, i) { return [v, i]; }).sort(function (a, b) { return b[0] - a[0]; }).slice(0, 6);
      top.forEach(function (t, i) {
        var y = 705 + i * 86;
        tx(TOP[t[1]][0], 60, y, 30, '#eef7fb', 500, 'left', 550);
        x.fillStyle = 'rgba(125,211,252,0.16)'; x.fillRect(640, y - 24, 240, 16);
        x.fillStyle = t[0] >= 55 ? '#10b981' : t[0] >= 40 ? '#38bdf8' : '#f43f5e';
        x.fillRect(640, y - 24, 240 * t[0] / 100, 16);
        tx(t[0] + '%', 1020, y, 28, '#eef7fb', 700, 'right');
      });
      tx(T('ක්‍රිෂ්ණමූර්ති පද්ධතිය (KP) අනුව ගණනය කරන ලදී', 'Calculated with Krishnamurti Paddhati (KP)'), W / 2, H - 48, 24, '#648599', 500, 'center');
      cv.toBlob(function (b) {
        if (!b) return;
        var f; try { f = new File([b], 'kp-ai-pro-forecast.png', { type: 'image/png' }); } catch (e) {}
        var dl = function () {
          var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'kp-ai-pro-forecast.png';
          document.body.appendChild(a); a.click(); a.remove();
          mnToast(T('පින්තූරය සුරැකිණි — WhatsApp එකෙන් යවන්න', 'Image saved — share on WhatsApp'));
        };
        if (f && navigator.canShare && navigator.canShare({ files: [f] })) {
          navigator.share({ files: [f], title: 'KP Astrology AI Pro' }).catch(function (e) { if (!e || e.name !== 'AbortError') dl(); });
        } else dl();
      }, 'image/png');
    }

    /* ---------- Fixed Bottom Icon Bar (Like Classic KP App — 6 Crisp Icons) ---------- */
    function buildBar() {
      var b = document.createElement('nav'); b.id = 'kbar';
      var it = [
        ['🏠', T('මුල්', 'Home'), '__home'],
        ['🪐', T('ලග්න', 'Lagna'), 't1'],
        ['⭐', 'Signif.', 't3'],
        ['⏳', T('පලාපල', 'Dasha'), 't5'],
        ['🌟', T('ජීවිත', 'Life'), 't17'],
        ['🤖', 'AI', 't18']
      ];
      b.innerHTML = it.map(function (x) { return '<button data-t="' + x[2] + '"><i>' + x[0] + '</i>' + x[1] + '</button>'; }).join('');
      b.onclick = function (e) {
        var q = e.target.closest('button'); if (!q) return;
        var t = q.dataset.t;
        if (t === '__home') { goScr('home'); return; }
        if (!c) { goScr('form'); return; }
        nvB(t, '');
        openPage(t);
      };
      document.body.appendChild(b);
    }
    function barState(t) {
      $$('#kbar button').forEach(function (b) { b.classList.toggle('on', !!b.dataset.t && b.dataset.t === t); });
    }

    /* ---------- Clean Vertical "Choose Sections" Drawer (#dw) ---------- */
    var ICO = { t1:'🪐',t2:'📐',t3:'⭐',t4:'⏳',t9:'🕰️',t5:'🔮',t12:'📊',t6:'🌍',t7:'🍀',t15:'💼',t8:'💍',t10:'📅',t11:'📜',t16:'🔱',t13:'🎯',t17:'🌟',t18:'🤖',t19:'💎',pdf:'📄',kpPlus:'🧰' };
    function tiles() {
      var pn = E('dw') && E('dw').querySelector('.pn');
      if (!pn) return;
      // Add top "🏠 මුල් පිටුව" button inside drawer once
      if (!pn.querySelector('.dw-home-btn')) {
        var ph = pn.querySelector('.ph');
        var hb = document.createElement('button');
        hb.type = 'button'; hb.className = 'dw-home-btn';
        hb.innerHTML = '<span class="ti">🏠</span><span>' + T('මුල් පිටුව (Home)', 'Home Dashboard') + '</span>';
        hb.onclick = function () { mnC(); goScr('home'); };
        if (ph) ph.insertAdjacentElement('afterend', hb);
      }
      $$('button[onclick^="mnB"]', pn).forEach(function (b) {
        if (b.querySelector('.ti')) return;
        var m = /mnB\('([^']*)','([^']*)'\)/.exec(b.getAttribute('onclick') || '');
        var k = m && (m[1] || m[2]), tx = b.textContent.trim().replace(/\s*🔒\s*$/, '');
        var em = /^(\p{Extended_Pictographic}\uFE0F?)\s*/u.exec(tx), ic = em ? em[1] : (ICO[k] || '✦');
        if (em) tx = tx.slice(em[0].length);
        b.innerHTML = '<span class="ti">' + ic + '</span><span>' + tx + '</span>';
      });
    }

    /* ---------- Tables, Charts (South/North + Zoom), 42-Day Heatmap, Chips, Wizard ---------- */
    var RX = /^(AS|Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)(\(R\))?$/;
    function tables(root) {
      if (!root) return;
      $$('table', root).forEach(function (t) {
        if (!t.parentNode.classList.contains('tw')) {
          var w = document.createElement('div'); w.className = 'tw'; t.parentNode.insertBefore(w, t); w.appendChild(t);
        }
        if (t.dataset.kDone === String(t.rows.length)) return;
        t.dataset.kDone = String(t.rows.length);
        $$('td', t).forEach(function (td) {
          if (td.dataset.k) return; td.dataset.k = 1;
          var m = RX.exec(td.textContent.trim());
          if (m && td.children.length === 0) td.innerHTML = '<span class="pc pc-' + m[1] + '">' + m[1] + (m[2] ? '<sup>R</sup>' : '') + '</span>';
        });
      });
    }

    var SPOS = { 11:[0,0],0:[1,0],1:[2,0],2:[3,0],10:[0,1],3:[3,1],9:[0,2],4:[3,2],8:[0,3],7:[1,3],6:[2,3],5:[3,3] };
    function paint(sv) {
      $$('text', sv).forEach(function (t) {
        var m = /^(Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)/.exec(t.textContent);
        if (m && t.getAttribute('fill') !== 'var(--hn)') t.style.fill = PC[m[1]];
      });
    }
    function south() {
      var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 400 400'); s.setAttribute('class', 'ks');
      var lg = Math.floor(c.cs[0] / 30), by = {}, h = '<g fill="none" stroke="rgba(125,211,252,0.34)">';
      Object.keys(c.pl).forEach(function (p) { var sg = Math.floor(c.pl[p] / 30); (by[sg] = by[sg] || []).push([p, Math.floor(c.pl[p] % 30), !!(c.rt[p] || p == 'Ra' || p == 'Ke')]); });
      for (var sg = 0; sg < 12; sg++) { var q = SPOS[sg]; h += '<rect x="' + (q[0] * 100) + '" y="' + (q[1] * 100) + '" width="100" height="100"' + (sg == lg ? ' stroke="#38bdf8" stroke-width="2.8"' : '') + '/>'; }
      h += '</g>';
      for (sg = 0; sg < 12; sg++) {
        q = SPOS[sg]; var x0 = q[0] * 100 + 7, y0 = q[1] * 100;
        h += '<text x="' + (x0 + 86) + '" y="' + (y0 + 14) + '" text-anchor="end" fill="#82a4b8" style="font-size:9px;font-weight:500">' + SGN[sg].slice(0, 3) + '</text>';
        var L = (sg == lg ? [['As', null, 0]] : []).concat(by[sg] || []);
        L.forEach(function (e, i) {
          h += '<text x="' + x0 + '" y="' + (y0 + 30 + i * 14) + '" fill="' + (e[0] == 'As' ? '#38bdf8' : (PC[e[0]] || '#eef7fb')) + '" style="font-size:12px;font-weight:700">' + e[0] + (e[2] ? '*' : '') + (e[1] != null && e[0] != 'As' ? ' ' + e[1] : '') + '</text>';
        });
      }
      h += '<text x="200" y="196" text-anchor="middle" fill="#38bdf8" style="font-size:14px;font-weight:800">' + T('රාශි සටහන', 'Rasi Chart') + '</text>';
      h += '<text x="200" y="216" text-anchor="middle" fill="#82a4b8" style="font-size:11px;font-weight:500">' + SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°</text>';
      s.innerHTML = h; return s;
    }
    function charts() {
      var t1 = E('t1');
      if (t1 && c) {
        var sv = t1.querySelector('svg:not(.ks)');
        if (sv && !t1.querySelector('.kct')) {
          var bar = document.createElement('div'); bar.className = 'kct';
          bar.innerHTML = '<button data-s="S">▦ South (KP)</button><button data-s="N">◇ North</button>';
          sv.parentNode.insertBefore(bar, sv); var so = south(); sv.parentNode.insertBefore(so, sv.nextSibling);
          var ap = function (m) { sv.style.display = m == 'S' ? 'none' : ''; so.style.display = m == 'S' ? '' : 'none'; $$('button', bar).forEach(function (b) { b.className = b.dataset.s == m ? 'p' : ''; }); };
          bar.onclick = function (e) { var b = e.target.closest('button'); if (!b) return; try { localStorage.setItem('kpCs', b.dataset.s); } catch (x) {} ap(b.dataset.s); };
          ap((function () { try { return localStorage.getItem('kpCs') || 'S'; } catch (x) { return 'S'; } })());
        }
      }
      $$('.tab svg').forEach(function (sv) {
        if (sv.dataset.k || sv.getAttribute('viewBox') !== '0 0 400 400') return;
        sv.dataset.k = 1; paint(sv);
        sv.addEventListener('click', function () {
          var z = E('czm');
          if (!z) { z = document.createElement('div'); z.id = 'czm'; z.onclick = function () { z.classList.remove('on'); }; document.body.appendChild(z); }
          z.innerHTML = '<i>✕</i>'; var cl = sv.cloneNode(true); cl.style.display = ''; cl.removeAttribute('class'); z.appendChild(cl); z.classList.add('on');
        });
      });
    }

    var HM = { c: null, d: {}, busy: 0 };
    function days42() { var n = new Date(), a = []; for (var i = 0; i < 42; i++) a.push(new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate() + i)).toISOString().slice(0, 10)); return a; }
    function heatRender() {
      var box = E('khm'); if (!box) return;
      var ds = days42(), v = ds.map(function (x) { return HM.d[x]; }).filter(function (z) { return z != null; });
      var mn = Math.min.apply(0, v), mx = Math.max.apply(0, v), first = new Date(ds[0] + 'T00:00:00Z').getUTCDay();
      var h = '<h3>' + T('දින 42 සුබ-අසුබ සිතියම', '42-Day KP Heatmap') + '</h3><div class="khw">' + WD.map(function (w) { return '<i>' + w + '</i>'; }).join('');
      for (var i = 0; i < first; i++) h += '<b class="e"></b>';
      ds.forEach(function (x, i) {
        var s = HM.d[x]; if (s == null) { h += '<b class="sk"></b>'; return; }
        var t = mx > mn ? (s - mn) / (mx - mn) : 0.5;
        h += '<b class="' + (i == 0 ? 'td' : '') + '" data-d="' + x + '" data-v="' + s + '" style="background:hsl(' + Math.round(4 + 145 * t) + ' 65% var(--kl))">' + (+x.slice(8)) + '<small>' + s + '%</small></b>';
      });
      box.innerHTML = h + '</div><div class="khl"><span>' + T('අඩු', 'Low') + '</span><i></i><span>' + T('ඉහළ', 'High') + '</span></div>';
    }
    function heat() {
      var t7 = E('t7'); if (!t7 || t7.style.display !== 'block' || !c) return;
      if (!E('khm')) {
        var b = document.createElement('div'); b.id = 'khm'; b.className = 'card';
        b.onclick = function (e) { var q = e.target.closest('b[data-d]'); if (q) mnToast(q.dataset.d + ' — ' + q.dataset.v + '%'); };
        t7.insertBefore(b, t7.firstChild); heatRender();
      }
      if (HM.c !== c) HM = { c: c, d: {}, busy: 0 };
      var h = HM; if (h.busy) return;
      var todo = days42().filter(function (x) { return h.d[x] == null; }); if (!todo.length) return;
      h.busy = 1;
      var sched = window.requestIdleCallback ? function (fn) { window.requestIdleCallback(fn, { timeout: 60 }); } : function (fn) { requestAnimationFrame(fn); };
      (function step() {
        if (h.c !== c) return;
        if (scrolling) { setTimeout(step, 90); return; }
        var x = todo.shift();
        if (x != null) {
          h.d[x] = ok(function () { return dayScore(x).avg; });
          if (h.d[x] == null) h.d[x] = 50;
          if (!todo.length || todo.length % 4 === 0) heatRender();
        }
        if (todo.length) sched(step); else { heatRender(); h.busy = 0; }
      })();
    }

    function chips() {
      var box = E('pfc');
      if (!box) {
        box = document.createElement('div'); box.id = 'pfc';
        var anchor = E('kp-scr-bar') || E('tp');
        anchor.insertAdjacentElement('afterend', box);
      }
      var a = []; try { a = pg(); } catch (e) {}
      box.innerHTML = a.length ? '<div class="kpl">' + a.map(function (x, i) { return '<button class="kc" onclick="pfl(' + i + ')">👤 ' + esc(x.nm || '—') + '</button>'; }).join('') + '</div>' : '';
    }

    function wizard() {
      var card = $$('body > .card').find(function (el) { return $$('.sec', el).length >= 3; });
      if (!card || card.dataset.w) return;
      card.dataset.w = 1;
      card.classList.add('kp-form-card');
      var P3 = [0, 1, 2].map(function () { var d = document.createElement('div'); d.className = 'kstep'; return d; }), cur = 0, seen = 0;
      Array.prototype.slice.call(card.childNodes).forEach(function (n) {
        if (n.nodeType == 1 && n.classList.contains('sec')) cur = Math.min(seen++, 2);
        P3[cur].appendChild(n);
      });
      var nm = [T('පුද්ගල', 'Person'), T('දිනය/වේලාව', 'Date & Time'), T('ස්ථානය', 'Place')], pr = document.createElement('div');
      pr.className = 'kprog';
      pr.innerHTML = nm.map(function (n, i) { return '<span data-i="' + i + '"><b>' + (i + 1) + '</b>' + n + '</span>'; }).join('');
      card.appendChild(pr);
      P3.forEach(function (p, i) {
        var k = document.createElement('div'); k.className = 'kn';
        if (i > 0) k.innerHTML += '<button type="button" data-g="' + (i - 1) + '">⬅ ' + T('ආපසු', 'Back') + '</button>';
        if (i < 2) k.innerHTML += '<button type="button" class="p" data-g="' + (i + 1) + '">' + T('ඊළඟ', 'Next') + ' ➜</button>';
        p.appendChild(k); card.appendChild(p);
      });
      function set(n) {
        P3.forEach(function (p, i) { p.classList.toggle('on', i == n); });
        $$('span', pr).forEach(function (s, i) { s.className = i == n ? 'on' : i < n ? 'done' : ''; });
      }
      card.addEventListener('click', function (e) {
        var g = e.target.closest('[data-g]'), s = e.target.closest('.kprog span');
        if (g) set(+g.dataset.g); else if (s) set(+s.dataset.i);
      });
      set(0);
    }

    function skeleton() {
      var sk = document.createElement('div'); sk.id = 'ksk'; sk.innerHTML = '<div class="ksb"></div><div class="ksb"></div><div class="ksb"></div>'; document.body.appendChild(sk);
      document.addEventListener('click', function (e) {
        var b = e.target.closest && e.target.closest('#b1'); if (!b || b.dataset.go) return;
        e.stopImmediatePropagation(); e.preventDefault(); sk.classList.add('on');
        requestAnimationFrame(function () { setTimeout(function () { b.dataset.go = 1; try { b.click(); } finally { delete b.dataset.go; sk.classList.remove('on'); } }, 30); });
      }, true);
    }

    /* ---------- 120Hz Passive Scroll Guard & Lightweight Observer ---------- */
    var ob, tm, curTab = null, activeEl = null, pfSig = '', scrolling = false, scTm = null;
    window.addEventListener('scroll', function () {
      scrolling = true; clearTimeout(scTm); scTm = setTimeout(function () { scrolling = false; }, 110);
    }, { passive: true });

    function sync() {
      if (c && S.c !== c) { S.c = c; ok(buildSum); }
      var el0 = null, tabs = document.getElementsByClassName('tab');
      for (var i = 0; i < tabs.length; i++) { if (tabs[i].style.display === 'block') { el0 = tabs[i]; break; } }
      activeEl = el0;
      var t = el0 ? el0.id : '';
      if (t !== curTab) {
        curTab = t; barState(t);
        if (el0) { el0.classList.remove('kfade'); requestAnimationFrame(function () { el0.classList.add('kfade'); }); }
      }
    }
    function pfSync() {
      if (S.scr !== 'form') return;
      var s = ''; try { s = JSON.stringify(pg().map(function (x) { return x.nm; })); } catch (e) {}
      if (s !== pfSig) { pfSig = s; chips(); }
    }
    var OBC = { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] };
    function tick() {
      if (scrolling) { clearTimeout(tm); tm = setTimeout(tick, 120); return; }
      if (ob) ob.disconnect();
      ok(sync);
      var dw = E('dw'); if (dw && !dw.querySelector('.ti')) ok(tiles);
      ok(pfSync);
      if (activeEl && S.scr === 'page') { ok(function () { tables(activeEl); }); ok(charts); }
      if (curTab === 't7' && S.scr === 'page') ok(heat);
      if (ob) ob.observe(document.body, OBC);
    }

    ok(buildScreens); ok(buildBar); ok(chips); ok(wizard); ok(skeleton);
    goScr('home', true);

    // Live Home clock (30s interval, zero DOM churn)
    S.clockTimer = setInterval(function () {
      var ck = E('kw-clk');
      if (!ck || S.scr !== 'home') return;
      var nt = fmtLiveTime().clock;
      if (ck.textContent !== nt) {
        if (ob) ob.disconnect();
        ck.textContent = nt;
        if (ob) ob.observe(document.body, OBC);
      }
    }, 30000);

    document.addEventListener('click', function (e) {
      if (e.target && e.target.closest && e.target.closest('.hbt')) {
        requestAnimationFrame(function () { var dw = E('dw'); if (dw) ok(tiles); });
      }
    });

    // Preserve active chart & screen across SI <-> EN toggle
    var RSK = ['g','nm','dt','tm','pl','la','lo','tz','ay','ao'];
    document.addEventListener('click', function (e) {
      if (!(e.target.closest && e.target.closest('#lgb')) || !c) return;
      var o = { t: curTab, scr: S.scr }; RSK.forEach(function (k) { if (E(k)) o[k] = E(k).value; });
      try { sessionStorage.setItem('kpRs', JSON.stringify(o)); } catch (x) {}
    }, true);
    ok(function () {
      var r = null; try { r = JSON.parse(sessionStorage.getItem('kpRs') || 'null'); sessionStorage.removeItem('kpRs'); } catch (x) {}
      if (!r) return;
      RSK.forEach(function (k) { if (E(k) && r[k] != null) E(k).value = r[k]; });
      ['la', 'lo'].forEach(function (k) { if (E(k)) E(k).dispatchEvent(new Event('input')); });
      setTimeout(function () {
        if (E('b1')) E('b1').click();
        var n = 0, iv = setInterval(function () {
          if (c || ++n > 60) {
            clearInterval(iv);
            if (c) ok(function () {
              if (r.scr === 'page' && r.t) { nvB(r.t, ''); openPage(r.t); }
              else if (r.scr && r.scr !== 'home') goScr(r.scr);
            });
          }
        }, 100);
      }, 60);
    });

    ob = new MutationObserver(function (muts) {
      var real = false;
      for (var i = 0; i < muts.length; i++) {
        var tg = muts[i].target;
        if (tg && tg.id === 'kw-clk') continue;
        real = true; break;
      }
      if (!real) return;
      clearTimeout(tm); tm = setTimeout(tick, 80);
    });
    tick();
  }
})();
