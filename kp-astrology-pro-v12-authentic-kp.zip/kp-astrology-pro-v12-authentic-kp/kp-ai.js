/* ==========================================================================
   KP ASTROLOGY AI PRO v10 — ZERO-API-KEY FREE MULTI-ENGINE KP A-TO-Z GURU
   Engines:
     1) Smart Auto (Fast Free Cloud AI -> AI Horde Community GPU -> Offline KP Guru)
     2) Pollinations Free Cloud LLMs (OpenAI / DeepSeek / Qwen / Mistral — No API key)
     3) AI Horde Text Community GPUs (aihorde.net/api/v2, free anon key 0000000000 + live GPU list)
     4) Built-in Instant Offline KP A-to-Z Expert Engine (447 Rules + CSL + Significators + DBA)
   ========================================================================== */
(function () {
  if (!window.KPB || /[?&]plain\b/.test(location.search)) return;
  var K = window.KPB;
  var SI = /[\u0D80-\u0DFF]/.test((K.NAV && K.NAV[0] && K.NAV[0][0]) || '');
  var T = function (a, b) { return SI ? a : b; };
  var E = function (i) { return document.getElementById(i); };
  var esc = K.esc;

  var SGN = SI
    ? ['මේෂ','වෘෂභ','මිථුන','කටක','සිංහ','කන්‍යා','තුලා','වෘශ්චික','ධනු','මකර','කුම්භ','මීන']
    : ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
  var NKN = SI
    ? ['අස්විද','බරණ','කැති','රෙහෙණ','මුවසිරස','අද','පුනාවස','පුස','ඇසළ','මා','පුවපල්','උත්තරපල්','හත','සිත','සා','විසා','අනුර','දෙට','මුල','පුරාසල','උතුරුසල','සුවණ','දෙනට','සියාවස','පුව පුටුප','උතුරු පුටුප','රේවතී']
    : ['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','P.Phalguni','U.Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','P.Ashadha','U.Ashadha','Shravana','Dhanishta','Shatabhisha','P.Bhadrapada','U.Bhadrapada','Revati'];
  var PLN = SI
    ? ['කේතු','සිකුරු','රවි','චන්ද්‍ර','කුජ','රාහු','ගුරු','ශනි','බුධ']
    : ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
  var PL_EN = ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
  var CODE_TO_SI = { Su:'රවි', Mo:'චන්ද්‍ර', Ma:'කුජ', Me:'බුධ', Ju:'ගුරු', Ve:'සිකුරු', Sa:'ශනි', Ra:'රාහු', Ke:'කේතු' };
  var CODE_TO_EN = { Su:'Sun', Mo:'Moon', Ma:'Mars', Me:'Mercury', Ju:'Jupiter', Ve:'Venus', Sa:'Saturn', Ra:'Rahu', Ke:'Ketu' };

  var STATE = {
    engine: 'auto',          // 'auto' | 'poll:openai' | 'poll:deepseek' | 'poll:mistral' | 'poll:qwen' | 'horde:<model>' | 'offline'
    engineLabel: T('⚡ Smart Auto (හොඳම Free AI + Horde + Offline)', '⚡ Smart Auto (Best Free AI + Horde + Offline)'),
    hordeModels: [],
    hordeLoaded: false,
    busy: false,
    messages: []
  };

  try {
    var savedEng = localStorage.getItem('kp_ai_eng');
    var savedLbl = localStorage.getItem('kp_ai_lbl');
    if (savedEng) STATE.engine = savedEng;
    if (savedLbl) STATE.engineLabel = savedLbl;
  } catch (e) {}

  /* ---------- Core KP A-to-Z Knowledge System Prompt ---------- */
  var KP_SYSTEM_PROMPT =
    'You are "KP AI Guru", an authoritative Krishnamurti Paddhati (KP) Stellar Astrologer. ' +
    'Follow authentic KP A-to-Z principles strictly:\n' +
    '1. CUSPAL SUB-LORD (CSL) THEORY: The Sub-Lord of the relevant cusp decides whether an event is promised or denied. ' +
    'Planet gives results of its Star-Lord (Nakshatra Lord), modified by its Sub-Lord (quality/denial/confirmation).\n' +
    '2. 4-STEP SIGNIFICATORS (strongest to weakest): (A) Houses occupied by Star-Lord, (B) House occupied by Planet, (C) Houses owned by Star-Lord, (D) Houses owned by Planet.\n' +
    '3. KEY KP HOUSE GROUPINGS:\n' +
    '   - Marriage: 7th CSL connected to 2,7,11 (Denial/Delay: 1,6,10; Separation: 6,10,12; Love marriage: 5,7,11).\n' +
    '   - Job/Service: 6th/10th CSL -> 2,6,10,11 (Promotion: 2,6,10,11; Transfer: 3,10,12; Loss: 5,8,9).\n' +
    '   - Business: 7th/10th CSL -> 2,7,10,11.\n' +
    '   - Wealth/Finance: 2nd/11th CSL -> 2,6,10,11 (Losses: 5,8,12).\n' +
    '   - Foreign Travel/PR: 12th/9th CSL -> 3,9,12.\n' +
    '   - Education: 4th/9th CSL -> 4,9,11.\n' +
    '   - Property/Vehicle: 4th CSL -> 4,11,12.\n' +
    '   - Health: 1st/6th CSL -> 1,5,11 (good/cure) vs 6,8,12 (disease/surgery).\n' +
    '   - Children: 5th CSL -> 2,5,11 (denial: 1,4,10).\n' +
    '   - Litigation/Win: 6th CSL -> 6,11.\n' +
    '4. TIMING (DBA): Event fructifies ONLY during Joint Dasha-Bhukti-Antara (Maha-Antar-Pratyantar) periods of planets signifying the required houses, confirmed by Transit & Ruling Planets.\n' +
    '5. BADHAKA & MARAKA: Badhaka = 11th for Movable lagna, 9th for Fixed, 7th for Dual. Maraka = 2,7.\n' +
    '6. KP GEMS, COLORS & METALS (KP Reader Page 280): ONLY the 1st Cusp Sub-Lord (CSL) or 11th Cusp Sub-Lord (CSL) is eligible for a gemstone, and STRICTLY ONLY IF that planet does NOT signify houses 6, 8, or 12. If both signify 6/8/12, advise against wearing gems. Page 280 table: Sun=Ruby/Orange or Deep Red/Gold & Copper; Moon=Pearl/White,Silvery/Silver; Mars=Coral/Deep Red/Copper & Iron; Mercury=Emerald/Greyish Green/Quick-Silver; Jupiter=Topaz/Purple,Violet,Blue,White/Tin; Venus=Diamond/Yellow,Light Blue,Neutral/Silver & Copper; Saturn=Sapphire/Brown,Indigo,Black/Lead; Rahu & Ketu=Agate or Turquoise/Mixed Colors/Alloy.\n' +
    '7. RAHU KALAYA: Prof. K.S. Krishnamurti REJECTED fixed weekday Rahu Kalaya; in KP, timing is judged solely by Ruling Planets (RP), Sub-Lords, and natal DBA significators.\n' +
    '6. CRITICAL RULE: NEVER invent or guess planetary positions. Use ONLY the exact calculated KP chart data supplied below. ' +
    'Keep the response structured, clear, empathetic, practical, and easy to understand. ' +
    (SI
      ? 'ALWAYS reply in natural, respectful, clear SINHALA (සිංහල) with bullet points and exact KP house/planet proof from the supplied chart.'
      : 'Reply in clear, structured ENGLISH with bullet points and exact KP house/planet proof from the supplied chart.');

  /* ---------- Build Compact Accurate Chart Context ---------- */
  function buildChartContext() {
    var c = K.c;
    if (!c) return 'NO_CHART_CALCULATED_YET (Answer general KP Astrology theory or guide user to enter birth details).';
    var lines = [];
    var nm = (E('nm') && E('nm').value.trim()) || 'User';
    var dtVal = (E('dt') && E('dt').value) || '';
    var tmVal = (E('tm') && E('tm').value) || '';
    var plVal = (E('pl') && E('pl').value) || '';
    var lg = Math.floor(c.cs[0] / 30), lgL = K.lords(c.cs[0]);
    var mo = c.pl.Mo, mn = Math.floor(mo / 30), nk = Math.floor(mo / (40 / 3)) % 27, pd = Math.floor((mo / (40 / 3) % 1) * 4) + 1;

    lines.push('NATIVE: ' + nm + ' | Birth: ' + dtVal + ' ' + tmVal + ' | Place: ' + plVal);
    lines.push('LAGNA: ' + SGN[lg] + ' ' + (c.cs[0] % 30).toFixed(2) + ' deg | RL:' + PL_EN[lgL.rl] + ' NL:' + PL_EN[lgL.nl] + ' SL:' + PL_EN[lgL.sl] + ' SSL:' + PL_EN[lgL.ssl]);
    lines.push('MOON: ' + SGN[mn] + ' ' + (mo % 30).toFixed(2) + ' deg | Nakshatra:' + NKN[nk] + ' Pada ' + pd);

    // 12 Cuspal Sub-Lords
    var csls = [];
    for (var i = 0; i < 12; i++) {
      var cl = K.lords(c.cs[i]);
      csls.push('H' + (i + 1) + ':' + PL_EN[cl.sl]);
    }
    lines.push('12 CUSPAL SUB-LORDS (CSL): ' + csls.join(', '));

    // 9 Planet Significators
    try {
      var sig = K.signif(c);
      var slines = [];
      ['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'].forEach(function (p) {
        var s = sig[p];
        if (!s) return;
        var allH = [];
        [0,1,2,3].forEach(function (lv) { (s[lv] || []).forEach(function (h) { if (allH.indexOf(h) === -1) allH.push(h); }); });
        slines.push(CODE_TO_EN[p] + '(L1:' + (s[0] || []).join(',') + ' All:' + allH.join(',') + ')');
      });
      lines.push('PLANET SIGNIFICATORS: ' + slines.join(' | '));
    } catch (e) {}

    // Current Running Dasha (Maha - Antar - Pratyantar) + Next Antars
    try {
      var nowJD = Date.now() / 864e5 + 2440587.5;
      var findNow = function (x) { return nowJD >= x[1] && nowJD < x[1] + x[2]; };
      var m = K.mainL.find(findNow);
      var a = m && K.kids(m).find(findNow);
      var p = a && K.kids(a).find(findNow);
      if (m) {
        lines.push('CURRENT DASHA (DBA): Maha=' + PL_EN[m[0]] + ' (until ' + K.dt(m[1] + m[2]) + ')'
          + (a ? ' | Antar=' + PL_EN[a[0]] + ' (until ' + K.dt(a[1] + a[2]) + ')' : '')
          + (p ? ' | Pratyantar=' + PL_EN[p[0]] + ' (until ' + K.dt(p[1] + p[2]) + ')' : ''));
        var nextAntars = K.kids(m).filter(function (x) { return x[1] > nowJD; }).slice(0, 3);
        if (nextAntars.length) {
          lines.push('UPCOMING ANTARS: ' + nextAntars.map(function (x) { return PL_EN[x[0]] + '(' + K.dt(x[1]) + '-' + K.dt(x[1] + x[2]) + ')'; }).join(', '));
        }
      }
    } catch (e) {}

    // Top Active Promised Rules from kpRulesData (447 rules)
    try {
      if (window.kpRulesData && window.kpRulesData.rules) {
        var act = [];
        var R = window.kpRulesData.rules;
        for (var idx = 0; idx < R.length; idx++) {
          var o = window.kpRulesData.calc(idx);
          if (o && o.pct >= 62 && o.run >= 2) {
            act.push({ t: R[idx][2], pct: o.pct, run: o.run });
          }
        }
        act.sort(function (a, b) { return (b.run * 100 + b.pct) - (a.run * 100 + a.pct); });
        if (act.length) {
          lines.push('TOP ACTIVE PROMISED KP RULES NOW: ' + act.slice(0, 8).map(function (x) { return x.t + '(' + x.pct + '%, ' + x.run + '/3 DBA)'; }).join('; '));
        }
      }
    } catch (e) {}

    return lines.join('\n');
  }

  /* ---------- Engine 1: Pollinations.ai Free Text API (Zero Key) ---------- */
  function callPollinations(modelName, question, ctx, onStatus) {
    if (onStatus) onStatus(T('🚀 Pollinations Free AI (' + modelName + ') සම්බන්ධ වෙමින්...', '🚀 Connecting to Pollinations Free AI (' + modelName + ')...'));
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 22000);

    var payload = {
      model: modelName || 'openai',
      messages: [
        { role: 'system', content: KP_SYSTEM_PROMPT + '\n\nCALCULATED KP CHART DATA:\n' + ctx },
        { role: 'user', content: question }
      ],
      seed: Math.floor(Math.random() * 99999),
      private: true
    };

    return fetch('https://text.pollinations.ai/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (r) {
      clearTimeout(timer);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    }).then(function (txt) {
      var clean = (txt || '').trim();
      if (!clean || clean.length < 15 || /^<!doctype|^<html/i.test(clean)) throw new Error('Empty/invalid response');
      // Sometimes OpenAI-style JSON wraps content
      if (clean[0] === '{') {
        try {
          var j = JSON.parse(clean);
          var c2 = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
          if (c2) return c2.trim();
        } catch (e) {}
      }
      return clean;
    }).catch(function (err) {
      clearTimeout(timer);
      throw err;
    });
  }

  /* ---------- Engine 2: AI Horde Text Community GPUs (Zero Key — anon 0000000000) ---------- */
  function fetchHordeModels() {
    return fetch('https://aihorde.net/api/v2/status/models?type=text')
      .then(function (r) { if (!r.ok) throw new Error('Horde list err'); return r.json(); })
      .then(function (arr) {
        if (!Array.isArray(arr)) return [];
        arr = arr.filter(function (m) { return m && m.name && m.count > 0; });
        arr.sort(function (a, b) { return (b.count - a.count) || (a.queued - b.queued); });
        STATE.hordeModels = arr.slice(0, 25);
        STATE.hordeLoaded = true;
        return STATE.hordeModels;
      }).catch(function () { return STATE.hordeModels; });
  }

  function callAIHorde(modelName, question, ctx, onStatus) {
    if (onStatus) onStatus(T('🌐 AI Horde Community GPU පෝලිමට යොමු කරමින්...', '🌐 Submitting to AI Horde Community GPUs...'));
    var prompt =
      '### System:\n' + KP_SYSTEM_PROMPT + '\n\nCALCULATED KP CHART:\n' + ctx +
      '\n\n### User:\n' + question + '\n\n### Assistant:\n';

    var body = {
      prompt: prompt,
      params: {
        max_context_length: 2048,
        max_length: 480,
        temperature: 0.65,
        top_p: 0.9,
        rep_pen: 1.1
      }
    };
    if (modelName && modelName !== 'auto') body.models = [modelName];

    return fetch('https://aihorde.net/api/v2/generate/text/async', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': '0000000000',
        'Client-Agent': 'KPAstrologyPro:10.0:public'
      },
      body: JSON.stringify(body)
    }).then(function (r) {
      if (!r.ok) throw new Error('Horde submit HTTP ' + r.status);
      return r.json();
    }).then(function (data) {
      if (!data || !data.id) throw new Error('No Horde job ID');
      var id = data.id, tries = 0;
      return new Promise(function (resolve, reject) {
        function poll() {
          if (++tries > 22) return reject(new Error('AI Horde queue timeout'));
          fetch('https://aihorde.net/api/v2/generate/text/status/' + id, {
            headers: { 'Client-Agent': 'KPAstrologyPro:10.0:public' }
          }).then(function (r) { return r.json(); }).then(function (st) {
            if (st && st.done && st.generations && st.generations[0] && st.generations[0].text) {
              var out = st.generations[0].text.trim();
              if (out.length < 10) return reject(new Error('Short Horde text'));
              return resolve({ text: out, model: st.generations[0].model || modelName || 'AI Horde GPU' });
            }
            if (st && st.faulted) return reject(new Error('Horde worker faulted'));
            var wait = (st && st.wait_time != null) ? st.wait_time : '?';
            var qpos = (st && st.queue_position != null) ? st.queue_position : '?';
            if (onStatus) onStatus(T('🌐 AI Horde GPU සැකසෙමින්... (පෝලිම: ' + qpos + ' · ~' + wait + 's)', '🌐 AI Horde GPU working... (Queue: ' + qpos + ' · ~' + wait + 's)'));
            setTimeout(poll, 2200);
          }).catch(function (e) { reject(e); });
        }
        setTimeout(poll, 1800);
      });
    });
  }

  /* ---------- Engine 3: Built-in Instant Offline KP A-to-Z Guru (Real Chart Math!) ---------- */
  var TOPICS = [
    { id:'marriage', kw:/විවාහ|කසාද|බඳින|සහකරු|සහකාරිය|පෙම්|ආදර|marri|wedd|spouse|love|partner|wife|husband|7th/i,
      cusp:6, good:[2,7,11], bad:[1,6,10,12], cat:'MR',
      si:'විවාහය සහ ආදර සබඳතා', en:'Marriage & Relationships',
      ruleSi:'KP ක්‍රමයට 7 වන භාව උප-අධිපති (7th CSL) 2, 7, 11 භාව සම්බන්ධ නම් විවාහ පොරොන්දුව ප්‍රබලයි. 1, 6, 10 සම්බන්ධ නම් ප්‍රමාද හෝ බාධා ඇති විය හැක.',
      ruleEn:'In KP, marriage is promised when the 7th Cuspal Sub-Lord signifies houses 2, 7, or 11. Strong links to 1, 6, or 10 indicate delay or obstacles.' },
    { id:'career', kw:/රැකියා|ජොබ්|වැඩ|උසස්|ප්‍රමෝෂන්|වෘත්ති|job|career|work|promot|salary|boss|office|10th|6th/i,
      cusp:9, good:[2,6,10,11], bad:[5,8,9,12], cat:'PR',
      si:'රැකියාව සහ වෘත්තීය දියුණුව', en:'Career & Job Growth',
      ruleSi:'KP නීතිය අනුව 10 සහ 6 වන භාව උප-අධිපතීන් 2, 6, 10, 11 සම්බන්ධ වීම ස්ථිර රැකියාව, ආදායම සහ උසස්වීම් පෙන්නුම් කරයි.',
      ruleEn:'In KP, 10th and 6th Cuspal Sub-Lords linked to 2, 6, 10, and 11 promise stable employment, growth, and promotions.' },
    { id:'business', kw:/ව්‍යාපාර|බිස්නස්|වෙළඳ|කඩ|ආයෝජන|business|trade|shop|startup|invest/i,
      cusp:6, good:[2,7,10,11], bad:[5,8,12], cat:'PR',
      si:'ව්‍යාපාර සහ ස්වයං රැකියා', en:'Business & Trade',
      ruleSi:'ස්වාධීන ව්‍යාපාරයක් සඳහා 7 වන සහ 10 වන භාව උප-අධිපතීන් 2, 7, 10, 11 සමඟ සම්බන්ධ විය යුතුය. 8, 12 ප්‍රබල නම් අවදානම් අඩු කර ආරම්භ කරන්න.',
      ruleEn:'Successful business requires 7th & 10th CSL linked to 2, 7, 10, 11. Heavy 8/12 links advise cautious capital management.' },
    { id:'foreign', kw:/විදේශ|රට|වීසා|පිටරට|ප්‍ර|foreign|abroad|visa|pr|migrat|travel|overseas|12th/i,
      cusp:11, good:[3,9,12], bad:[2,4,11], cat:'FT',
      si:'විදේශ ගමන් සහ පදිංචිය', en:'Foreign Travel & Settlement',
      ruleSi:'KP සිද්ධාන්තය අනුව 12 වන භාව උප-අධිපති 3, 9, 12 භාව සම්බන්ධ වීම විදේශ ගමන් සහ රට පදිංචිය සනාථ කරයි.',
      ruleEn:'In KP, the 12th CSL connected to houses 3, 9, and 12 confirms foreign travel and overseas settlement.' },
    { id:'money', kw:/ධන|සල්ලි|මුදල්|ආදායම්|ලාභ|පොහොසත්|ණය|money|wealth|finance|rich|income|loan|profit|2nd|11th/i,
      cusp:1, good:[2,6,10,11], bad:[5,8,12], cat:'FN',
      si:'ධනය, ආදායම් සහ මූල්‍ය තත්ත්වය', en:'Wealth & Financial Strength',
      ruleSi:'2 වන සහ 11 වන භාව උප-අධිපතීන් 2, 6, 10, 11 සම්බන්ධ නම් ධන ලාභ සහ මූල්‍ය ස්ථාවරත්වය ඉහළයි. 8, 12 ප්‍රබල නම් අනවශ්‍ය වියදම් පාලනය කළ යුතුය.',
      ruleEn:'Strong 2nd & 11th CSL links to 2, 6, 10, 11 promise steady income and financial accumulation.' },
    { id:'education', kw:/අධ්‍යාපන|විභාග|ඉගෙන|උපාධි|කැම්පස්|educat|exam|study|degree|school|college|4th|9th/i,
      cusp:3, good:[4,9,11], bad:[3,8,12], cat:'ED',
      si:'අධ්‍යාපනය සහ විභාග ජය', en:'Education & Exams',
      ruleSi:'4 වන සහ 9 වන භාව උප-අධිපතීන් 4, 9, 11 භාව සම්බන්ධ වීම උසස් අධ්‍යාපනය සහ විභාග සමත් වීම පෙන්නුම් කරයි.',
      ruleEn:'4th and 9th CSL linked to 4, 9, 11 indicate academic success and higher studies.' },
    { id:'health', kw:/සෞඛ්‍ය|ලෙඩ|රෝග|අපල|ශල්‍ය|අනතුර|ආයුෂ|health|sick|disease|surger|accid|longev/i,
      cusp:0, good:[1,5,11], bad:[6,8,12], cat:'HL',
      si:'සෞඛ්‍යය සහ රෝග ආරක්ෂාව', en:'Health & Vitality',
      ruleSi:'ලග්න උප-අධිපති 1, 5, 11 සම්බන්ධ නම් සෞඛ්‍යය සහ රෝග සුව වීම ප්‍රබලයි. 6, 8, 12 සම්බන්ධ කාලවලදී සෞඛ්‍යය ගැන සැලකිලිමත් විය යුතුය.',
      ruleEn:'Lagna CSL signifying 1, 5, 11 gives resilience and recovery; 6, 8, 12 periods call for preventive health care.' },
    { id:'property', kw:/ඉඩම්|ගෙවල්|නිවාස|වාහන|කාර්|දේපළ|property|house|land|home|vehicle|car|real estate/i,
      cusp:3, good:[4,11,12], bad:[3,5,8], cat:'PR',
      si:'නිවාස, ඉඩම් සහ වාහන', en:'Property, Land & Vehicles',
      ruleSi:'4 වන භාව උප-අධිපති 4, 11, 12 භාව සම්බන්ධ වීම ඉඩම්, නිවාස සහ වාහන හිමිකාරිත්වය (12 = ආයෝජනය, 11 = ලාභය) සනාථ කරයි.',
      ruleEn:'4th CSL signifying 4, 11, and 12 promises acquisition of home, land, or vehicles.' },
    { id:'children', kw:/දරු|ළමයි|පුත|දුව|ගැබ්|child|baby|son|daughter|pregnan|5th/i,
      cusp:4, good:[2,5,11], bad:[1,4,10], cat:'CH',
      si:'දරු සම්පත්', en:'Children & Progeny',
      ruleSi:'5 වන භාව උප-අධිපති 2, 5, 11 භාව සම්බන්ධ නම් දරු සම්පත් පොරොන්දුව ප්‍රබලයි.',
      ruleEn:'5th CSL linked to 2, 5, and 11 promises childbirth and joy from children.' },
    { id:'dasha', kw:/දශා|කාලය|දැන්|අද|මේ දවස්|හොඳද|නරකද|dasha|period|now|today|timing|future|2026|2027/i,
      cusp:0, good:[1,2,6,9,10,11], bad:[6,8,12], cat:'',
      si:'වත්මන් දශාව සහ කාල විග්‍රහය', en:'Current Dasha & Timing Analysis',
      ruleSi:'KP ක්‍රමයට කුමන සිදුවීමක් වුවද සැබෑවටම සිදුවන්නේ මහා, අන්තර සහ ප්‍රත්‍යන්තර (DBA) අධිපතීන් එම භාව සම්බන්ධ කරන විට පමණි.',
      ruleEn:'In KP, events manifest strictly when Maha, Antar, and Pratyantar (DBA) lords jointly signify the relevant houses.' }
  ];

  function callOfflineGuru(question) {
    var c = K.c;
    if (!c) {
      return T(
        '🪐 **KP AI ජ්‍යොතිෂ ගුරු (Offline):**\n\n' +
        'ඔබේ පුද්ගලික ජන්ම පත්‍රය තවම ගණනය කර නැත. පහළින් ඔබේ උපන් දිනය, වේලාව සහ ස්ථානය දමා **Go ➜** (හෝ "⚡ දැන් වේලාවෙන් පත්‍රය බලන්න") ඔබන්න.\n\n' +
        '📘 **KP මූලික සිද්ධාන්තය:** ක්‍රිෂ්ණමූර්ති පද්ධතියේදී ඕනෑම ප්‍රශ්නයක පොරොන්දුව තීරණය කරන්නේ අදාළ භාවයේ **උප-අධිපති (Cuspal Sub-Lord)** වන අතර, සිදුවන කාලය තීරණය කරන්නේ **මහා–අන්තර–ප්‍රත්‍යන්තර (DBA) දශා** මඟිනි.',
        '🪐 **KP AI Guru (Offline):**\n\nPlease enter your birth details and tap **Go ➜** first so I can analyze your exact Cuspal Sub-Lords, Significators, and Dasha timing.'
      );
    }

    if (/රාහු\s*කාල|rahu\s*kal/i.test(question)) {
      return T(
        '📘 **රාහු කාලය පිළිබඳ ක්‍රිෂ්ණමූර්ති (KP) සිද්ධාන්තය:**\n\n' +
        'මහාචාර්ය කේ.එස්. ක්‍රිෂ්ණමූර්තිතුමා සාම්ප්‍රදායික ස්ථිර **"රාහු කාලය"** (Rahu Kalaya) පිළිගත්තේ නැත.\n\n' +
        '• ලෝකයේ සැමට එකම වේලාවක් අසුබ විය නොහැකි බව KP ක්‍රමයේ මූලික ඉගැන්වීමයි.\n' +
        '• යම් කාර්යයකට සුබ වේලාව තීරණය කරන්නේ එම මොහොතේ **පාලක ග්‍රහයන් (Ruling Planets)**, චන්ද්‍ර උප-අධිපති සහ ඔබේ ජන්ම පත්‍රයේ ශුභ භාව සම්බන්ධ ගෝචරයන් අනුව පමණි.',
        '📘 **KP Theory on Rahu Kalaya:**\n\nProf. K.S. Krishnamurti rejected fixed weekday Rahu Kalaya. In KP, auspicious timing is determined strictly by Ruling Planets (RP), Cuspal Sub-Lords, and natal Dasha/Transit significators.'
      );
    }

    if (/මැණික්|මැණික|ගල්|වර්ණ|පාට|ලෝහ|gem|stone|color|colour|metal|ring|ruby|pearl|sapphire|emerald|topaz|coral|diamond/i.test(question)) {
      var sigG = K.signif(c);
      var P280 = {
        Su: ['රවි','Sun','Ruby (මාණික්‍ය)','තැඹිලි හෝ තද රතු','Gold & Copper (රන් සහ තඹ)'],
        Mo: ['චන්ද්‍ර','Moon','Pearl (මුතු)','සුදු, රිදී පාට','Silver (රිදී)'],
        Ma: ['කුජ','Mars','Coral (පබළු)','තද රතු','Copper / Iron (තඹ / යකඩ)'],
        Me: ['බුධ','Mercury','Emerald (පච්ච / මරකත)','අළු මිශ්‍ර කොළ පාට','Quick-Silver (රසදිය)'],
        Ju: ['ගුරු','Jupiter','Topaz (පුෂ්පරාග)','දම්, වයලට්, නිල්, සුදු','Tin (ටින්)'],
        Ve: ['සිකුරු','Venus','Diamond (දියමන්ති)','කහ, ලා නිල්, සුදුත් නෙවෙයි කළුත් නෙවෙයි','Silver & Copper (රිදී සහ තඹ)'],
        Sa: ['ශනි','Saturn','Sapphire (නීල)','දුඹුරු, ඉන්ඩිගෝ, කළු','Lead (ඊයම්)'],
        Ra: ['රාහු','Rahu','Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)','මිශ්‍ර පාට','Alloy (මිශ්‍ර ලෝහ)'],
        Ke: ['කේතු','Ketu','Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)','මිශ්‍ර පාට','Alloy (මිශ්‍ර ලෝහ)']
      };
      function chk(idx, lbl) {
        var code = K.P[K.lords(c.cs[idx]).sl], lv = sigG[code] || [[],[],[],[]], ah = [];
        [0,1,2,3].forEach(function (k) { (lv[k] || []).forEach(function (h) { if (ah.indexOf(h) === -1) ah.push(h); }); });
        ah.sort(function (a, b) { return a - b; });
        var bad = ah.filter(function (h) { return h === 6 || h === 8 || h === 12; });
        return { lbl: lbl, code: code, m: P280[code], ah: ah, bad: bad, ok: bad.length === 0 };
      }
      var r1 = chk(0, T('1 වන භාව උප-අධිපති (ලග්න)', '1st CSL (Lagna)'));
      var r11 = chk(10, T('11 වන භාව උප-අධිපති (ලාභ)', '11th CSL (Gains)'));
      var lines = ['💎 **KP මැණික්, සුබ වර්ණ & ලෝහ විශ්ලේෂණය (පිටුව 280)**', ''];
      [r1, r11].forEach(function (r) {
        lines.push('• **' + r.lbl + ':** ' + (SI ? r.m[0] : r.m[1]) + ' → ' + T('භාව: ', 'Houses: ') + (r.ah.join(', ') || '—') + ' — ' + (r.ok ? T('✅ සුදුසුයි (6/8/12 නැත)', '✅ Eligible (no 6/8/12)') : T('❌ නුසුදුසුයි (6/8/12 ඇත: ' + r.bad.join(',') + ')', '❌ Avoid (signifies ' + r.bad.join(',') + ')')));
      });
      var okList = [];
      if (r1.ok) okList.push(r1);
      if (r11.ok && (!r1.ok || r11.code !== r1.code)) okList.push(r11);
      lines.push('');
      if (okList.length) {
        okList.forEach(function (r) {
          lines.push('✨ **' + (SI ? r.m[0] : r.m[1]) + ' සඳහා නිර්දේශ (Page 280):**');
          lines.push('• 💎 මැණික: **' + r.m[2] + '**');
          lines.push('• 🎨 පාට: **' + r.m[3] + '**');
          lines.push('• ⚙️ ලෝහය: **' + r.m[4] + '**');
          lines.push('');
        });
      } else {
        lines.push('⚠️ ' + T('1 වන සහ 11 වන උප-අධිපතීන් දෙදෙනාම 6, 8 හෝ 12 භාව සම්බන්ධ කරන බැවින් KP සිද්ධාන්තය අනුව මැණික් පැළඳීම නිර්දේශ නොකෙරේ.', 'Both 1st & 11th CSL signify 6/8/12, so gemstones are not recommended under KP rules.'));
      }
      return lines.join('\n');
    }

    var topic = TOPICS.find(function (tp) { return tp.kw.test(question); }) || TOPICS[9];
    var sig = K.signif(c);
    var cslIdx = K.lords(c.cs[topic.cusp]).sl;
    var cslCode = K.P[cslIdx];
    var cslName = SI ? CODE_TO_SI[cslCode] : CODE_TO_EN[cslCode];
    var lv = sig[cslCode] || [[], [], [], [], []];
    var allH = [];
    [0, 1, 2, 3].forEach(function (i) { (lv[i] || []).forEach(function (h) { if (allH.indexOf(h) === -1) allH.push(h); }); });

    var w = [4, 3, 2, 1.5, 1], pos = 0, neg = 0, tot = 0;
    lv.forEach(function (arr, li) {
      (arr || []).forEach(function (h) {
        tot += w[li];
        if (topic.good.indexOf(h) !== -1) pos += w[li];
        if (topic.bad.indexOf(h) !== -1) neg += w[li];
      });
    });
    var pct = Math.max(18, Math.min(96, tot > 0 ? Math.round(50 + ((pos - neg) / (tot + 2)) * 55) : 50));
    var verdict = pct >= 62
      ? T('🟢 ප්‍රබල සුබ පොරොන්දුවක් ඇත (Strong Promise)', '🟢 Strong Positive Promise')
      : pct >= 45
        ? T('🟡 මධ්‍යස්ථ / උත්සාහයෙන් ජය ගත හැකිය (Moderate / Mixed)', '🟡 Moderate / Effort Brings Success')
        : T('🔴 බාධා / ප්‍රමාද පෙන්නුම් කරයි — නිවැරදි දශාව එනතුරු ඉවසන්න', '🔴 Obstacles / Delay Indicated — Wait for Supportive DBA');

    // Current Dasha analysis
    var nowJD = Date.now() / 864e5 + 2440587.5;
    var fNow = function (x) { return nowJD >= x[1] && nowJD < x[1] + x[2]; };
    var m = K.mainL.find(fNow), a = m && K.kids(m).find(fNow), p = a && K.kids(a).find(fNow);
    var dbaLines = [];
    var dbaMatchCount = 0;
    [
      [T('මහා දශාව', 'Maha Dasha'), m],
      [T('අන්තර දශාව', 'Antar Dasha'), a],
      [T('ප්‍රත්‍යන්තරය', 'Pratyantar'), p]
    ].forEach(function (row) {
      if (!row[1]) return;
      var pc = K.P[row[1][0]];
      var ps = sig[pc] || [[], [], [], []];
      var ph = [];
      [0, 1, 2, 3].forEach(function (i) { (ps[i] || []).forEach(function (h) { if (ph.indexOf(h) === -1) ph.push(h); }); });
      var hits = ph.filter(function (h) { return topic.good.indexOf(h) !== -1; });
      if (hits.length) dbaMatchCount++;
      dbaLines.push('• **' + row[0] + ':** ' + (SI ? CODE_TO_SI[pc] : CODE_TO_EN[pc]) +
        ' (' + K.dt(row[1][1] + row[1][2]) + ' ' + T('දක්වා', 'end') + ') → ' +
        T('භාව: ', 'Houses: ') + (ph.join(', ') || '—') +
        (hits.length ? ' ✅' : ''));
    });

    // Matching rules from 447 KP Rules engine
    var ruleHits = [];
    try {
      if (window.kpRulesData && window.kpRulesData.rules) {
        var R = window.kpRulesData.rules;
        for (var i = 0; i < R.length; i++) {
          if (topic.cat && R[i][1] !== topic.cat && R[i][0] !== (topic.cusp + 1)) continue;
          var o = window.kpRulesData.calc(i);
          if (o && o.pct >= 55) ruleHits.push({ name: SI ? R[i][3] : R[i][2], pct: o.pct, run: o.run });
        }
        ruleHits.sort(function (x, y) { return (y.run * 100 + y.pct) - (x.run * 100 + x.pct); });
      }
    } catch (e) {}

    // Next best Antardasha for this topic
    var nextBest = [];
    if (m) {
      K.kids(m).filter(function (x) { return x[1] + x[2] > nowJD; }).slice(0, 6).forEach(function (x) {
        var pc = K.P[x[0]];
        var ps = sig[pc] || [[], [], [], []];
        var ph = [];
        [0, 1, 2, 3].forEach(function (i) { (ps[i] || []).forEach(function (h) { if (ph.indexOf(h) === -1) ph.push(h); }); });
        var score = ph.filter(function (h) { return topic.good.indexOf(h) !== -1; }).length;
        if (score >= 2) {
          nextBest.push((SI ? CODE_TO_SI[pc] : CODE_TO_EN[pc]) + ' (' + K.dt(x[1]) + ' → ' + K.dt(x[1] + x[2]) + ')');
        }
      });
    }

    var out = [];
    out.push('🔮 **' + (SI ? topic.si : topic.en) + ' — KP විශ්ලේෂණය**');
    out.push('');
    out.push('**1. භාව උප-අධිපති පොරොන්දුව (CSL Promise): ' + pct + '%**');
    out.push('• ' + (topic.cusp + 1) + ' ' + T('වන භාව උප-අධිපති (CSL):', 'th House CSL:') + ' **' + cslName + '**');
    out.push('• ' + T('සම්බන්ධ භාව (Significators):', 'Signified Houses:') + ' **' + (allH.join(', ') || '—') + '** (' + T('ප්‍රබලම නක්ෂත්‍ර භාවය:', 'Strongest Star-Lord House:') + ' ' + ((lv[0] || []).join(', ') || '—') + ')');
    out.push('• ' + verdict);
    out.push('');
    out.push('**2. ' + T('දැන් ක්‍රියාත්මක දශා කාලය (DBA Timing):', 'Running Dasha Timing (DBA):') + '** (' + dbaMatchCount + '/3 ' + T('ගැළපේ', 'active') + ')');
    dbaLines.forEach(function (l) { out.push(l); });

    if (nextBest.length) {
      out.push('');
      out.push('**3. ' + T('ඉදිරියේදී වඩාත් සුබ අන්තර දශා කාල:', 'Most Supportive Upcoming Antardashas:') + '**');
      nextBest.slice(0, 3).forEach(function (nb) { out.push('• 🗓️ ' + nb); });
    }

    if (ruleHits.length) {
      out.push('');
      out.push('**4. ' + T('ගැළපෙන KP නීති 447න් ප්‍රධාන පලාපල:', 'Matching KP Rules (from 447 Engine):') + '**');
      ruleHits.slice(0, 4).forEach(function (rh) {
        out.push('• ' + (rh.run >= 2 ? '🟢 ' : '🔹 ') + rh.name + ' — **' + rh.pct + '%** (' + rh.run + '/3 DBA)');
      });
    }

    out.push('');
    out.push('📘 *' + (SI ? topic.ruleSi : topic.ruleEn) + '*');
    return out.join('\n');
  }

  /* ---------- Unified Smart Router (Zero API Key!) ---------- */
  function askKP(question, onStatus) {
    var ctx = buildChartContext();
    var eng = STATE.engine;

    if (eng === 'offline') {
      return Promise.resolve({ text: callOfflineGuru(question), source: T('⚡ Offline KP 447-Rules Guru', '⚡ Offline KP 447-Rules Guru') });
    }

    if (eng.indexOf('poll:') === 0) {
      var pm = eng.slice(5);
      return callPollinations(pm, question, ctx, onStatus).then(function (txt) {
        return { text: txt, source: '🚀 Pollinations (' + pm + ')' };
      }).catch(function () {
        return { text: callOfflineGuru(question), source: T('⚡ Offline KP Guru (Cloud busy fallback)', '⚡ Offline KP Guru (Cloud fallback)') };
      });
    }

    if (eng.indexOf('horde:') === 0) {
      var hm = eng.slice(6);
      return callAIHorde(hm, question, ctx, onStatus).then(function (res) {
        return { text: res.text, source: '🌐 AI Horde (' + res.model + ')' };
      }).catch(function () {
        if (onStatus) onStatus(T('⚡ AI Horde කාර්යබහුලයි — Pollinations Free AI වෙත මාරු වෙමින්...', '⚡ AI Horde busy — switching to Pollinations Free AI...'));
        return callPollinations('openai', question, ctx, onStatus).then(function (txt) {
          return { text: txt, source: '🚀 Pollinations (Horde fallback)' };
        }).catch(function () {
          return { text: callOfflineGuru(question), source: T('⚡ Offline KP Guru (Fallback)', '⚡ Offline KP Guru (Fallback)') };
        });
      });
    }

    // Smart Auto: Pollinations OpenAI -> Pollinations Mistral -> AI Horde -> Instant Offline KP Guru
    return callPollinations('openai', question, ctx, onStatus).then(function (txt) {
      return { text: txt, source: '⚡ Smart Auto · Pollinations OpenAI' };
    }).catch(function () {
      if (onStatus) onStatus(T('🔄 දෙවැනි Free AI එන්ජිම (Mistral) පරීක්ෂා කරමින්...', '🔄 Trying backup Free AI (Mistral)...'));
      return callPollinations('mistral', question, ctx, onStatus).then(function (txt) {
        return { text: txt, source: '⚡ Smart Auto · Pollinations Mistral' };
      });
    }).catch(function () {
      if (onStatus) onStatus(T('🌐 AI Horde Community GPU සම්බන්ධ කරමින්...', '🌐 Trying AI Horde Community GPUs...'));
      return callAIHorde('auto', question, ctx, onStatus).then(function (res) {
        return { text: res.text, source: '🌐 Smart Auto · AI Horde (' + res.model + ')' };
      });
    }).catch(function () {
      return { text: callOfflineGuru(question), source: T('⚡ Offline KP 447-Rules Guru (Instant)', '⚡ Offline KP 447-Rules Guru (Instant)') };
    });
  }

  /* ---------- Simple Safe Markdown Renderer ---------- */
  function fmtMd(str) {
    var s = esc(str || '');
    s = s.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
    s = s.replace(/\*([^*\n]+)\*/g, '<i>$1</i>');
    s = s.replace(/^###\s*(.+)$/gm, '<div class="ai-h">$1</div>');
    s = s.replace(/^##\s*(.+)$/gm, '<div class="ai-h">$1</div>');
    s = s.replace(/\n/g, '<br>');
    return s;
  }

  /* ---------- Engine Picker Modal (AI Horde Style Radio List!) ---------- */
  function openEngineModal() {
    var m = E('kp-eng-modal');
    if (!m) {
      m = document.createElement('div');
      m.id = 'kp-eng-modal';
      m.onclick = function (e) { if (e.target === m) m.classList.remove('on'); };
      document.body.appendChild(m);
    }

    function renderModal() {
      var builtins = [
        ['auto', '⚡ Smart Best Auto', T('Pollinations + AI Horde GPU + Offline KP Guru (API Key අවශ්‍ය නැත)', 'Fast Free AI + AI Horde GPUs + Offline Fallback (Zero Key)')],
        ['poll:openai', '🚀 Pollinations OpenAI (Free Cloud)', T('සිංහල + KP තර්කනයට වේගවත්ම Free එන්ජිම', 'Fastest Free Cloud AI · Great Sinhala & English')],
        ['poll:deepseek', '🧠 Pollinations DeepSeek (Free Reasoning)', T('ගැඹුරු KP භාව විශ්ලේෂණය සඳහා', 'Deep Reasoning for complex KP charts')],
        ['poll:qwen', '🌏 Pollinations Qwen / Multilingual (Free)', T('බහු-භාෂා Free AI එන්ජිම', 'Strong multilingual Free Cloud model')],
        ['poll:mistral', '💨 Pollinations Mistral (Free Fast)', T('වේගවත් Free Open-Weight මොඩලය', 'Fast Free open-weight model')],
        ['horde:auto', '🌐 AI Horde Community GPUs (Auto Best)', T('නොමිලේ ස්වේච්ඡා GPU ජාලය (Anon Key: 0000000000)', 'Free volunteer GPU cluster (Zero API Key)')],
        ['offline', '⚡ Instant Offline KP 447-Rules Guru', T('අන්තර්ජාලය නැතිව 0.01s න් නිවැරදි KP විග්‍රහය', '100% Offline · Uses your 447 KP Rules & CSLs instantly')]
      ];

      var hordeHtml = '';
      if (STATE.hordeModels.length) {
        hordeHtml = '<div class="em-sec">🌐 AI HORDE LIVE FREE TEXT GPUs (' + STATE.hordeModels.length + ')</div>' +
          STATE.hordeModels.map(function (hm) {
            var val = 'horde:' + hm.name;
            var on = STATE.engine === val;
            var q = hm.queued != null ? hm.queued : 0;
            return '<div class="em-row' + (on ? ' on' : '') + '" data-eng="' + esc(val) + '" data-lbl="🌐 ' + esc(hm.name) + '">' +
              '<div class="em-info"><b>' + esc(hm.name) + '</b><small>(' + hm.count + ' GPU • Q:' + q + ')</small></div>' +
              '<span class="em-rad"></span></div>';
          }).join('');
      } else {
        hordeHtml = '<div class="em-sec">🌐 AI HORDE LIVE TEXT GPUs</div>' +
          '<div class="em-load">' + T('සජීවී GPU ලැයිස්තුව පූරණය වෙමින්...', 'Loading live community GPU workers...') + '</div>';
      }

      m.innerHTML =
        '<div class="em-sheet">' +
          '<div class="em-head">' +
            '<span>🤖 ' + T('Free AI එන්ජිම තෝරන්න (API Key එපා)', 'Select Free AI Engine (Zero API Key)') + '</span>' +
            '<button type="button" class="em-x" id="em-close">✕</button>' +
          '</div>' +
          '<div class="em-list">' +
            '<div class="em-sec">⚡ ' + T('ප්‍රධාන FREE එන්ජින්', 'FEATURED FREE ENGINES') + '</div>' +
            builtins.map(function (b) {
              var on = STATE.engine === b[0];
              return '<div class="em-row' + (on ? ' on' : '') + '" data-eng="' + esc(b[0]) + '" data-lbl="' + esc(b[1]) + '">' +
                '<div class="em-info"><b>' + b[1] + '</b><small>' + b[2] + '</small></div>' +
                '<span class="em-rad"></span></div>';
            }).join('') +
            hordeHtml +
          '</div>' +
        '</div>';

      E('em-close').onclick = function () { m.classList.remove('on'); };
      m.querySelectorAll('.em-row').forEach(function (row) {
        row.onclick = function () {
          STATE.engine = row.dataset.eng;
          STATE.engineLabel = row.dataset.lbl;
          try {
            localStorage.setItem('kp_ai_eng', STATE.engine);
            localStorage.setItem('kp_ai_lbl', STATE.engineLabel);
          } catch (e) {}
          var btn = E('ai-eng-btn');
          if (btn) btn.textContent = STATE.engineLabel + ' ▾';
          m.classList.remove('on');
          if (K.mnToast) K.mnToast(T('AI එන්ජිම: ', 'AI Engine: ') + STATE.engineLabel);
        };
      });
    }

    renderModal();
    m.classList.add('on');
    if (!STATE.hordeLoaded) {
      fetchHordeModels().then(function () { if (m.classList.contains('on')) renderModal(); });
    }
  }

  /* ---------- Render Chat Tab (t18) ---------- */
  var QUICK_QS = SI ? [
    ['💍 විවාහය කවදාද?', 'මගේ විවාහය සිදුවන්නේ කවදාද? සහකරු/සහකාරිය සහ විවාහ ජීවිතය KP ක්‍රමයට විස්තර කරන්න.'],
    ['💼 රැකියාව / ව්‍යාපාරය', 'මට වඩාත් ගැළපෙන්නේ රැකියාවද ව්‍යාපාරයක්ද? ඉදිරි දියුණුව KP ක්‍රමයට කියන්න.'],
    ['✈️ විදේශ ගමන්', 'මට විදේශ රටකට යන්න හෝ පදිංචි වෙන්න වාසනාව තියෙනවද? හොඳම කාලය කවදාද?'],
    ['💰 ධනය සහ ලාභ', 'මගේ මූල්‍ය තත්ත්වය සහ ධන ලාභ ලැබෙන කාල වකවානු KP ක්‍රමයට පැහැදිලි කරන්න.'],
    ['⏳ දැන් දශාව හොඳද?', 'මට දැන් ගතවෙන මහා-අන්තර-ප්‍රත්‍යන්තර දශාව මොන වගේද? සැලකිලිමත් විය යුතු දේ මොනවාද?'],
    ['🩺 සෞඛ්‍යය සහ අපල', 'මගේ සෞඛ්‍ය තත්ත්වය සහ අපල කාලවලින් ආරක්ෂා වන විදිහ KP ක්‍රමයට කියන්න.'],
    ['🏠 ඉඩම් / නිවාස', 'මට ගෙයක්, ඉඩමක් හෝ වාහනයක් මිලදී ගන්න පුළුවන් හොඳම කාලය කවදාද?'],
    ['💎 සුදුසු මැණික & පාට', 'KP ක්‍රමයට (1 හෝ 11 උප-අධිපති අනුව) මට පැළඳීමට සුදුසු මැණික, පාට සහ ලෝහය කුමක්ද?'],
    ['🌟 සම්පූර්ණ විග්‍රහය', 'මගේ ජන්ම පත්‍රයේ ලග්න උප-අධිපති සහ ප්‍රධාන භාව අනුව සම්පූර්ණ KP සාරාංශයක් දෙන්න.']
  ] : [
    ['💍 Marriage Timing', 'When is my marriage promised and how will married life be according to my KP chart?'],
    ['💼 Job vs Business', 'Is job or business better for me according to my 6th, 7th, and 10th Cuspal Sub-Lords?'],
    ['✈️ Foreign Travel', 'Do I have foreign travel or settlement promise in my KP chart, and when?'],
    ['💰 Wealth & Finance', 'Analyze my 2nd and 11th Cuspal Sub-Lords for financial growth and best dasha timing.'],
    ['⏳ Current Dasha', 'Explain my currently running Maha-Antar-Pratyantar Dasha and what events it activates.'],
    ['🩺 Health Overview', 'Analyze my Lagna and 6th/8th/12th house significators for health and caution periods.'],
    ['🏠 Home / Vehicle', 'When is the best KP period to buy property, land, or a vehicle?'],
    ['💎 Lucky Gem & Color', 'Which gemstone, color, and metal are suitable for me based on KP 1st and 11th Cuspal Sub-Lords (excluding 6,8,12)?'],
    ['🌟 Full KP Reading', 'Give me a complete executive KP summary based on my Lagna Sub-Lord and active rules.']
  ];

  function renderMessages() {
    var box = E('ai-msgs');
    if (!box) return;
    if (!STATE.messages.length) {
      box.innerHTML =
        '<div class="ai-msg bot">' +
          '<div class="ai-b">' +
            '<b>✦ ' + T('ආයුබෝවන්! මම ඔබේ KP AI ජ්‍යොතිෂ ගුරු.', 'Welcome! I am your KP AI Astrology Guru.') + '</b><br>' +
            T('කිසිම API Key එකක් අවශ්‍ය නැත. ඔබේ ගණනය කළ සැබෑ KP භාව උප-අධිපති (CSL), Significators, දශා සහ KP නීති 447 ඇසුරින් ඕනෑම ප්‍රශ්නයකට පිළිතුරු දෙමි. පහළින් ප්‍රශ්නයක් තෝරන්න හෝ ටයිප් කරන්න!',
              'Zero API key needed. I analyze your exact calculated KP Cuspal Sub-Lords, 4-level Significators, Dasha timing, and 447 KP Rules. Tap a quick question below or type anything!') +
          '</div>' +
        '</div>';
      return;
    }

    box.innerHTML = STATE.messages.map(function (m, idx) {
      if (m.role === 'user') {
        return '<div class="ai-msg usr"><div class="ai-b">' + esc(m.text) + '</div></div>';
      }
      return '<div class="ai-msg bot">' +
        '<div class="ai-b">' +
          (m.source ? '<div class="ai-src">' + esc(m.source) + '</div>' : '') +
          '<div>' + fmtMd(m.text) + '</div>' +
          '<div class="ai-acts">' +
            '<button type="button" data-cp="' + idx + '">📋 ' + T('කොපි', 'Copy') + '</button>' +
            '<button type="button" data-wa="' + idx + '">📤 WhatsApp</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');

    box.querySelectorAll('button[data-cp]').forEach(function (b) {
      b.onclick = function () {
        var msg = STATE.messages[+b.dataset.cp];
        if (!msg) return;
        if (navigator.clipboard) navigator.clipboard.writeText(msg.text).catch(function () {});
        if (K.mnToast) K.mnToast(T('පිළිතුර කොපි විය!', 'Copied to clipboard!'));
      };
    });
    box.querySelectorAll('button[data-wa]').forEach(function (b) {
      b.onclick = function () {
        var msg = STATE.messages[+b.dataset.wa];
        if (!msg) return;
        var txt = '✦ KP Astrology AI Pro\n\n' + msg.text;
        window.open('https://wa.me/?text=' + encodeURIComponent(txt), '_blank');
      };
    });
    box.scrollTop = box.scrollHeight;
  }

  function submitQuestion(qText) {
    var q = (qText || '').trim();
    if (!q || STATE.busy) return;
    STATE.busy = true;
    STATE.messages.push({ role: 'user', text: q });
    renderMessages();

    var inp = E('ai-in');
    if (inp) inp.value = '';
    var stEl = E('ai-status');
    var sendBtn = E('ai-send');
    if (sendBtn) sendBtn.disabled = true;
    if (stEl) { stEl.style.display = 'block'; stEl.textContent = T('🔮 ඔබේ KP කේන්දරය විශ්ලේෂණය කරමින්...', '🔮 Analyzing your KP chart...'); }

    askKP(q, function (statusText) {
      if (stEl) stEl.textContent = statusText;
    }).then(function (res) {
      STATE.messages.push({ role: 'bot', text: res.text, source: res.source });
      renderMessages();
    }).catch(function () {
      STATE.messages.push({ role: 'bot', text: callOfflineGuru(q), source: '⚡ Offline KP Guru' });
      renderMessages();
    }).finally(function () {
      STATE.busy = false;
      if (sendBtn) sendBtn.disabled = false;
      if (stEl) stEl.style.display = 'none';
    });
  }

  function renderAiTab() {
    var el = E('t18');
    if (!el) return;
    var hasChart = !!K.c;
    var nm = (E('nm') && E('nm').value.trim()) || T('ජන්ම පත්‍රය', 'Birth Chart');

    el.innerHTML =
      '<div class="ai-top">' +
        '<h3>🤖 ' + T('KP AI ජ්‍යොතිෂ ගුරු (100% Free)', 'KP AI Astrology Guru (100% Free)') + '</h3>' +
        '<div class="ai-bar">' +
          '<button type="button" id="ai-eng-btn" class="ai-eng-pill">' + esc(STATE.engineLabel) + ' ▾</button>' +
          '<button type="button" id="ai-clr" title="' + T('මකන්න', 'Clear') + '">🗑️</button>' +
        '</div>' +
        '<div class="ai-ctx-pill">' +
          (hasChart
            ? '🟢 ' + T('සැබෑ KP කේන්දර දත්ත සම්බන්ධයි: ', 'Live KP Chart Linked: ') + '<b>' + esc(nm) + '</b>'
            : '🟡 ' + T('කේන්දරය තවම සාදා නැත (සාමාන්‍ය KP ප්‍රශ්න ඇසිය හැක)', 'No chart yet (general KP Q&A ready)')) +
        '</div>' +
      '</div>' +
      '<div class="ai-chips">' +
        QUICK_QS.map(function (q, i) { return '<button type="button" data-qq="' + i + '">' + q[0] + '</button>'; }).join('') +
      '</div>' +
      '<div id="ai-msgs" class="ai-msgs"></div>' +
      '<div id="ai-status" class="ai-status" style="display:none"></div>' +
      '<div class="ai-foot">' +
        '<input id="ai-in" type="text" placeholder="' + T('ඔබේ ප්‍රශ්නය සිංහලෙන් හෝ ඉංග්‍රීසියෙන් අසන්න...', 'Ask anything about your KP chart...') + '" autocomplete="off">' +
        '<button type="button" class="p" id="ai-send">➤</button>' +
      '</div>';

    E('ai-eng-btn').onclick = openEngineModal;
    E('ai-clr').onclick = function () { STATE.messages = []; renderMessages(); };
    E('ai-send').onclick = function () { submitQuestion(E('ai-in').value); };
    E('ai-in').onkeydown = function (e) { if (e.key === 'Enter') submitQuestion(E('ai-in').value); };
    el.querySelectorAll('.ai-chips button').forEach(function (b) {
      b.onclick = function () { submitQuestion(QUICK_QS[+b.dataset.qq][1]); };
    });

    renderMessages();
  }

  window.kpAiTab = renderAiTab;
  window.kpAiOpenModal = openEngineModal;

  /* Add KP AI Guru entry into the Drawer Menu (Forecast group) */
  try {
    var g = K.NAV.find(function (x) { return x[1].some(function (y) { return y[1] === 't5'; }); });
    if (g && !g[1].some(function (y) { return y[1] === 't18'; })) {
      g[1].unshift([T('🤖 KP AI ගුරු', '🤖 KP AI Guru'), 't18']);
    }
  } catch (e) {}
})();
