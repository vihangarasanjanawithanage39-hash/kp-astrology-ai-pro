KP ASTROLOGY AI PRO v21 — COMMERCIAL CLEAN EDITION (120HZ · 100% OFFLINE · MULTI-SCREEN)
=======================================================================================
- Removed 447 rules module (kp-rules.js) for a streamlined, professional commercial release.
- True 6-Screen Multi-Screen Navigation (Home, Birth Chart, Horary 1-249, Ruling RP, Saved Charts, Settings).
- Unified 5-Level KP+ Dasha Engine (Maha -> Antar -> Pratyantar -> Sookshma -> Prana).
- Authentic KP Gems, Colors & Metals (strictly 1st & 11th CSL excluding 6/8/12).
- Built-in Bilingual (Sinhala / English) KP AI Guru (Online Cloud + Instant Offline).
- Ready for GitHub Auto-Update OTA + 120Hz Offline Android APK & Netlify Drop.
