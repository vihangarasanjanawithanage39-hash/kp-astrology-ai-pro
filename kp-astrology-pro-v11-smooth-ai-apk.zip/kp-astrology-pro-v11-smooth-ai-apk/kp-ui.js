/* ==========================================================================
   KP ASTROLOGY AI PRO v10 — MIDNIGHT CYAN-BLACK UI ENGINE + EXTRA KP TOOLS
   ========================================================================== */
(function () {
  if (!window.KPB || /[?&]plain\b/.test(location.search)) return;
  with (window.KPB) {
    var SI = /[\u0D80-\u0DFF]/.test((typeof NAV !== 'undefined' && NAV[0] && NAV[0][0]) || '');
    var T = function (a, b) { return SI ? a : b; };
    var E = function (i) { return document.getElementById(i); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
    var ok = function (f) { try { return f(); } catch (e) { if (window.console) console.warn('kp-ui', e); } };

    // Default to Midnight-Black & Light-Blue Dark Theme (kpt_v10)
    try {
      if (!localStorage.getItem('kpt_v10')) {
        document.documentElement.dataset.t = 'dark';
        localStorage.setItem('kpt_v10', 'dark');
      }
    } catch (e) {}

    function syncThemeIcon() {
      var btn = E('th');
      if (!btn) return;
      btn.textContent = document.documentElement.dataset.t === 'light' ? '🌙' : '☀️';
      btn.setAttribute('aria-label', T('තේමාව මාරු කරන්න', 'Toggle theme'));
    }
    syncThemeIcon();
    if (E('th')) E('th').addEventListener('click', function () { setTimeout(syncThemeIcon, 10); });

    if (SI) { document.body.classList.add('si'); var flk = document.createElement('link'); flk.rel = 'stylesheet'; flk.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Sinhala:wght@400;600;700&display=swap'; document.head.appendChild(flk); }
    if (E('lgb')) E('lgb').textContent = SI ? 'සිං/EN' : 'EN/සිං';
    var ayEl = E('aysub');
    if (ayEl) ayEl.textContent = T('KP + Free AI ගුරු · සියල්ල විවෘතයි', 'KP + Free AI Guru · All Unlocked');

    var SGN = SI
      ? ['මේෂ','වෘෂභ','මිථුන','කටක','සිංහ','කන්‍යා','තුලා','වෘශ්චික','ධනු','මකර','කුම්භ','මීන']
      : ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
    var NKN = SI
      ? ['අස්විද','බරණ','කැති','රෙහෙණ','මුවසිරස','අද','පුනාවස','පුස','ඇසළ','මා','පුවපල්','උත්තරපල්','හත','සිත','සා','විසා','අනුර','දෙට','මුල','පුරාසල','උතුරුසල','සුවණ','දෙනට','සියාවස','පුව පුටුප','උතුරු පුටුප','රේවතී']
      : ['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','P.Phalguni','U.Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','P.Ashadha','U.Ashadha','Shravana','Dhanishta','Shatabhisha','P.Bhadrapada','U.Bhadrapada','Revati'];
    var PLN = SI
      ? ['කේතු','සිකුරු','රවි','චන්ද්‍ර','කුජ','රාහු','ගුරු','ශනි','බුධ']
      : ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
    var DAY_LORD = SI
      ? ['රවි','චන්ද්‍ර','කුජ','බුධ','ගුරු','සිකුරු','ශනි']
      : ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
    var HORA_SEQ = SI
      ? ['රවි','සිකුරු','බුධ','චන්ද්‍ර','ශනි','ගුරු','කුජ']
      : ['Sun','Venus','Mercury','Moon','Saturn','Jupiter','Mars'];
    var DAY_TO_HORA = [0, 3, 6, 2, 5, 1, 4];
    // Sri Lanka / Vedic standard weekday Rahu Kalaya windows (24h decimal hours): Sun..Sat
    var RAHU_WIN = [
      [16.5, 18.0, '4:30–6:00 PM'],
      [7.5,  9.0,  '7:30–9:00 AM'],
      [15.0, 16.5, '3:00–4:30 PM'],
      [12.0, 13.5, '12:00–1:30 PM'],
      [13.5, 15.0, '1:30–3:00 PM'],
      [10.5, 12.0, '10:30–12:00 PM'],
      [9.0,  10.5, '9:00–10:30 AM']
    ];
    var PL_META = {
      Su: { si:'රවි', en:'Sun', daySi:'ඉරිදා', dayEn:'Sunday', colSi:'රන්වන් / තැඹිලි', colEn:'Gold / Orange', num:'1', dirSi:'නැගෙනහිර', dirEn:'East' },
      Mo: { si:'චන්ද්‍ර', en:'Moon', daySi:'සඳුදා', dayEn:'Monday', colSi:'සුදු / රිදී', colEn:'White / Pearl', num:'2', dirSi:'වයඹ', dirEn:'NW' },
      Ma: { si:'කුජ', en:'Mars', daySi:'අඟහරුවාදා', dayEn:'Tuesday', colSi:'රතු / කොරල්', colEn:'Red / Coral', num:'9', dirSi:'දකුණ', dirEn:'South' },
      Me: { si:'බුධ', en:'Mercury', daySi:'බදාදා', dayEn:'Wednesday', colSi:'කොළ / මරකත', colEn:'Emerald Green', num:'5', dirSi:'උතුර', dirEn:'North' },
      Ju: { si:'ගුරු', en:'Jupiter', daySi:'බ්‍රහස්පතින්දා', dayEn:'Thursday', colSi:'කහ / රන්', colEn:'Yellow / Saffron', num:'3', dirSi:'ඊසාන', dirEn:'NE' },
      Ve: { si:'සිකුරු', en:'Venus', daySi:'සිකුරාදා', dayEn:'Friday', colSi:'ලා නිල් / සුදු', colEn:'Sky Blue / White', num:'6', dirSi:'ගිනිකොණ', dirEn:'SE' },
      Sa: { si:'ශනි', en:'Saturn', daySi:'සෙනසුරාදා', dayEn:'Saturday', colSi:'තද නිල්', colEn:'Royal Blue', num:'8', dirSi:'බස්නාහිර', dirEn:'West' },
      Ra: { si:'රාහු', en:'Rahu', daySi:'සෙනසුරාදා', dayEn:'Saturday', colSi:'අළු / නිල්', colEn:'Electric Blue', num:'4', dirSi:'නිරිත', dirEn:'SW' },
      Ke: { si:'කේතු', en:'Ketu', daySi:'අඟහරුවාදා', dayEn:'Tuesday', colSi:'දුඹුරු / කහ', colEn:'Earthy / Saffron', num:'7', dirSi:'ඊසාන', dirEn:'NE' }
    };
    var WD = SI ? ['ඉ','ස','අ','බ','බ්‍ර','සි','සෙ'] : ['S','M','T','W','T','F','S'];
    var PC = { Su:'#f59e0b',Mo:'#94a3b8',Ma:'#ef4444',Me:'#10b981',Ju:'#eab308',Ve:'#ec4899',Sa:'#6366f1',Ra:'#a855f7',Ke:'#b45309',Ur:'#06b6d4',Ne:'#06b6d4',Pl:'#06b6d4' };
    var S = { c: null, day: null, clockTimer: null, installPrompt: null };

    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault(); S.installPrompt = e;
      var btn = E('kp-install-btn'); if (btn) btn.classList.add('show');
    });
    window.addEventListener('appinstalled', function () {
      S.installPrompt = null;
      var btn = E('kp-install-btn'); if (btn) btn.classList.remove('show');
      ok(function () { mnToast(T('✓ KP Astrology AI Pro ඇප් එක ස්ථාපනය විය!', '✓ KP Astrology AI Pro installed!')); });
    });

    function today() {
      var n = new Date();
      return n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0');
    }
    function dms(deg) {
      var d = Math.floor(deg), mF = (deg - d) * 60, m = Math.floor(mF), s = Math.floor((mF - m) * 60);
      return d + '°' + String(m).padStart(2, '0') + "'" + String(s).padStart(2, '0') + '"';
    }
    function livePanchanga() {
      var now = new Date(), dow = now.getDay(), hr = now.getHours(), mn = now.getMinutes();
      var decH = hr + mn / 60;
      var effDow = hr < 6 ? (dow + 6) % 7 : dow;
      var hrsSinceSunrise = (hr + 24 - 6) % 24;
      var idx = (DAY_TO_HORA[effDow] + hrsSinceSunrise) % 7;
      var rw = RAHU_WIN[dow];
      var inRahu = decH >= rw[0] && decH < rw[1];
      var minsLeftHora = 60 - mn;
      return {
        dayLord: DAY_LORD[effDow],
        horaLord: HORA_SEQ[idx],
        horaLeft: minsLeftHora + 'm',
        rahuText: rw[2],
        inRahu: inRahu,
        time: now.toTimeString().slice(0, 5)
      };
    }
    function dayScore(x) {
      var g = kpDay(x);
      var r = TOP.map(function (t, i) {
        return PCT(g.segs.reduce(function (s, y) { return s + y.f[i] * (y.t1 - y.t0); }, 0) / 24);
      });
      return { g: g, r: r, avg: Math.round(r.reduce(function (a, b) { return a + b; }, 0) / r.length) };
    }
    function curDashaObj() {
      var now = Date.now() / 864e5 + 2440587.5;
      var f = function (x) { return now >= x[1] && now < x[1] + x[2]; };
      var m = mainL.find(f), a = m && kids(m).find(f), p = a && kids(a).find(f);
      return {
        names: [m, a, p].filter(Boolean).map(function (x) { return PLN[x[0]]; }),
        end: p ? dt(p[1] + p[2]) : (a ? dt(a[1] + a[2]) : '')
      };
    }
    function ringSvg(p, sz) {
      var r = sz / 2 - 8, L = 2 * Math.PI * r, h = sz / 2;
      var col = p >= 55 ? '#10b981' : p >= 40 ? '#38bdf8' : '#f43f5e';
      return '<svg class="kring" viewBox="0 0 ' + sz + ' ' + sz + '">'
        + '<circle cx="' + h + '" cy="' + h + '" r="' + r + '" stroke="rgba(125,211,252,0.16)"/>'
        + '<circle cx="' + h + '" cy="' + h + '" r="' + r + '" stroke="' + col + '" stroke-linecap="round" stroke-dasharray="' + (L * p / 100) + ' ' + L + '" transform="rotate(-90 ' + h + ' ' + h + ')"/>'
        + '<text x="' + h + '" y="' + (h + 7) + '" text-anchor="middle">' + p + '%</text></svg>';
    }

    function computePillars() {
      var sig = ok(function () { return signif(c); });
      if (!sig) return [];
      var defs = [
        [T('ධනය', 'Wealth'), 1, [2, 6, 10, 11], [5, 8, 12], 't17'],
        [T('රැකියාව', 'Career'), 9, [2, 6, 10, 11], [5, 8, 12], 't15'],
        [T('විවාහය', 'Marriage'), 6, [2, 7, 11], [1, 6, 10], 't8'],
        [T('අධ්‍යාපන', 'Education'), 3, [4, 9, 11], [3, 8, 12], 't5'],
        [T('විදේශ', 'Foreign'), 11, [3, 9, 12], [2, 4, 11], 't17'],
        [T('සෞඛ්‍යය', 'Health'), 0, [1, 5, 11], [6, 8, 12], 't14']
      ];
      return defs.map(function (df) {
        var cslCode = P[lords(c.cs[df[1]]).sl];
        var levels = sig[cslCode] || [[], [], [], [], []];
        var w = [4, 3, 2, 1.5, 1], pos = 0, neg = 0, tot = 0;
        levels.forEach(function (arr, li) {
          (arr || []).forEach(function (h) {
            tot += w[li];
            if (df[2].indexOf(h) !== -1) pos += w[li];
            if (df[3].indexOf(h) !== -1) neg += w[li];
          });
        });
        var raw = tot > 0 ? Math.round(50 + ((pos - neg) / (tot + 2)) * 55) : 50;
        var pct = Math.max(18, Math.min(96, raw));
        return { label: df[0], pct: pct, csl: PLN[lords(c.cs[df[1]]).sl], tab: df[4] };
      });
    }

    // Compute KP Lucky Planets, Days, Colors, Numbers & Caution Planets from real signif(c)
    function computeLucky() {
      var sig = ok(function () { return signif(c); });
      if (!sig) return null;
      var goodH = [1, 2, 5, 9, 10, 11], badH = [6, 8, 12], w = [4, 3, 2, 1.5, 1];
      var scored = ['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'].map(function (p) {
        var lv = sig[p] || [], s = 0;
        lv.forEach(function (arr, li) {
          (arr || []).forEach(function (h) {
            if (goodH.indexOf(h) !== -1) s += w[li];
            if (badH.indexOf(h) !== -1) s -= w[li] * 1.1;
          });
        });
        return { p: p, s: s };
      }).sort(function (a, b) { return b.s - a.s; });

      var top2 = scored.slice(0, 2).map(function (x) { return PL_META[x.p]; });
      var bot2 = scored.slice(-2).reverse().map(function (x) { return PL_META[x.p]; });
      return {
        benefic: top2.map(function (m) { return SI ? m.si : m.en; }).join(', '),
        caution: bot2.map(function (m) { return SI ? m.si : m.en; }).join(', '),
        days: top2.map(function (m) { return SI ? m.daySi : m.dayEn; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).join(' · '),
        colors: top2.map(function (m) { return SI ? m.colSi : m.colEn; }).join(' / '),
        nums: top2.map(function (m) { return m.num; }).join(', '),
        dir: SI ? top2[0].dirSi : top2[0].dirEn
      };
    }

    /* ---------- 0 · Landing Welcome Banner + Quick AI + Instant Random Horary ---------- */
    function buildWelcome() {
      if (E('kp-welcome')) return;
      var tp = E('tp'); if (!tp) return;
      var w = document.createElement('div');
      w.id = 'kp-welcome';
      w.innerHTML =
        '<div class="kw-title">✦ ' + T('ක්‍රිෂ්ණමූර්ති පද්ධති <span>KP AI Pro</span>', 'Krishnamurti Paddhati <span>KP AI Pro</span>') + '</div>' +
        '<div class="kw-desc">' + T('නිවැරදි උප අධිපති (Sub-Lord) ගණනය, API Key නැති Free KP AI ගුරු (Pollinations + AI Horde GPU + Offline 447), BTR, Horary 1–249 සහ විවාහ ගැළපීම.', 'Precision KP Sub-Lord engine, Zero-Key Free AI Guru (Pollinations + AI Horde GPUs + Offline 447), BTR, Horary 1–249 & Marriage Match.') + '</div>' +
        '<div class="kw-badges">' +
          '<b class="g">✓ ' + T('සියල්ල අන්ලොක්', 'All Unlocked') + '</b>' +
          '<b>🤖 Free AI (No Key)</b>' +
          '<b>KP නීති 447</b>' +
          '<b>Horary 1–249</b>' +
          '<b>PDF Export</b>' +
        '</div>' +
        '<div class="kw-quick">' +
          '<button type="button" class="p" id="kw-now">⚡ ' + T('දැන් වේලාවෙන් පත්‍රය', 'Instant Chart (Now)') + '</button>' +
          '<button type="button" id="kw-ai">🤖 ' + T('KP AI ගුරු අසන්න', 'Ask KP AI Guru') + '</button>' +
          '<button type="button" id="kw-hor">🎲 ' + T('Horary 1–249', 'Horary 1–249') + '</button>' +
        '</div>' +
        '<button type="button" id="kp-install-btn">📲 ' + T('ඇප් එක දුරකථනයට ස්ථාපනය කරන්න (Install App)', 'Install KP AI Pro App') + '</button>';
      tp.insertAdjacentElement('afterend', w);

      if (S.installPrompt) E('kp-install-btn').classList.add('show');
      E('kp-install-btn').onclick = function () {
        if (!S.installPrompt) return;
        S.installPrompt.prompt();
        S.installPrompt.userChoice.finally(function () { S.installPrompt = null; E('kp-install-btn').classList.remove('show'); });
      };
      E('kw-now').onclick = function () {
        if (E('now')) E('now').click();
        if (E('la') && !E('la').value) { E('la').value = '6.9271'; E('lo').value = '79.8612'; E('tz').value = '5.5'; if (E('pl')) E('pl').value = 'Colombo'; }
        if (E('b1')) E('b1').click();
      };
      E('kw-ai').onclick = function () {
        // If no chart yet, cast instant current chart or open AI directly
        if (!c) {
          if (E('now')) E('now').click();
          if (E('la') && !E('la').value) { E('la').value = '6.9271'; E('lo').value = '79.8612'; E('tz').value = '5.5'; if (E('pl')) E('pl').value = 'Colombo'; }
          if (E('b1')) E('b1').click();
          setTimeout(function () { if (c) nvB('t18', ''); }, 140);
        } else {
          nvB('t18', '');
        }
      };
      E('kw-hor').onclick = function () {
        if (E('now')) E('now').click();
        var adv = $$('details.adv').find(function (d) { return d.textContent.indexOf('Horary') !== -1; });
        if (adv) {
          var stepBtn = document.querySelector('.kprog span[data-i="2"]');
          if (stepBtn) stepBtn.click();
          adv.open = true;
          adv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      };

      // Inject 1-tap Random 1–249 Horary Number Generator button next to #hb
      var hb = E('hb');
      if (hb && !E('kp-rand-hn')) {
        var rb = document.createElement('button');
        rb.id = 'kp-rand-hn';
        rb.type = 'button';
        rb.textContent = '🎲 ' + T('අහඹු අංකයක් (1–249)', 'Random 1–249');
        rb.onclick = function () {
          var n = Math.floor(Math.random() * 249) + 1;
          if (E('hn')) E('hn').value = n;
          if (E('now')) E('now').click();
          mnToast(T('🎲 KP Horary අංකය: ', '🎲 KP Horary Number: ') + n);
        };
        hb.parentNode.insertBefore(rb, hb);
      }
    }

    var QUICK_TABS = [
      ['t18', T('🤖 AI ගුරු', '🤖 AI Guru'), '', true],
      ['t1', T('ලග්න', 'Chart'), ''],
      ['t2', T('භාව', 'Houses'), ''],
      ['t3', T('Signif.', 'Signif.'), ''],
      ['t4', T('දශා', 'Dasha'), ''],
      ['t5', T('පලාපල', 'Forecast'), ''],
      ['t17', T('KP නීති 447', 'KP Rules'), ''],
      ['t6', T('ගෝචර', 'Transits'), ''],
      ['t7', T('සුබ දින', '42-Day'), ''],
      ['t16', T('Ruling RP', 'Live RP'), ''],
      ['t13', T('Horary', 'Horary'), ''],
      ['t9', T('BTR', 'BTR'), ''],
      ['t15', T('වෘත්ති', 'Career'), ''],
      ['t8', T('විවාහ', 'Match'), ''],
      ['t14', T('KP+', 'KP+'), 'kpPlus'],
      ['', T('📄 PDF', '📄 PDF'), 'pdf']
    ];

    /* ---------- 1 · Midnight-Cyan APEX Dashboard ---------- */
    function buildSum() {
      var res = E('res'); if (!res || !c) return;
      var d = ok(function () { return dayScore(today()); });
      var lg = Math.floor(c.cs[0] / 30), lgDeg = dms(c.cs[0] % 30);
      var lgL = ok(function () { return lords(c.cs[0]); });
      var mo = c.pl.Mo, mn = Math.floor(mo / 30), moL = ok(function () { return lords(mo); });
      var nk = Math.floor(mo / (40 / 3)), pd = Math.floor((mo / (40 / 3) % 1) * 4) + 1;
      var ds = ok(curDashaObj) || { names: [], end: '' };
      var pn = livePanchanga();
      var nm = (E('nm') && E('nm').value.trim()) || T('ජන්ම පත්‍රය', 'Birth Chart');
      var best = d ? d.r.map(function (v, i) { return [v, i]; }).sort(function (a, b) { return b[0] - a[0]; })[0] : null;
      var avg = d ? d.avg : 50;
      var moodCls = avg >= 55 ? 'ok' : avg >= 40 ? 'mid' : 'bad';
      var moodTxt = avg >= 55 ? T('සුබ දිනයක් (Strong)', 'Favorable (Strong)')
                  : avg >= 40 ? T('සමබර දිනයක් (Balanced)', 'Balanced Day')
                  : T('ප්‍රවේශම් වන්න (Caution)', 'Caution Advised');
      var pillars = ok(computePillars) || [];
      var lucky = ok(computeLucky);

      var card = E('ksum');
      if (!card) {
        card = document.createElement('div');
        card.id = 'ksum';
        res.insertBefore(card, E('nv') || res.firstChild);
      }

      card.innerHTML =
        '<div class="kp-guard">' +
          '<div class="kp-guard-top">' +
            '<div class="kp-guard-title">🛡️ KP GUARD · ' + T('අද සජීවී පංචාංග & ලකුණු', 'LIVE KP & PANCHANGA') + '</div>' +
            '<span class="kp-pill ' + moodCls + '">' + avg + '%</span>' +
          '</div>' +
          '<div class="kp-guard-sub">' +
            '<span>💠 <b>' + moodTxt + '</b></span>' +
            (best ? '<span style="font-size:12px;color:var(--mu)">' + T('හොඳම: ', 'Best: ') + '<b style="color:var(--hl)">' + esc(TOP[best[1]][0]) + ' ' + best[0] + '%</b></span>' : '') +
          '</div>' +
          '<div class="kp-guard-meta">' +
            '<div>' + T('දින: ', 'Day: ') + '<b>' + pn.dayLord + '</b></div>' +
            '<div>' + T('හෝරාව: ', 'Hora: ') + '<b>' + pn.horaLord + ' (' + pn.horaLeft + ')</b></div>' +
            '<div class="' + (pn.inRahu ? 'rk-on' : 'rk-ok') + '">' + (pn.inRahu ? '⚠️ ' + T('දැන් රාහු කාලය! ', 'RAHU KALAYA! ') : '🧭 ' + T('රාහු: ', 'Rahu: ')) + pn.rahuText + '</div>' +
            '<div>⏱ <b id="kp-live-clk">' + pn.time + '</b></div>' +
          '</div>' +
        '</div>' +

        '<div class="kp-strip-wrap"><div class="kp-strip" id="kp-qstrip">' +
          QUICK_TABS.map(function (q) {
            return '<button type="button" class="' + (q[3] ? 'ai-q' : '') + '" data-qt="' + q[0] + '" data-qf="' + q[2] + '">' + q[1] + '</button>';
          }).join('') +
        '</div></div>' +

        '<div class="kp-hero">' +
          '<div style="min-width:0;flex:1">' +
            '<div class="kp-hero-name">' + esc(nm) + ' <span class="kp-tag">KP AI PRO</span></div>' +
            '<div class="kp-hero-big">' + SGN[lg] + ' ' + lgDeg + '</div>' +
            (lgL ? '<div class="kp-chain">' +
              '<span>RL <b>' + PLN[lgL.rl] + '</b></span>' +
              '<span>NL <b>' + PLN[lgL.nl] + '</b></span>' +
              '<span>SL <b>' + PLN[lgL.sl] + '</b></span>' +
              '<span class="ssl">SSL <b>' + PLN[lgL.ssl] + '</b></span>' +
            '</div>' : '') +
          '</div>' +
          (d ? ringSvg(avg, 84) : '') +
        '</div>' +

        '<div class="ks-g">' +
          '<div><small>' + T('චන්ද්‍ර රාශිය & නැකත', 'MOON & NAKSHATRA') + '</small><b>' + SGN[mn] + ' · ' + NKN[nk % 27] + '</b><span class="ksub">' + T('පාදය ', 'Pada ') + pd + (moL ? ' · SL ' + PLN[moL.sl] : '') + '</span></div>' +
          '<div><small>' + T('BTR මූලික (SSL)', 'BTR KEY (SSL)') + '</small><b>' + (lgL ? 'SSL: ' + PLN[lgL.ssl] : '—') + '</b><span class="ksub">' + (moL ? T('චන්ද්‍ර SSL: ', 'Moon SSL: ') + PLN[moL.ssl] : '') + '</span></div>' +
          '<div><small>' + T('දැන් දශාව (DBA)', 'RUNNING DASHA') + '</small><b style="color:var(--ac)">' + (ds.names.join(' - ') || '—') + '</b><span class="ksub">' + (ds.end ? T('අවසන්: ', 'Until: ') + ds.end : today()) + '</span></div>' +
          '<div><small>' + T('සුබ / අසුබ සමතුලිතය', 'STRENGTH RATIO') + '</small><b>' + avg + '% / ' + (100 - avg) + '%</b><div class="kbar-mini"><i style="width:' + avg + '%"></i></div><div class="kbar-lbl"><span class="ok">' + T('සුබ', 'Positive') + '</span><span class="bd">' + T('බාධා', 'Caution') + '</span></div></div>' +
        '</div>' +

        (pillars.length ? '<div class="kp-pillars">' +
          '<div class="kp-pillars-hd"><span>✦ ' + T('ප්‍රධාන භාව උප-අධිපති පොරොන්දුව (CSL)', 'KP CUSPAL SUB-LORD PROMISE') + '</span><span style="color:var(--mu);font-weight:600">' + T('ටැප් කර බලන්න', 'Tap to view') + '</span></div>' +
          '<div class="kp-pgrid">' +
            pillars.map(function (pl) {
              var cls = pl.pct >= 60 ? 'ok' : pl.pct >= 42 ? 'mid' : 'bad';
              var bg = pl.pct >= 60 ? '#10b981' : pl.pct >= 42 ? '#38bdf8' : '#f43f5e';
              return '<div class="kp-pitem" data-ptab="' + pl.tab + '">' +
                '<span class="plb">' + pl.label + ' (' + pl.csl + ')</span>' +
                '<span class="pval ' + cls + '">' + pl.pct + '%</span>' +
                '<div class="pbar"><i style="width:' + pl.pct + '%;background:' + bg + '"></i></div>' +
              '</div>';
            }).join('') +
          '</div>' +
        '</div>' : '') +

        (lucky ? '<details class="kp-lucky"><summary style="cursor:pointer;font-size:12px;font-weight:800;color:var(--ac);list-style:none">💎 ' + T('KP වාසනාවන්ත අංක, වර්ණ, දින & සුබ ග්‍රහයන් ▾', 'KP Lucky Numbers, Colors, Days & Benefic Planets ▾') + '</summary>' +
          '<div class="kl-grid" style="margin-top:9px">' +
            '<div class="kl-box"><small>🌟 ' + T('ප්‍රබල සුබ ග්‍රහයන්', 'Benefic Significators') + '</small><b style="color:var(--hl)">' + lucky.benefic + '</b></div>' +
            '<div class="kl-box"><small>⚠️ ' + T('ප්‍රවේශම් ග්‍රහයන් (6/8/12)', 'Caution Planets') + '</small><b style="color:var(--hn)">' + lucky.caution + '</b></div>' +
            '<div class="kl-box"><small>📅 ' + T('සුබ දින & දිශාව', 'Lucky Days & Dir') + '</small><b>' + lucky.days + ' · ' + lucky.dir + '</b></div>' +
            '<div class="kl-box"><small>🎨 ' + T('සුබ වර්ණ & අංක', 'Lucky Colors & Nos') + '</small><b>' + lucky.colors + ' (' + lucky.nums + ')</b></div>' +
          '</div>' +
          '<div class="kl-note">' + T('සටහන: ඔබේ KP Significator මට්ටම් අනුව 2, 5, 9, 10, 11 ප්‍රබල කරන ග්‍රහයන් තෝරා ගණනය කර ඇත.', 'Calculated directly from your KP 4-level Significators favoring houses 2, 5, 9, 10, 11.') + '</div>' +
        '</details>' : '') +

        '<div class="ks-a">' +
          '<button type="button" class="p" id="kai-go">🤖 ' + T('KP AI ගුරුගෙන් අසන්න', 'Ask KP AI Guru') + '</button>' +
          '<button type="button" id="ksh">📤 ' + T('WhatsApp කාඩ්පත', 'Share Card') + '</button>' +
        '</div>';

      E('ksh').onclick = share;
      E('kai-go').onclick = function () { nvB('t18', ''); window.scrollTo(0, 0); };
      E('kp-qstrip').onclick = function (e) {
        var b = e.target.closest('button[data-qt]');
        if (!b || !c) return;
        nvB(b.dataset.qt, b.dataset.qf || '');
      };
      $$('.kp-pitem', card).forEach(function (el) {
        el.onclick = function () { if (!c) return; nvB(el.dataset.ptab, el.dataset.ptab === 't14' ? 'kpPlus' : ''); };
      });

      if (S.clockTimer) clearInterval(S.clockTimer);
      S.clockTimer = setInterval(function () {
        var ck = E('kp-live-clk');
        if (!ck) return;
        var nt = new Date().toTimeString().slice(0, 5);
        if (ck.textContent !== nt) {
          if (ob) ob.disconnect();
          ck.textContent = nt;
          if (ob) ob.observe(document.body, OBC);
        }
      }, 30000);

      S.day = d;
    }

    /* ---------- 2 · Midnight-Cyan WhatsApp Share Card ---------- */
    function share() {
      var go = function () { ok(drawShare); };
      if (document.fonts && document.fonts.load) document.fonts.load('700 40px "Noto Sans Sinhala"').then(go, go);
      else go();
    }
    function drawShare() {
      var W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      var x = cv.getContext('2d'), F = '"Noto Sans Sinhala","Inter",system-ui,sans-serif';
      var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#060d14'); g.addColorStop(1, '#0c2436');
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      var rg = x.createRadialGradient(W * 0.8, 0, 20, W * 0.8, 0, 560);
      rg.addColorStop(0, 'rgba(56,189,248,0.28)'); rg.addColorStop(1, 'transparent');
      x.fillStyle = rg; x.fillRect(0, 0, W, H);

      var d = S.day || dayScore(today()), nm = (E('nm') && E('nm').value) || '', lg = Math.floor(c.cs[0] / 30), mn = Math.floor(c.pl.Mo / 30), nk = Math.floor(c.pl.Mo / (40 / 3)) % 27;
      function tx(s, px, py, sz, col, w, al, mx) {
        x.font = (w || 600) + ' ' + sz + 'px ' + F; x.fillStyle = col; x.textAlign = al || 'left'; s = String(s);
        if (mx) while (x.measureText(s).width > mx && s.length > 2) s = s.slice(0, -2);
        x.fillText(s, px, py);
      }
      tx('✦ KP ASTROLOGY AI PRO', 60, 100, 44, '#38bdf8', 800);
      tx(today() + (nm ? '  ·  ' + nm : ''), 60, 158, 30, '#82a4b8', 500, 'left', 960);
      var cx = 215, cy = 380, r = 118, p = d.avg, col = p >= 55 ? '#10b981' : p >= 40 ? '#38bdf8' : '#f43f5e';
      x.lineWidth = 22; x.lineCap = 'round'; x.strokeStyle = 'rgba(125,211,252,0.18)'; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.stroke();
      x.strokeStyle = col; x.beginPath(); x.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p / 100); x.stroke();
      tx(p + '%', cx, cy + 22, 62, '#eef7fb', 700, 'center');
      tx(T('අද ලකුණු', 'TODAY'), cx, cy + r + 58, 28, '#82a4b8', 600, 'center');
      var ds = ok(curDashaObj) || { names: [] };
      var rows = [
        [T('ලග්නය', 'Lagna'), SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°'],
        [T('චන්ද්‍ර රාශිය', 'Moon'), SGN[mn]],
        [T('නැකත', 'Nakshatra'), NKN[nk]],
        [T('දශාව', 'Dasha'), ds.names.join(' - ') || '—']
      ];
      rows.forEach(function (r2, i) { var y = 290 + i * 58; tx(r2[0], 440, y, 26, '#82a4b8', 500); tx(r2[1], 650, y, 30, '#eef7fb', 700, 'left', 370); });
      tx(T('අද ප්‍රබල ක්ෂේත්‍ර', 'TOP FIELDS TODAY'), 60, 640, 34, '#38bdf8', 800);
      var top = d.r.map(function (v, i) { return [v, i]; }).sort(function (a, b) { return b[0] - a[0]; }).slice(0, 6);
      top.forEach(function (t, i) {
        var y = 705 + i * 86;
        tx(TOP[t[1]][0], 60, y, 30, '#eef7fb', 500, 'left', 550);
        x.fillStyle = 'rgba(125,211,252,0.16)'; x.fillRect(640, y - 24, 240, 16);
        x.fillStyle = t[0] >= 55 ? '#10b981' : t[0] >= 40 ? '#38bdf8' : '#f43f5e';
        x.fillRect(640, y - 24, 240 * t[0] / 100, 16);
        tx(t[0] + '%', 1020, y, 28, '#eef7fb', 700, 'right');
      });
      tx(T('ක්‍රිෂ්ණමූර්ති පද්ධතිය (KP) අනුව ගණනය කරන ලදී', 'Calculated with Krishnamurti Paddhati (KP)'), W / 2, H - 48, 24, '#648599', 500, 'center');
      cv.toBlob(function (b) {
        if (!b) return;
        var f; try { f = new File([b], 'kp-ai-pro-forecast.png', { type: 'image/png' }); } catch (e) {}
        var dl = function () {
          var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'kp-ai-pro-forecast.png';
          document.body.appendChild(a); a.click(); a.remove();
          mnToast(T('පින්තූරය සුරැකිණි — WhatsApp එකෙන් යවන්න', 'Image saved — share on WhatsApp'));
        };
        if (f && navigator.canShare && navigator.canShare({ files: [f] })) {
          navigator.share({ files: [f], title: 'KP Astrology AI Pro' }).catch(function (e) { if (!e || e.name !== 'AbortError') dl(); });
        } else dl();
      }, 'image/png');
    }

    /* ---------- 3 · Bottom Bar (with 🤖 AI ගුරු center highlight) ---------- */
    function buildBar() {
      var b = document.createElement('nav'); b.id = 'kbar';
      var it = [
        ['🪐', T('පත්‍රය', 'Chart'), 't1'],
        ['🔮', T('පලාපල', 'Forecast'), 't5'],
        ['🤖', T('AI ගුරු', 'AI Guru'), 't18'],
        ['📜', T('KP නීති', 'KP Rules'), 't17'],
        ['☰', T('මෙනුව', 'Menu'), '']
      ];
      b.innerHTML = it.map(function (x) { return '<button data-t="' + x[2] + '"><i>' + x[0] + '</i>' + x[1] + '</button>'; }).join('');
      b.onclick = function (e) {
        var q = e.target.closest('button'); if (!q) return;
        var t = q.dataset.t; if (!t) return mnO();
        if (!c) return; nvB(t, ''); window.scrollTo(0, 0);
      };
      document.body.appendChild(b);
    }
    function barState(t) {
      $$('#kbar button').forEach(function (b) { b.classList.toggle('on', !!b.dataset.t && b.dataset.t === t); });
      $$('#kp-qstrip button').forEach(function (b) { b.classList.toggle('on', !!b.dataset.qt && b.dataset.qt === t); });
    }

    /* ---------- 4 · Drawer Tiles, Tables, Charts, Heatmap, Wizard ---------- */
    var ICO = { t1:'🪐',t2:'🏠',t3:'⭐',t4:'⏳',t9:'🕰️',t5:'🔮',t12:'📊',t6:'🌍',t7:'🍀',t15:'💼',t8:'💍',t10:'📅',t11:'📜',t16:'🔱',t13:'🎯',t17:'📖',t18:'🤖',pdf:'📄',kpPlus:'🧰' };
    function tiles() {
      $$('#dw .pn button[onclick^="mnB"]').forEach(function (b) {
        if (b.querySelector('.ti')) return;
        var m = /mnB\('([^']*)','([^']*)'\)/.exec(b.getAttribute('onclick') || '');
        var k = m && (m[1] || m[2]), tx = b.textContent.trim().replace(/\s*🔒\s*$/, '');
        var em = /^(\p{Extended_Pictographic}\uFE0F?)\s*/u.exec(tx), ic = em ? em[1] : (ICO[k] || '✦');
        if (em) tx = tx.slice(em[0].length);
        b.innerHTML = '<span class="ti">' + ic + '</span><span>' + tx + '</span>';
      });
    }

    var RX = /^(AS|Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)(\(R\))?$/;
    function tables(root) {
      if (!root) return;
      $$('table', root).forEach(function (t) {
        if (!t.parentNode.classList.contains('tw')) {
          var w = document.createElement('div'); w.className = 'tw'; t.parentNode.insertBefore(w, t); w.appendChild(t);
        }
        if (t.dataset.kDone === String(t.rows.length)) return;
        t.dataset.kDone = String(t.rows.length);
        $$('td', t).forEach(function (td) {
          if (td.dataset.k) return; td.dataset.k = 1;
          var m = RX.exec(td.textContent.trim());
          if (m && td.children.length === 0) td.innerHTML = '<span class="pc pc-' + m[1] + '">' + m[1] + (m[2] ? '<sup>R</sup>' : '') + '</span>';
        });
      });
    }

    var SPOS = { 11:[0,0],0:[1,0],1:[2,0],2:[3,0],10:[0,1],3:[3,1],9:[0,2],4:[3,2],8:[0,3],7:[1,3],6:[2,3],5:[3,3] };
    function paint(sv) {
      $$('text', sv).forEach(function (t) {
        var m = /^(Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)/.exec(t.textContent);
        if (m && t.getAttribute('fill') !== 'var(--hn)') t.style.fill = PC[m[1]];
      });
    }
    function south() {
      var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 400 400'); s.setAttribute('class', 'ks');
      var lg = Math.floor(c.cs[0] / 30), by = {}, h = '<g fill="none" stroke="rgba(125,211,252,0.34)">';
      Object.keys(c.pl).forEach(function (p) { var sg = Math.floor(c.pl[p] / 30); (by[sg] = by[sg] || []).push([p, Math.floor(c.pl[p] % 30), !!(c.rt[p] || p == 'Ra' || p == 'Ke')]); });
      for (var sg = 0; sg < 12; sg++) { var q = SPOS[sg]; h += '<rect x="' + (q[0] * 100) + '" y="' + (q[1] * 100) + '" width="100" height="100"' + (sg == lg ? ' stroke="#38bdf8" stroke-width="2.8"' : '') + '/>'; }
      h += '</g>';
      for (sg = 0; sg < 12; sg++) {
        q = SPOS[sg]; var x0 = q[0] * 100 + 7, y0 = q[1] * 100;
        h += '<text x="' + (x0 + 86) + '" y="' + (y0 + 14) + '" text-anchor="end" fill="#82a4b8" style="font-size:9px;font-weight:500">' + SGN[sg].slice(0, 3) + '</text>';
        var L = (sg == lg ? [['As', null, 0]] : []).concat(by[sg] || []);
        L.forEach(function (e, i) {
          h += '<text x="' + x0 + '" y="' + (y0 + 30 + i * 14) + '" fill="' + (e[0] == 'As' ? '#38bdf8' : (PC[e[0]] || '#eef7fb')) + '" style="font-size:12px;font-weight:700">' + e[0] + (e[2] ? '*' : '') + (e[1] != null && e[0] != 'As' ? ' ' + e[1] : '') + '</text>';
        });
      }
      h += '<text x="200" y="196" text-anchor="middle" fill="#38bdf8" style="font-size:14px;font-weight:800">' + T('රාශි සටහන', 'Rasi Chart') + '</text>';
      h += '<text x="200" y="216" text-anchor="middle" fill="#82a4b8" style="font-size:11px;font-weight:500">' + SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°</text>';
      s.innerHTML = h; return s;
    }
    function charts() {
      var t1 = E('t1');
      if (t1 && c) {
        var sv = t1.querySelector('svg:not(.ks)');
        if (sv && !t1.querySelector('.kct')) {
          var bar = document.createElement('div'); bar.className = 'kct';
          bar.innerHTML = '<button data-s="S">▦ South (KP)</button><button data-s="N">◇ North</button>';
          sv.parentNode.insertBefore(bar, sv); var so = south(); sv.parentNode.insertBefore(so, sv.nextSibling);
          var ap = function (m) { sv.style.display = m == 'S' ? 'none' : ''; so.style.display = m == 'S' ? '' : 'none'; $$('button', bar).forEach(function (b) { b.className = b.dataset.s == m ? 'p' : ''; }); };
          bar.onclick = function (e) { var b = e.target.closest('button'); if (!b) return; try { localStorage.setItem('kpCs', b.dataset.s); } catch (x) {} ap(b.dataset.s); };
          ap((function () { try { return localStorage.getItem('kpCs') || 'S'; } catch (x) { return 'S'; } })());
        }
      }
      $$('.tab svg').forEach(function (sv) {
        if (sv.dataset.k || sv.getAttribute('viewBox') !== '0 0 400 400') return;
        sv.dataset.k = 1; paint(sv);
        sv.addEventListener('click', function () {
          var z = E('czm');
          if (!z) { z = document.createElement('div'); z.id = 'czm'; z.onclick = function () { z.classList.remove('on'); }; document.body.appendChild(z); }
          z.innerHTML = '<i>✕</i>'; var cl = sv.cloneNode(true); cl.style.display = ''; cl.removeAttribute('class'); z.appendChild(cl); z.classList.add('on');
        });
      });
    }

    var HM = { c: null, d: {}, busy: 0 };
    function days42() { var n = new Date(), a = []; for (var i = 0; i < 42; i++) a.push(new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate() + i)).toISOString().slice(0, 10)); return a; }
    function heatRender() {
      var box = E('khm'); if (!box) return;
      var ds = days42(), v = ds.map(function (x) { return HM.d[x]; }).filter(function (z) { return z != null; });
      var mn = Math.min.apply(0, v), mx = Math.max.apply(0, v), first = new Date(ds[0] + 'T00:00:00Z').getUTCDay();
      var h = '<h3>' + T('දින 42 සුබ-අසුබ සිතියම', '42-Day KP Heatmap') + '</h3><div class="khw">' + WD.map(function (w) { return '<i>' + w + '</i>'; }).join('');
      for (var i = 0; i < first; i++) h += '<b class="e"></b>';
      ds.forEach(function (x, i) {
        var s = HM.d[x]; if (s == null) { h += '<b class="sk"></b>'; return; }
        var t = mx > mn ? (s - mn) / (mx - mn) : 0.5;
        h += '<b class="' + (i == 0 ? 'td' : '') + '" data-d="' + x + '" data-v="' + s + '" style="background:hsl(' + Math.round(4 + 145 * t) + ' 65% var(--kl))">' + (+x.slice(8)) + '<small>' + s + '%</small></b>';
      });
      box.innerHTML = h + '</div><div class="khl"><span>' + T('අඩු', 'Low') + '</span><i></i><span>' + T('ඉහළ', 'High') + '</span></div>';
    }
    function heat() {
      var t7 = E('t7'); if (!t7 || t7.style.display !== 'block' || !c) return;
      if (!E('khm')) {
        var b = document.createElement('div'); b.id = 'khm'; b.className = 'card';
        b.onclick = function (e) { var q = e.target.closest('b[data-d]'); if (q) mnToast(q.dataset.d + ' — ' + q.dataset.v + '%'); };
        t7.insertBefore(b, t7.firstChild); heatRender();
      }
      if (HM.c !== c) HM = { c: c, d: {}, busy: 0 };
      var h = HM; if (h.busy) return;
      var todo = days42().filter(function (x) { return h.d[x] == null; }); if (!todo.length) return;
      h.busy = 1;
      (function step() {
        if (h.c !== c) return;
        todo.splice(0, 3).forEach(function (x) { h.d[x] = ok(function () { return dayScore(x).avg; }); if (h.d[x] == null) h.d[x] = 50; });
        heatRender(); if (todo.length) setTimeout(step, 0); else h.busy = 0;
      })();
    }

    function chips() {
      var box = E('pfc');
      if (!box) {
        box = document.createElement('div'); box.id = 'pfc';
        var anchor = E('kp-welcome') || E('tp');
        anchor.insertAdjacentElement('afterend', box);
      }
      var a = []; try { a = pg(); } catch (e) {}
      box.innerHTML = a.length ? '<div class="kpl">' + a.map(function (x, i) { return '<button class="kc" onclick="pfl(' + i + ')">👤 ' + esc(x.nm || '—') + '</button>'; }).join('') + '</div>' : '';
    }

    function wizard() {
      var card = $$('body > .card').find(function (el) { return $$('.sec', el).length >= 3; });
      if (!card || card.dataset.w) return;
      card.dataset.w = 1;
      card.classList.add('kp-form-card');
      var P3 = [0, 1, 2].map(function () { var d = document.createElement('div'); d.className = 'kstep'; return d; }), cur = 0, seen = 0;
      Array.prototype.slice.call(card.childNodes).forEach(function (n) {
        if (n.nodeType == 1 && n.classList.contains('sec')) cur = Math.min(seen++, 2);
        P3[cur].appendChild(n);
      });
      var nm = [T('පුද්ගල', 'Person'), T('දිනය/වේලාව', 'Date & Time'), T('ස්ථානය', 'Place')], pr = document.createElement('div');
      pr.className = 'kprog';
      pr.innerHTML = nm.map(function (n, i) { return '<span data-i="' + i + '"><b>' + (i + 1) + '</b>' + n + '</span>'; }).join('');
      card.appendChild(pr);
      P3.forEach(function (p, i) {
        var k = document.createElement('div'); k.className = 'kn';
        if (i > 0) k.innerHTML += '<button type="button" data-g="' + (i - 1) + '">⬅ ' + T('ආපසු', 'Back') + '</button>';
        if (i < 2) k.innerHTML += '<button type="button" class="p" data-g="' + (i + 1) + '">' + T('ඊළඟ', 'Next') + ' ➜</button>';
        p.appendChild(k); card.appendChild(p);
      });
      function set(n) {
        P3.forEach(function (p, i) { p.classList.toggle('on', i == n); });
        $$('span', pr).forEach(function (s, i) { s.className = i == n ? 'on' : i < n ? 'done' : ''; });
      }
      card.addEventListener('click', function (e) {
        var g = e.target.closest('[data-g]'), s = e.target.closest('.kprog span');
        if (g) set(+g.dataset.g); else if (s) set(+s.dataset.i);
      });
      set(0);
    }

    function skeleton() {
      var sk = document.createElement('div'); sk.id = 'ksk'; sk.innerHTML = '<div class="ksb"></div><div class="ksb"></div><div class="ksb"></div>'; document.body.appendChild(sk);
      document.addEventListener('click', function (e) {
        var b = e.target.closest && e.target.closest('#b1'); if (!b || b.dataset.go) return;
        e.stopImmediatePropagation(); e.preventDefault(); sk.classList.add('on');
        requestAnimationFrame(function () { setTimeout(function () { b.dataset.go = 1; try { b.click(); } finally { delete b.dataset.go; sk.classList.remove('on'); } }, 35); });
      }, true);
      var pl = window.pfl;
      if (pl) {
        window.pfl = function (i) {
          sk.classList.add('on');
          requestAnimationFrame(function () { setTimeout(function () { try { pl(i); } finally { sk.classList.remove('on'); } }, 35); });
        };
      }
    }

    var ob, tm, curTab = null, activeEl = null, pfSig = '', tilesDone = 0;
    function sync() {
      if (c && S.c !== c) { S.c = c; ok(buildSum); }
      var el0 = null, tabs = document.getElementsByClassName('tab');
      for (var i = 0; i < tabs.length; i++) { if (tabs[i].style.display === 'block') { el0 = tabs[i]; break; } }
      activeEl = el0;
      var t = el0 ? el0.id : '';
      if (t !== curTab) {
        curTab = t; barState(t);
        if (el0) { el0.classList.remove('kfade'); requestAnimationFrame(function () { el0.classList.add('kfade'); }); }
      }
    }
    function pfSync() {
      if (document.body.classList.contains('rv')) return;
      var s = ''; try { s = JSON.stringify(pg().map(function (x) { return x.nm; })); } catch (e) {}
      if (s !== pfSig) { pfSig = s; chips(); }
    }
    var OBC = { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] };
    function tick() {
      if (ob) ob.disconnect();
      ok(sync);
      if (E('dw') && !tilesDone) { ok(tiles); tilesDone = 1; }
      ok(pfSync);
      if (activeEl) { ok(function () { tables(activeEl); }); ok(charts); }
      if (curTab === 't7') ok(heat);
      if (ob) ob.observe(document.body, OBC);
    }

    ok(buildWelcome); ok(buildBar); ok(chips); ok(wizard); ok(skeleton);

    var RSK = ['g','nm','dt','tm','pl','la','lo','tz','ay','ao'];
    document.addEventListener('click', function (e) {
      if (!(e.target.closest && e.target.closest('#lgb')) || !c) return;
      var o = { t: curTab }; RSK.forEach(function (k) { if (E(k)) o[k] = E(k).value; });
      try { sessionStorage.setItem('kpRs', JSON.stringify(o)); } catch (x) {}
    }, true);
    ok(function () {
      var r = null; try { r = JSON.parse(sessionStorage.getItem('kpRs') || 'null'); sessionStorage.removeItem('kpRs'); } catch (x) {}
      if (!r) return;
      RSK.forEach(function (k) { if (E(k) && r[k] != null) E(k).value = r[k]; });
      ['la', 'lo'].forEach(function (k) { if (E(k)) E(k).dispatchEvent(new Event('input')); });
      setTimeout(function () {
        if (E('b1')) E('b1').click();
        var n = 0, iv = setInterval(function () {
          if (c || ++n > 60) { clearInterval(iv); if (c && r.t) ok(function () { nvB(r.t, ''); }); }
        }, 100);
      }, 60);
    });

    ob = new MutationObserver(function (muts) {
      var real = false;
      for (var i = 0; i < muts.length; i++) {
        var tg = muts[i].target;
        if (tg && tg.id === 'kp-live-clk') continue;
        if (tg && tg.id === 'dw') tilesDone = 0;
        real = true; break;
      }
      if (!real) return;
      clearTimeout(tm); tm = setTimeout(tick, 120);
    });
    tick();
  }
})();
