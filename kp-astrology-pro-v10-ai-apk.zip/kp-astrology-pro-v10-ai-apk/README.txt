KP ASTROLOGY AI PRO v10 — MIDNIGHT CYAN-BLACK + ZERO-KEY FREE AI + AUTO-APK
===========================================================================
1. ZERO-API-KEY FREE AI GURU (kp-ai.js):
   - Smart Auto failover: Pollinations Free AI (OpenAI/DeepSeek/Qwen/Mistral) -> AI Horde Live Community GPUs (anon 0000000000) -> Instant Offline KP 447-Rules Guru.
   - Reads your actual calculated KP chart (12 Cuspal Sub-Lords, Significators, DBA Dasha, 447 Rules).

2. DEPLOY TO NETLIFY DROP (Web + Installable PWA):
   - Drag & drop this ZIP directly to https://app.netlify.com/drop

3. BUILD ANDROID APK AUTOMATICALLY VIA GITHUB ACTIONS:
   - Unzip this ZIP and upload all files (including the .github folder!) to a new GitHub repository.
   - Open the "Actions" tab on GitHub -> wait ~2-3 minutes -> download "KP-Astrology-AI-Pro-v10-APK" from Artifacts!
   - Unzip the downloaded artifact to get KP-Astrology-AI-Pro-v10.apk and install on Android.
