/* ==========================================================================
   KP ASTROLOGY AI PRO — OFFLINE ASYMMETRIC ECDSA (secp256k1) LICENSE ENGINE
   Mobile: 2k/5k/9.5k/17.5k/35k | Windows PC: 3k/7.5k/15k/30k/50k
   ========================================================================== */
(function () {
  // Asymmetric secp256k1 Public Key ONLY (Safe to be public — Private signing key is NEVER in this app!)
  var PUB_X = '1d31fb603047fe257fa15a0f431dc034f4f913b481c42cefbe156ab41ff199fd';
  var PUB_Y = '27b464764ce688aeaa38c901534df4bc1e2cc41da1b3989f9fffbd27b7c40e50';
  var OWNER_WA = ''; // Optional: put '947XXXXXXXX' (no +) to open direct WhatsApp chat

  // Pure-JS Synchronous SHA-256 (works 100% offline in all WebViews / file:// / https://)
  function sha256(str) {
    var msg = unescape(encodeURIComponent(str));
    var K = [
      0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
      0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
      0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
      0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
      0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
      0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
      0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
      0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    ];
    var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    var l = msg.length, words = [];
    for (var i = 0; i < l; i++) words[i >> 2] |= (msg.charCodeAt(i) & 0xff) << (24 - (i % 4) * 8);
    words[l >> 2] |= 0x80 << (24 - (l % 4) * 8);
    words[(((l + 8) >> 6) + 1) * 16 - 1] = l * 8;
    var W = new Array(64);
    for (var b = 0; b < words.length; b += 16) {
      var a = H[0], b0 = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (var t = 0; t < 64; t++) {
        if (t < 16) W[t] = words[b + t] | 0;
        else {
          var s0 = ((W[t - 15] >>> 7) | (W[t - 15] << 25)) ^ ((W[t - 15] >>> 18) | (W[t - 15] << 14)) ^ (W[t - 15] >>> 3);
          var s1 = ((W[t - 2] >>> 17) | (W[t - 2] << 15)) ^ ((W[t - 2] >>> 19) | (W[t - 2] << 13)) ^ (W[t - 2] >>> 10);
          W[t] = (W[t - 16] + s0 + W[t - 7] + s1) | 0;
        }
        var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        var ch = (e & f) ^ ((~e) & g);
        var temp1 = (h + S1 + ch + K[t] + W[t]) | 0;
        var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        var maj = (a & b0) ^ (a & c) ^ (b0 & c);
        var temp2 = (S0 + maj) | 0;
        h = g; g = f; f = e; e = (d + temp1) | 0; d = c; c = b0; b0 = a; a = (temp1 + temp2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b0) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    var out = '';
    for (var j = 0; j < 8; j++) out += ('00000000' + (H[j] >>> 0).toString(16)).slice(-8);
    return out;
  }

  function isPC() {
    return !!(window.KPDesktop && window.KPDesktop.isDesktop) || /[?&]pc=1\b/.test(location.search);
  }

  var PLANS_MOBILE = [
    { id: '1M', si: 'මාස 1',      en: '1 Month',   price: 'Rs. 2,000',  days: 31,  tagSi: '',         tagEn: '' },
    { id: '3M', si: 'මාස 3',      en: '3 Months',  price: 'Rs. 5,000',  days: 93,  tagSi: '',         tagEn: '' },
    { id: '6M', si: 'මාස 6',      en: '6 Months',  price: 'Rs. 9,500',  days: 186, tagSi: '',         tagEn: '' },
    { id: '1Y', si: 'අවුරුදු 1',  en: '1 Year',    price: 'Rs. 17,500', days: 366, tagSi: '🔥 ජනප්‍රිය', tagEn: '🔥 Popular' },
    { id: 'LT', si: 'සදාකාලික',   en: 'Lifetime',  price: 'Rs. 35,000', days: 0,   tagSi: '⭐ හොඳම',  tagEn: '⭐ Best Value' }
  ];

  var PLANS_PC = [
    { id: '1M', si: 'මාස 1',      en: '1 Month',   price: 'Rs. 3,000',  days: 31,  tagSi: '',         tagEn: '' },
    { id: '3M', si: 'මාස 3',      en: '3 Months',  price: 'Rs. 7,500',  days: 93,  tagSi: '',         tagEn: '' },
    { id: '6M', si: 'මාස 6',      en: '6 Months',  price: 'Rs. 15,000', days: 186, tagSi: '',         tagEn: '' },
    { id: '1Y', si: 'අවුරුදු 1',  en: '1 Year',    price: 'Rs. 30,000', days: 366, tagSi: '🔥 ජනප්‍රිය', tagEn: '🔥 Popular' },
    { id: 'LT', si: 'සදාකාලික',   en: 'Lifetime',  price: 'Rs. 50,000', days: 0,   tagSi: '⭐ හොඳම',  tagEn: '⭐ Best Value' }
  ];

  var PLANS = isPC() ? PLANS_PC : PLANS_MOBILE;

  function isSI() {
    try { return /[\u0D80-\u0DFF]/.test((window.KPB && window.KPB.NAV && window.KPB.NAV[0] && window.KPB.NAV[0][0]) || document.title || ''); }
    catch (e) { return true; }
  }
  function LT(a, b) { return isSI() ? a : b; }

  function getDeviceId() {
    try {
      if (window.KPDesktop && typeof window.KPDesktop.getHardwareId === 'function') {
        var hwid = window.KPDesktop.getHardwareId();
        if (/^KP-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(hwid)) {
          try { localStorage.setItem('kp_dev_id', hwid); localStorage.setItem('kp_dev_id_b', hwid); } catch (e) {}
          return hwid;
        }
      }
    } catch (e) {}
    var id = '';
    try { id = localStorage.getItem('kp_dev_id') || localStorage.getItem('kp_dev_id_b') || ''; } catch (e) {}
    if (!/^KP-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(id)) {
      var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', s1 = '', s2 = '';
      var arr = new Uint32Array(8);
      if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(arr);
      else for (var k = 0; k < 8; k++) arr[k] = Math.floor(Math.random() * 1e9);
      for (var i = 0; i < 4; i++) { s1 += chars[arr[i] % chars.length]; s2 += chars[arr[i + 4] % chars.length]; }
      id = 'KP-' + s1 + '-' + s2;
    }
    try { localStorage.setItem('kp_dev_id', id); localStorage.setItem('kp_dev_id_b', id); } catch (e) {}
    return id;
  }

  function effNowMs() {
    var now = Date.now(), maxSeen = now;
    try {
      var prev = Number(localStorage.getItem('kp_lic_ts') || '0');
      if (isFinite(prev) && prev > now) maxSeen = prev;
      else localStorage.setItem('kp_lic_ts', String(now));
    } catch (e) {}
    return maxSeen;
  }

  function parseYmdEnd(ymd) {
    var y = +ymd.slice(0, 4), m = +ymd.slice(4, 6) - 1, d = +ymd.slice(6, 8);
    return new Date(y, m, d, 23, 59, 59, 999).getTime();
  }

  function fmtYmd(ymd) {
    if (ymd === '99991231') return LT('සදාකාලික (Lifetime)', 'Lifetime (Never Expires)');
    return ymd.slice(0, 4) + '-' + ymd.slice(4, 6) + '-' + ymd.slice(6, 8);
  }

  // Pure-JS BigInt secp256k1 Schnorr Public-Key Verifier (100% Offline, Works on file:// & WebView)
  var Z0 = BigInt(0), Z1 = BigInt(1), Z2 = BigInt(2), Z3 = BigInt(3), Z5 = BigInt(5), Z256 = BigInt(256);
  var MASK256 = (Z1 << Z256) - Z1;
  var LIM128 = Z1 << BigInt(128);
  var EC_P = BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F');
  var EC_N = BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141');
  var EC_G = [
    BigInt('0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798'),
    BigInt('0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8')
  ];
  var EC_Q_NEG = [
    BigInt('0x' + PUB_X),
    EC_P - BigInt('0x' + PUB_Y)
  ];
  var B32_ALPH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  function ecMod(a, m) {
    var r = a % m;
    return r < Z0 ? r + m : r;
  }
  function ecModInv(a, m) {
    var t = Z0, nt = Z1, r = m, nr = ecMod(a, m);
    while (nr !== Z0) {
      var q = r / nr;
      var tt = t - q * nt; t = nt; nt = tt;
      var tr = r - q * nr; r = nr; nr = tr;
    }
    if (r !== Z1) return Z0;
    return t < Z0 ? t + m : t;
  }
  function ecAdd(p1, p2) {
    if (!p1) return p2;
    if (!p2) return p1;
    var x1 = p1[0], y1 = p1[1], x2 = p2[0], y2 = p2[1], lam;
    if (x1 === x2) {
      if (ecMod(y1 + y2, EC_P) === Z0) return null;
      lam = ecMod(Z3 * x1 * x1 * ecModInv(Z2 * y1, EC_P), EC_P);
    } else {
      lam = ecMod((y2 - y1) * ecModInv(x2 - x1, EC_P), EC_P);
    }
    var x3 = ecMod(lam * lam - x1 - x2, EC_P);
    var y3 = ecMod(lam * (x1 - x3) - y1, EC_P);
    return [x3, y3];
  }
  function ecMul(k, pt) {
    var res = null, add = pt, n = k;
    while (n > Z0) {
      if ((n & Z1) === Z1) res = ecAdd(res, add);
      add = ecAdd(add, add);
      n = n >> Z1;
    }
    return res;
  }
  function ecPad64(bi) {
    var h = bi.toString(16);
    while (h.length < 64) h = '0' + h;
    return h;
  }
  function b32Dec(str) {
    var v = Z0;
    for (var i = 0; i < str.length; i++) {
      var idx = B32_ALPH.indexOf(str.charAt(i));
      if (idx < 0) return null;
      v = (v << Z5) | BigInt(idx);
    }
    return v;
  }

  function verifyKey(rawKey, devId) {
    var k = String(rawKey || '').trim().toUpperCase().replace(/\s+/g, '');
    var m = /^KP(1M|3M|6M|1Y|LT)-(\d{8})-([A-Z2-9-]+)$/.exec(k);
    if (!m) return { ok: false, reason: 'format' };
    var plan = m[1], ymd = m[2], sigB32 = m[3].replace(/-/g, '');
    if (sigB32.length !== 77) return { ok: false, reason: 'format' };
    var packed = b32Dec(sigB32);
    if (packed === null) return { ok: false, reason: 'format' };
    var e = packed >> Z256;
    var s = packed & MASK256;
    if (e <= Z0 || e >= LIM128 || s <= Z0 || s >= EC_N) return { ok: false, reason: 'mismatch' };
    var R = null;
    try {
      R = ecAdd(ecMul(s, EC_G), ecMul(e, EC_Q_NEG));
    } catch (err) {
      return { ok: false, reason: 'mismatch' };
    }
    if (!R) return { ok: false, reason: 'mismatch' };
    var msg = 'KP43|' + devId + '|' + plan + '|' + ymd;
    var eCheck = BigInt('0x' + sha256(ecPad64(R[0]) + '|' + PUB_X + '|' + msg).slice(0, 32));
    if (eCheck !== e) return { ok: false, reason: 'mismatch' };
    var active = (ymd === '99991231') || (effNowMs() <= parseYmdEnd(ymd));
    var daysLeft = ymd === '99991231' ? 99999 : Math.max(0, Math.ceil((parseYmdEnd(ymd) - effNowMs()) / 86400000));
    var pObj = PLANS.find(function (p) { return p.id === plan; }) || PLANS[0];
    return {
      ok: true,
      active: active,
      plan: plan,
      planName: isSI() ? pObj.si : pObj.en,
      ymd: ymd,
      daysLeft: daysLeft,
      key: 'KP' + plan + '-' + ymd + '-' + sigB32
    };
  }

  function getStatus() {
    var devId = getDeviceId(), saved = '';
    try { saved = localStorage.getItem('kp_lic_key') || ''; } catch (e) {}
    if (!saved) return { active: false, expired: false, devId: devId };
    var res = verifyKey(saved, devId);
    res.devId = devId;
    return res;
  }

  var selPlan = 'LT';
  function openModal(reasonTxt) {
    var st = getStatus();
    var m = document.getElementById('kp-lic-modal');
    if (!m) {
      m = document.createElement('div');
      m.id = 'kp-lic-modal';
      document.body.appendChild(m);
    }
    m.innerHTML =
      '<div class="klm-sheet">' +
        '<div class="klm-head">' +
          '<span>' + (isPC() ? '💻 ' + LT('KP Astrology AI Pro — Windows PC බලපත්‍රය', 'KP Astrology AI Pro — Windows PC License') : '👑 ' + LT('KP Astrology AI Pro — බලපත්‍රය', 'KP Astrology AI Pro — License')) + '</span>' +
          '<button type="button" class="em-x" id="klm-x">✕</button>' +
        '</div>' +
        '<div class="klm-body">' +
          (st.expired ? '<div class="klm-exp">⚠️ ' + LT('ඔබේ පෙර බලපත්‍රය (' + fmtYmd(st.ymd) + ') කල් ඉකුත් වී ඇත. නැවත අලුත් කරගන්න.', 'Your previous license (' + fmtYmd(st.ymd) + ') has expired. Please renew.') + '</div>' : '') +
          (reasonTxt ? '<div class="klm-msg">' + reasonTxt + '</div>' : '<div class="klm-msg">' + LT('සියලුම වෘත්තීය KP අංග (භාව, Significators, මහා–ප්‍රාණ දශා, Horary 1–249, BTR, Ruling Planets, විවාහ, KP+, AI ගුරු සහ White-Label A4 PDF) සක්‍රීය කිරීමට පහත පැකේජයක් තෝරා Activation Key එක ඇතුළත් කරන්න.', 'Unlock all Pro KP tools (Cusps, Significators, 5-Level Dasha, Horary 1–249, BTR, Ruling Planets, Marriage Match, KP+, AI Guru & White-Label A4 PDF) with an offline device-locked Activation Key.') + '</div>') +

          '<div class="klm-dev">' +
            '<div><small>' + (isPC() ? LT('පරිගණක හැඳුනුම් අංකය (PC Hardware ID)', 'PC Hardware ID') : LT('ඔබේ දුරකථන අංකය (Device ID)', 'Your Device ID')) + '</small><b id="klm-did">' + st.devId + '</b></div>' +
            '<button type="button" id="klm-cp">📋 ' + LT('කොපි', 'Copy') + '</button>' +
          '</div>' +

          '<div class="klm-lbl">' + (isPC() ? LT('💻 Windows PC වෘත්තීය පැකේජය තෝරන්න (Hardware-Lock · 100% Offline)', '💻 Choose Windows PC Pro Plan (Hardware-Lock · 100% Offline)') : LT('💎 මිල පැකේජය තෝරන්න (Device-Lock · 100% Offline)', '💎 Choose a Plan (Device-Lock · 100% Offline)')) + '</div>' +
          '<div class="klm-plans" id="klm-plans">' +
            PLANS.map(function (pl) {
              var tg = isSI() ? pl.tagSi : pl.tagEn;
              return '<button type="button" class="klm-pl' + (selPlan === pl.id ? ' on' : '') + '" data-pl="' + pl.id + '">' +
                '<span class="klm-pl-n">' + (isSI() ? pl.si : pl.en) + (tg ? ' <em>' + tg + '</em>' : '') + '</span>' +
                '<b class="klm-pl-p">' + pl.price + '</b>' +
              '</button>';
            }).join('') +
          '</div>' +

          '<button type="button" class="klm-wa" id="klm-wa">💬 ' + LT('WhatsApp හරහා Activation Key එක ඉල්ලන්න', 'Request Activation Key on WhatsApp') + '</button>' +

          '<div class="klm-lbl" style="margin-top:12px">' + LT('🔑 Activation Key එක ඇතුළත් කරන්න', '🔑 Enter Activation Key') + '</div>' +
          '<div class="klm-inp-row">' +
            '<input id="klm-key" type="text" placeholder="KPLT-99991231-XXXX..." autocomplete="off" spellcheck="false">' +
            '<button type="button" id="klm-paste" title="' + LT('කොපි කළ Key එක පේස්ට් කරන්න', 'Paste Activation Key') + '">📋 ' + LT('පේස්ට්', 'Paste') + '</button>' +
            '<button type="button" class="p" id="klm-act">🔓 ' + LT('සක්‍රීය', 'Activate') + '</button>' +
          '</div>' +
          '<div id="klm-err" class="klm-err"></div>' +
          '<div class="klm-foot">' + (isPC() ? LT('සටහන: මෙම Activation Key එක මෙම පරිගණකයේ Hardware ID එකට පමණක් ලොක් වේ. සක්‍රීය කළ පසු අන්තර්ජාලය නොමැතිව 100% ඕෆ්ලයින් වැඩ කරයි.', 'Note: Permanently locked to this PC Hardware ID and works 100% offline once activated.') : LT('සටහන: එක් Key එකක් වලංගු වන්නේ මෙම දුරකථනයට (Device ID) පමණි. සක්‍රීය කළ පසු 100% ඕෆ්ලයින් වැඩ කරයි.', 'Note: Each key is permanently locked to this Device ID and works 100% offline once activated.')) + '</div>' +
        '</div>' +
      '</div>';

    m.classList.add('on');
    m.onclick = function (e) { if (e.target === m) m.classList.remove('on'); };
    document.getElementById('klm-x').onclick = function () { m.classList.remove('on'); };
    document.getElementById('klm-cp').onclick = function () {
      var copied = false;
      try {
        if (window.KPDesktop && typeof window.KPDesktop.writeClipboard === 'function') {
          window.KPDesktop.writeClipboard(st.devId);
          copied = true;
        }
      } catch (e) {}
      if (!copied) {
        try { navigator.clipboard.writeText(st.devId); copied = true; } catch (e) {}
      }
      if (!copied) {
        try {
          var ta = document.createElement('textarea');
          ta.value = st.devId; ta.style.cssText = 'position:fixed;left:-9999px;opacity:0';
          document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
        } catch (e) {}
      }
      if (window.KPB && window.KPB.mnToast) window.KPB.mnToast('📋 ' + LT('ID කොපි විය: ', 'Copied ID: ') + st.devId);
    };
    var pasteBtn = document.getElementById('klm-paste');
    if (pasteBtn) {
      pasteBtn.onclick = function () {
        var inp = document.getElementById('klm-key');
        var err = document.getElementById('klm-err');
        function applyPaste(txt) {
          var clean = String(txt || '').trim();
          if (!clean) {
            if (err) err.textContent = LT('⚠️ Clipboard එක හිස්ය — පළමුව Key එක Copy කරන්න.', '⚠️ Clipboard is empty — please copy your Key first.');
            return;
          }
          if (inp) { inp.value = clean; inp.focus(); }
          if (err) err.textContent = '';
          if (window.KPB && window.KPB.mnToast) window.KPB.mnToast('📋 ' + LT('Key එක පේස්ට් විය — දැන් "සක්‍රීය" ඔබන්න!', 'Key pasted — now click Activate!'));
        }
        try {
          if (window.KPDesktop && typeof window.KPDesktop.readClipboard === 'function') {
            applyPaste(window.KPDesktop.readClipboard());
            return;
          }
        } catch (e) {}
        if (navigator.clipboard && typeof navigator.clipboard.readText === 'function') {
          navigator.clipboard.readText().then(applyPaste, function () {
            if (inp) inp.focus();
            if (err) err.textContent = LT('ℹ️ කොටුව මත ක්ලික් කර Ctrl+V ඔබන්න.', 'ℹ️ Click inside the box and press Ctrl+V.');
          });
        } else {
          if (inp) inp.focus();
          if (err) err.textContent = LT('ℹ️ කොටුව මත ක්ලික් කර Ctrl+V ඔබන්න.', 'ℹ️ Click inside the box and press Ctrl+V.');
        }
      };
    }
    document.getElementById('klm-plans').onclick = function (e) {
      var b = e.target.closest('button[data-pl]');
      if (!b) return;
      selPlan = b.dataset.pl;
      Array.prototype.forEach.call(document.querySelectorAll('#klm-plans button'), function (x) { x.classList.toggle('on', x.dataset.pl === selPlan); });
    };
    document.getElementById('klm-wa').onclick = function () {
      var pObj = PLANS.find(function (p) { return p.id === selPlan; }) || PLANS[4];
      var edSi = isPC() ? '💻 Windows PC Software' : '📱 Android Mobile App';
      var edEn = isPC() ? '💻 Windows PC Software' : '📱 Android Mobile App';
      var idLbl = isPC() ? '💻 PC Hardware ID: ' : '📱 Device ID: ';
      var msg = LT(
        'ආයුබෝවන්! මට KP Astrology AI Pro (' + edSi + ') බලපත්‍රයක් (Activation Key) අවශ්‍යයි.\n\n' + idLbl + st.devId + '\n💎 පැකේජය: ' + pObj.si + ' (' + pObj.price + ')',
        'Hello! I would like to purchase a KP Astrology AI Pro (' + edEn + ') Activation Key.\n\n' + idLbl + st.devId + '\n💎 Plan: ' + pObj.en + ' (' + pObj.price + ')'
      );
      var url = OWNER_WA ? ('https://wa.me/' + OWNER_WA + '?text=' + encodeURIComponent(msg)) : ('https://wa.me/?text=' + encodeURIComponent(msg));
      window.open(url, '_blank');
    };
    document.getElementById('klm-act').onclick = function () {
      var val = (document.getElementById('klm-key').value || '').trim();
      var err = document.getElementById('klm-err');
      var r = verifyKey(val, st.devId);
      if (!r.ok) {
        err.textContent = r.reason === 'mismatch'
          ? LT('❌ මෙම Key එක ඔබේ Device ID (' + st.devId + ') සඳහා වලංගු නැත!', '❌ Key does not match your Device ID (' + st.devId + ')!')
          : LT('❌ Key ආකෘතිය වැරදියි. නිවැරදි Key එක copy-paste කරන්න.', '❌ Invalid key format. Please paste the exact Activation Key.');
        return;
      }
      if (!r.active) {
        err.textContent = LT('❌ මෙම Activation Key එක කල් ඉකුත් වී ඇත (' + fmtYmd(r.ymd) + ').', '❌ This Activation Key has expired (' + fmtYmd(r.ymd) + ').');
        return;
      }
      try { localStorage.setItem('kp_lic_key', r.key); } catch (e) {}
      m.classList.remove('on');
      if (window.KPB && window.KPB.mnToast) window.KPB.mnToast('🎉 ' + LT('PRO බලපත්‍රය සක්‍රීය විය! (' + r.planName + ')', 'PRO License Activated! (' + r.planName + ')'));
      if (window.kpRefreshLicUI) window.kpRefreshLicUI();
    };
  }

  // Free preview allows: Lagna Chart (t1) only; all other tabs/tools require active Pro license
  function allow(tab, fn) {
    if ((tab === 't1' || tab === 't22' || tab === 't26') && !fn) return true;
    var st = getStatus();
    if (st.active) return true;
    openModal();
    return false;
  }

  window.KPLic = {
    PLANS: PLANS,
    isPC: isPC,
    getDeviceId: getDeviceId,
    getStatus: getStatus,
    verifyKey: verifyKey,
    openModal: openModal,
    allow: allow,
    fmtYmd: fmtYmd
  };
})();

/* ==========================================================================
   KP ASTROLOGY AI PRO v20 — TRUE MULTI-SCREEN NATIVE ANDROID 120HZ UI ENGINE
   Screens: home | form | horary | profiles | settings | page
   ========================================================================== */
(function () {
  if (!window.KPB || /[?&]plain\b/.test(location.search)) return;
  with (window.KPB) {
    var SI = /[\u0D80-\u0DFF]/.test((typeof NAV !== 'undefined' && NAV[0] && NAV[0][0]) || '');
    var T = function (a, b) { return SI ? a : b; };
    var E = function (i) { return document.getElementById(i); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
    var ok = function (f) { try { return f(); } catch (e) { if (window.console) console.warn('kp-ui', e); } };

    // Default Theme: Crisp "Tharu Kirana" Light Studio on Windows PC, Midnight-Cyan Dark on Mobile
    var _isDesktopPC = !!(window.KPDesktop && window.KPDesktop.isDesktop) || /[?&]pc=1\b/.test(location.search);
    if (_isDesktopPC) document.documentElement.classList.add('kp-pc');
    try {
      if (_isDesktopPC) {
        var pcSaved = localStorage.getItem('kpt_pc_v44');
        var pcMode = (pcSaved === 'dark' || pcSaved === 'light') ? pcSaved : 'light';
        document.documentElement.dataset.t = pcMode;
        localStorage.setItem('kpt_pc_v44', pcMode);
        localStorage.setItem('kpt_v10', pcMode);
      } else if (!localStorage.getItem('kpt_v10')) {
        document.documentElement.dataset.t = 'dark';
        localStorage.setItem('kpt_v10', 'dark');
      }
    } catch (e) {}

    function syncThemeIcon() {
      var btn = E('th');
      if (!btn) return;
      btn.textContent = document.documentElement.dataset.t === 'light' ? '🌙' : '☀️';
      btn.setAttribute('aria-label', T('තේමාව මාරු කරන්න', 'Toggle theme'));
    }
    syncThemeIcon();
    if (E('th')) E('th').addEventListener('click', function () {
      setTimeout(function () {
        syncThemeIcon();
        if (_isDesktopPC) {
          try { localStorage.setItem('kpt_pc_v44', document.documentElement.dataset.t || 'light'); } catch (e) {}
        }
      }, 15);
    });

    if (SI) {
      document.body.classList.add('si');
      var flk = document.createElement('link');
      flk.rel = 'stylesheet';
      flk.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Sinhala:wght@400;600;700&display=swap';
      document.head.appendChild(flk);
    }
    if (E('lgb')) E('lgb').textContent = SI ? 'සිං/EN' : 'EN/සිං';
    if (E('aysub')) E('aysub').textContent = T('KP පද්ධතිය · Offline', 'KP Stellar System · Offline');

    // Add 💎 KP Gems & Colors (t19) into Drawer Menu NAV under Forecast/Life group
    try {
      var g0 = NAV[0];
      if (g0 && !g0[1].some(function (y) { return y[1] === 't20'; })) {
        g0[1].push([T('📐 KP දෘෂ්ටි (Aspects)', '📐 KP Aspects (W/V)'), 't20']);
      }
      var grp = NAV.find(function (x) { return x[1].some(function (y) { return y[1] === 't5'; }); }) || NAV[1];
      if (grp && !grp[1].some(function (y) { return y[1] === 't19'; })) {
        grp[1].push([T('💎 KP මැණික් & පාට', '💎 KP Gems & Colors'), 't19']);
      }
      if (grp && !grp[1].some(function (y) { return y[1] === 't21'; })) {
        grp[1].push([T('⏱ නිශ්චිත ගෝචර මාරු', '⏱ Exact Transits'), 't21']);
      }
      if (grp && !grp[1].some(function (y) { return y[1] === 't24'; })) {
        grp[1].push([T('🏠 1–12 භාව පලාපල', '🏠 1–12 Houses KP'), 't24']);
      }
      if (grp && !grp[1].some(function (y) { return y[1] === 't25'; })) {
        grp[1].push([T('🩺 KP ලෙඩරෝග (Medical)', '🩺 Medical KP (Health)'), 't25']);
      }
      if (grp && !grp[1].some(function (y) { return y[1] === 't23'; })) {
        grp[1].push([T('📋 සියලු ක්ෂේත්‍ර සාරාංශය', '📋 All Topics Summary'), 't23']);
      }
      var gLast = NAV[NAV.length - 1];
      if (gLast && !gLast[1].some(function (y) { return y[1] === 't26'; })) {
        gLast[1].unshift([T('🧘 ආධ්‍යාත්මික සහන & භාවනා', '🧘 Spiritual & Sound Studio'), 't26']);
      }
      if (gLast && !gLast[1].some(function (y) { return y[1] === 't22'; })) {
        gLast[1].push([T('📚 KP සිද්ධාන්ත අත්පොත', '📚 KP Principles Guide'), 't22']);
      }
    } catch (e) {}

    var SGN = SI
      ? ['මේෂ','වෘෂභ','මිථුන','කටක','සිංහ','කන්‍යා','තුලා','වෘශ්චික','ධනු','මකර','කුම්භ','මීන']
      : ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
    var NKN = SI
      ? ['අස්විද','බරණ','කැති','රෙහෙණ','මුවසිරස','අද','පුනාවස','පුස','ඇසළ','මා','පුවපල්','උත්තරපල්','හත','සිත','සා','විසා','අනුර','දෙට','මුල','පුරාසල','උතුරුසල','සුවණ','දෙනට','සියාවස','පුව පුටුප','උතුරු පුටුප','රේවතී']
      : ['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','P.Phalguni','U.Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','P.Ashadha','U.Ashadha','Shravana','Dhanishta','Shatabhisha','P.Bhadrapada','U.Bhadrapada','Revati'];
    var PLN = SI
      ? ['කේතු','සිකුරු','රවි','චන්ද්‍ර','කුජ','රාහු','ගුරු','ශනි','බුධ']
      : ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
    var DAY_LORD = SI
      ? ['රවි','චන්ද්‍ර','කුජ','බුධ','ගුරු','සිකුරු','ශනි']
      : ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
    var HORA_SEQ = SI
      ? ['රවි','සිකුරු','බුධ','චන්ද්‍ර','ශනි','ගුරු','කුජ']
      : ['Sun','Venus','Mercury','Moon','Saturn','Jupiter','Mars'];
    var DAY_TO_HORA = [0, 3, 6, 2, 5, 1, 4];
    var WK_FULL = SI
      ? ['ඉරිදා','සඳුදා','අඟහරුවාදා','බදාදා','බ්‍රහස්පතින්දා','සිකුරාදා','සෙනසුරාදා']
      : ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

    var KP_GEMS = {
      Su: { si:'රවි', en:'Sun', gemSi:'Ruby (මාණික්‍ය)', gemEn:'Ruby', colSi:'තැඹිලි හෝ තද රතු', colEn:'Orange or Deep Red', metSi:'Gold & Copper (රන් සහ තඹ)', metEn:'Gold & Copper' },
      Mo: { si:'චන්ද්‍ර', en:'Moon', gemSi:'Pearl (මුතු)', gemEn:'Pearl', colSi:'සුදු, රිදී පාට', colEn:'White, Silvery', metSi:'Silver (රිදී)', metEn:'Silver' },
      Ma: { si:'කුජ', en:'Mars', gemSi:'Coral (පබළු)', gemEn:'Coral', colSi:'තද රතු', colEn:'Deep Red', metSi:'Copper / Iron (තඹ / යකඩ)', metEn:'Copper / Iron' },
      Me: { si:'බුධ', en:'Mercury', gemSi:'Emerald (පච්ච / මරකත)', gemEn:'Emerald', colSi:'අළු මිශ්‍ර කොළ පාට', colEn:'Greyish Green', metSi:'Quick-Silver (රසදිය)', metEn:'Quick-Silver' },
      Ju: { si:'ගුරු', en:'Jupiter', gemSi:'Topaz (පුෂ්පරාග)', gemEn:'Topaz', colSi:'දම්, වයලට්, නිල්, සුදු', colEn:'Purple, Violet, Blue, White', metSi:'Tin (ටින්)', metEn:'Tin' },
      Ve: { si:'සිකුරු', en:'Venus', gemSi:'Diamond (දියමන්ති)', gemEn:'Diamond', colSi:'කහ, ලා නිල්, සුදුත් නෙවෙයි කළුත් නෙවෙයි', colEn:'Yellow, Light Blue, Neutral Off-White', metSi:'Silver & Copper (රිදී සහ තඹ)', metEn:'Silver & Copper' },
      Sa: { si:'ශනි', en:'Saturn', gemSi:'Sapphire (නීල)', gemEn:'Sapphire', colSi:'දුඹුරු, ඉන්ඩිගෝ, කළු', colEn:'Brown, Indigo, Black', metSi:'Lead (ඊයම්)', metEn:'Lead' },
      Ra: { si:'රාහු', en:'Rahu', gemSi:'Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)', gemEn:'Agate or Turquoise', colSi:'මිශ්‍ර පාට', colEn:'Mixed Colors', metSi:'Alloy (මිශ්‍ර ලෝහ)', metEn:'Alloy' },
      Ke: { si:'කේතු', en:'Ketu', gemSi:'Agate / Turquoise (අකීක් හෝ පිරෝජා / ෆිරෝසා)', gemEn:'Agate or Turquoise', colSi:'මිශ්‍ර පාට', colEn:'Mixed Colors', metSi:'Alloy (මිශ්‍ර ලෝහ)', metEn:'Alloy' }
    };

    var WD = SI ? ['ඉ','ස','අ','බ','බ්‍ර','සි','සෙ'] : ['S','M','T','W','T','F','S'];
    var PC = { Su:'#f59e0b',Mo:'#94a3b8',Ma:'#ef4444',Me:'#10b981',Ju:'#eab308',Ve:'#ec4899',Sa:'#6366f1',Ra:'#a855f7',Ke:'#b45309',Ur:'#06b6d4',Ne:'#06b6d4',Pl:'#06b6d4' };
    var S = { c: null, day: null, clockTimer: null, installPrompt: null, scr: 'home' };

    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault(); S.installPrompt = e;
      var btn = E('kp-install-btn'); if (btn) btn.classList.add('show');
    });
    window.addEventListener('appinstalled', function () {
      S.installPrompt = null;
      var btn = E('kp-install-btn'); if (btn) btn.classList.remove('show');
      ok(function () { mnToast(T('✓ KP Astrology AI Pro ස්ථාපනය විය!', '✓ KP Astrology AI Pro installed!')); });
    });

    /* ---------- Time & KP Helpers ---------- */
    function today() {
      var n = new Date();
      return n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0');
    }
    function dms(deg) {
      var d = Math.floor(deg), mF = (deg - d) * 60, m = Math.floor(mF), s = Math.floor((mF - m) * 60);
      return d + '°' + String(m).padStart(2, '0') + "'" + String(s).padStart(2, '0') + '"';
    }
    function fmtLiveTime() {
      var n = new Date(), h = n.getHours(), m = String(n.getMinutes()).padStart(2, '0');
      var ap = SI ? (h >= 12 ? 'ප.ව.' : 'පෙ.ව.') : (h >= 12 ? 'PM' : 'AM');
      var h12 = (h % 12) || 12;
      var dStr = n.getFullYear() + '.' + String(n.getMonth() + 1).padStart(2, '0') + '.' + String(n.getDate()).padStart(2, '0');
      return { clock: SI ? (ap + ' ' + h12 + ':' + m) : (h12 + ':' + m + ' ' + ap), date: WK_FULL[n.getDay()] + ' ' + dStr };
    }
    function livePanchanga() {
      var now = new Date(), dow = now.getDay(), hr = now.getHours(), mn = now.getMinutes();
      var effDow = hr < 6 ? (dow + 6) % 7 : dow;
      var idx = (DAY_TO_HORA[effDow] + ((hr + 24 - 6) % 24)) % 7;
      return { dayLord: DAY_LORD[effDow], horaLord: HORA_SEQ[idx], horaLeft: (60 - mn) + 'm' };
    }
    function dayScore(x) {
      var g = kpDay(x);
      var r = TOP.map(function (t, i) { return PCT(g.segs.reduce(function (s, y) { return s + y.f[i] * (y.t1 - y.t0); }, 0) / 24); });
      return { g: g, r: r, avg: Math.round(r.reduce(function (a, b) { return a + b; }, 0) / r.length) };
    }
    function curDashaObj() {
      var now = Date.now() / 864e5 + 2440587.5;
      var f = function (x) { return now >= x[1] && now < x[1] + x[2]; };
      var m = mainL.find(f), a = m && kids(m).find(f), p = a && kids(a).find(f);
      return { names: [m, a, p].filter(Boolean).map(function (x) { return PLN[x[0]]; }), end: p ? dt(p[1] + p[2]) : (a ? dt(a[1] + a[2]) : '') };
    }
    function computePillars() {
      var _sg = ok(function () { return signif(c); });
      var sig = _sg && (_sg.out || _sg);
      if (!sig) return [];
      var defs = [
        [T('ධනය', 'Wealth'), 1, [2, 6, 10, 11], [5, 8, 12], 't5'],
        [T('රැකියාව', 'Career'), 9, [2, 6, 10, 11], [5, 8, 12], 't15'],
        [T('විවාහය', 'Marriage'), 6, [2, 7, 11], [1, 6, 10], 't8'],
        [T('අධ්‍යාපන', 'Education'), 3, [4, 9, 11], [3, 8, 12], 't5'],
        [T('විදේශ', 'Foreign'), 11, [3, 9, 12], [2, 4, 11], 't14'],
        [T('සෞඛ්‍යය', 'Health'), 0, [1, 5, 11], [6, 8, 12], 't14']
      ];
      return defs.map(function (df) {
        var cslCode = P[lords(c.cs[df[1]]).sl];
        var levels = sig[cslCode] || [[], [], [], [], []];
        var w = [4, 3, 2, 1.5, 1], pos = 0, neg = 0, tot = 0;
        levels.forEach(function (arr, li) {
          (arr || []).forEach(function (h) {
            tot += w[li];
            if (df[2].indexOf(h) !== -1) pos += w[li];
            if (df[3].indexOf(h) !== -1) neg += w[li];
          });
        });
        var pct = Math.max(18, Math.min(96, tot > 0 ? Math.round(50 + ((pos - neg) / (tot + 2)) * 55) : 50));
        return { label: df[0], pct: pct, csl: PLN[lords(c.cs[df[1]]).sl], tab: df[4] };
      });
    }
    function computeKPGems() {
      var _sg = ok(function () { return signif(c); });
      var sig = _sg && (_sg.out || _sg);
      if (!sig || !c || !c.cs || c.cs.length < 11) return null;
      function evalCsl(cuspIdx, labelSi, labelEn) {
        var slIdx = lords(c.cs[cuspIdx]).sl, code = P[slIdx], lv = sig[code] || [[], [], [], []], allH = [];
        [0, 1, 2, 3].forEach(function (i) { (lv[i] || []).forEach(function (h) { if (allH.indexOf(h) === -1) allH.push(h); }); });
        allH.sort(function (a, b) { return a - b; });
        var bad = allH.filter(function (h) { return h === 6 || h === 8 || h === 12; });
        return { cusp: cuspIdx + 1, label: SI ? labelSi : labelEn, code: code, meta: KP_GEMS[code], houses: allH, bad: bad, ok: bad.length === 0 };
      }
      var c1 = evalCsl(0, '1 වන භාව උප-අධිපති (ලග්න)', '1st Cusp Sub-Lord (Lagna)');
      var c11 = evalCsl(10, '11 වන භාව උප-අධිපති (ලාභ)', '11th Cusp Sub-Lord (Gains)');
      var eligible = [];
      if (c1.ok && c11.ok && c1.code === c11.code) { c1.both = true; eligible.push(c1); }
      else { if (c1.ok) eligible.push(c1); if (c11.ok) eligible.push(c11); }
      return { c1: c1, c11: c11, eligible: eligible };
    }

    /* ==========================================================================
       TRUE MULTI-SCREEN ROUTER (home | form | horary | profiles | settings | page)
       ========================================================================== */
    var SCR_TITLES = {
      form:     '🪐 ' + T('ජන්ම පත්‍රය සාදන්න', 'New Birth Chart'),
      horary:   '🔮 ' + T('KP Horary (1–249)', 'KP Horary (1–249)'),
      profiles: '👥 ' + T('සුරැකි කේන්දර', 'Saved Charts'),
      settings: '⚙️ ' + T('සැකසුම් (Ayanamsha)', 'Settings & Ayanamsha')
    };

    function updateResumePill() {
      var p = E('kp-resume-pill');
      if (!p) return;
      if (c) {
        var nm = (E('nm') && E('nm').value.trim()) || T('ජන්ම පත්‍රය', 'Birth Chart');
        var lg = Math.floor(c.cs[0] / 30);
        p.innerHTML = '<span>📋 ' + T('දැන් පත්‍රය: ', 'Active Chart: ') + '<b>' + esc(nm) + ' (' + SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°)</b></span><b>➜</b>';
        p.classList.add('show');
      } else {
        p.classList.remove('show');
      }
    }

    function goScr(name, fromPop) {
      var prev = S.scr;
      S.scr = name;
      document.body.setAttribute('data-scr', name);
      if (name === 'page') document.body.classList.add('rv');
      else document.body.classList.remove('rv');

      var tEl = E('kp-scr-title');
      if (tEl && SCR_TITLES[name]) tEl.textContent = SCR_TITLES[name];

      if (name === 'horary') syncHoraryLoc();
      if (name === 'home') { updateResumePill(); if (window.kpRefreshLicUI) window.kpRefreshLicUI(); }
      if (name === 'settings' && window.kpRefreshLicUI) window.kpRefreshLicUI();

      if (!fromPop && name !== 'home' && prev === 'home') {
        try { history.pushState({ scr: name }, ''); } catch (e) {}
      }
      window.scrollTo(0, 0);
    }

    function openPage(tabId) {
      if (!c && tabId !== 't22' && tabId !== 't26') return;
      var target = tabId === 'kpPlus' ? 't14' : (tabId || 't1');
      ok(buildSum);
      goScr('page', false);
      barState(target);
      window.scrollTo(0, 0);
    }

    function onPop() {
      if (S.scr !== 'home') {
        goScr('home', true);
      }
    }

    window.kpGoScr = goScr;
    window.kpOpenPage = openPage;
    window.kpOnPop = onPop;

    /* ==========================================================================
       DEDICATED SCREEN 1..5 BUILDERS (Isolate Form, Horary, Profiles, Settings!)
       ========================================================================== */
    var SVG_CHART = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 12h18M12 3v18M12 3l9 9-9 9-9-9z"/></svg>';
    var SVG_AI = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="6" width="16" height="12" rx="3"/><path d="M12 2v4M9 11h.01M15 11h.01M9 15h6"/></svg>';
    var SVG_HORARY = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4M12 17h.01"/></svg>';
    var SVG_RP = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>';
    var SVG_PROF = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';
    var SVG_SET = '<svg class="kb-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.26.6.85 1 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';

    function syncHoraryLoc() {
      var el = E('kh-loc-txt');
      if (!el) return;
      if (E('now')) E('now').click();
      if (E('la') && !E('la').value) {
        E('la').value = '6.9271'; E('lo').value = '79.8612'; E('tz').value = '5.5';
        if (E('pl')) E('pl').value = 'Colombo';
      }
      var pl = (E('pl') && E('pl').value) || 'Colombo';
      var dtS = (E('dt') && E('dt').value) || today();
      var tmS = (E('tm') && E('tm').value) || '';
      el.textContent = '📍 ' + pl + ' · ' + dtS + ' ' + tmS;
    }

    function castNowAndOpen(targetTab) {
      if (E('now')) E('now').click();
      if (E('la') && !E('la').value) { E('la').value = '6.9271'; E('lo').value = '79.8612'; E('tz').value = '5.5'; if (E('pl')) E('pl').value = 'Colombo'; }
      if (E('b1')) E('b1').click();
      setTimeout(function () {
        if (c) {
          if (targetTab && targetTab !== 't1') nvB(targetTab, '');
          openPage(targetTab || 't1');
        }
      }, 150);
    }


    /* ==========================================================================
       v33: 100% OFFLINE CLICKABLE SRI LANKA TOWNS & HOSPITALS AUTOCOMPLETE
       (Android WebView ignores <datalist>; this renders instant tappable pills!)
       ========================================================================== */
    function initOfflineTownPicker() {
      var plEl = E('pl');
      if (!plEl || plEl.dataset.kpTowns) return;
      plEl.dataset.kpTowns = '1';

      // Build searchable index from <datalist> options + LOC coordinates
      var items = [];
      var seen = {};
      var dl = document.querySelector('datalist');
      if (dl) {
        $$('option', dl).forEach(function (op) {
          var en = (op.value || '').trim();
          var si = (op.label || op.getAttribute('label') || '').trim();
          var co = (typeof LOC !== 'undefined' && LOC[en]) ? LOC[en] : null;
          if (en && co && !seen[en]) {
            seen[en] = 1;
            items.push({ en: en, si: si, lat: co[0], lon: co[1], q: (en + ' ' + si).toLowerCase() });
          }
        });
      }
      if (typeof LOC !== 'undefined') {
        Object.keys(LOC).forEach(function (k) {
          if (!seen[k] && Array.isArray(LOC[k])) {
            seen[k] = 1;
            items.push({ en: k, si: '', lat: LOC[k][0], lon: LOC[k][1], q: k.toLowerCase() });
          }
        });
      }
      if (!items.length) return;

      var box = document.createElement('div');
      box.id = 'kp-town-pop';
      box.className = 'kp-town-pop';
      plEl.insertAdjacentElement('afterend', box);

      function showMatches() {
        var q = (plEl.value || '').trim().toLowerCase();
        if (!q) { box.innerHTML = ''; box.style.display = 'none'; return; }
        var hits = [];
        for (var i = 0; i < items.length; i++) {
          if (items[i].q.indexOf(q) !== -1) {
            hits.push(items[i]);
            if (hits.length >= 8) break;
          }
        }
        if (!hits.length) { box.innerHTML = ''; box.style.display = 'none'; return; }
        box.style.display = 'flex';
        box.innerHTML = hits.map(function (it, idx) {
          var lbl = (it.si && it.si !== '🏥') ? (it.si + ' (' + it.en + ')') : (it.si === '🏥' ? '🏥 ' + it.en : it.en);
          return '<button type="button" class="kp-town-it" data-idx="' + idx + '">📍 ' + esc(lbl) + '</button>';
        }).join('');
        box._hits = hits;
      }

      box.onclick = function (e) {
        var b = e.target.closest('button[data-idx]');
        if (!b || !box._hits) return;
        var it = box._hits[+b.dataset.idx];
        if (!it) return;
        plEl.value = (SI && it.si && it.si !== '🏥') ? it.si : it.en;
        if (E('la')) { E('la').value = String(it.lat); E('la').dispatchEvent(new Event('input', { bubbles: true })); }
        if (E('lo')) { E('lo').value = String(it.lon); E('lo').dispatchEvent(new Event('input', { bubbles: true })); }
        if (E('tz')) E('tz').value = '5.5';
        box.innerHTML = ''; box.style.display = 'none';
        if (window.KPB && window.KPB.mnToast) {
          window.KPB.mnToast('📍 ' + plEl.value + ' (' + it.lat.toFixed(3) + ', ' + it.lon.toFixed(3) + ')');
        }
      };

      plEl.addEventListener('input', showMatches);
      plEl.addEventListener('focus', showMatches);
    }

    function buildScreens() {
      var tp = E('tp');
      if (!tp || E('kp-home')) return;

      // 1. Sub-Screen Back Header Bar (shared by form / horary / profiles / settings)
      var sb = document.createElement('div');
      sb.id = 'kp-scr-bar';
      sb.innerHTML = '<button type="button" id="kp-scr-back">← ' + T('මුල් පිටුව', 'Home') + '</button><span id="kp-scr-title"></span>';
      tp.insertAdjacentElement('afterend', sb);
      E('kp-scr-back').onclick = function () {
        if (history.state && history.state.scr) history.back();
        else goScr('home', true);
      };

      // 2. Clean 1-Screen Home Dashboard (#kp-home)
      var lt = fmtLiveTime(), pn = livePanchanga();
      var hm = document.createElement('div');
      hm.id = 'kp-home';
      hm.innerHTML =
        '<div class="kb-hero">' +
          '<div class="kb-hero-row">' +
            '<button type="button" class="kb-gold-pill" id="kw-now">' +
              '<small>' + T('ක්ෂණික KP ගණනය', 'Quick KP Chart') + '</small>' +
              '<b>⚡ ' + T('දැන් වේලාවෙන් පත්‍රය', 'Instant Chart Now') + '</b>' +
            '</button>' +
            '<div class="kb-clock"><b id="kw-clk">' + lt.clock + '</b><small>' + lt.date + '</small></div>' +
          '</div>' +
          '<div class="kb-ticker">' +
            '<div class="kb-ticker-main"><span class="kb-dot r"></span>' + T('දින අධිපති: ', 'Day: ') + '<b>' + pn.dayLord + '</b> · <span class="kb-dot b"></span>' + T('හෝරාව: ', 'Hora: ') + '<b>' + pn.horaLord + '</b> · <span class="kb-dot g"></span>' + T('100% නොමිලේ', '100% Free') + '</div>' +
            '<div class="kb-ticker-r">KP<br>Offline</div>' +
          '</div>' +
        '</div>' +

        '<button type="button" id="kp-lic-pill"></button>' +
        '<button type="button" id="kp-resume-pill"></button>' +
        '<button type="button" id="kp-install-btn">📲 ' + T('ඇප් එක දුරකථනයට ස්ථාපනය කරන්න', 'Install KP AI Pro App') + '</button>' +

        '<div class="kb-grid">' +
          '<button type="button" class="kb-tile" id="hm-form">' +
            '<div class="kb-tile-top"><span class="kb-badge rose">' + T('ජන්ම පත්‍රය', 'KUNDALI') + '</span>' + SVG_CHART + '</div>' +
            '<div><span class="kb-tile-t">' + T('ජන්ම පත්‍රය', 'KP Birth Chart') + '</span><span class="kb-tile-s">' + T('ලග්න, භාව, දශා & පලාපල', 'Lagna, Cusps & Dasha') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-hor">' +
            '<div class="kb-tile-top"><span class="kb-badge blue">1–249</span>' + SVG_HORARY + '</div>' +
            '<div><span class="kb-tile-t">' + T('KP Horary', 'KP Horary') + '</span><span class="kb-tile-s">' + T('ප්‍රශ්න අංකයෙන් පිළිතුරු', 'Question Number 1–249') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-rp">' +
            '<div class="kb-tile-top"><span class="kb-badge teal">LIVE</span>' + SVG_RP + '</div>' +
            '<div><span class="kb-tile-t">' + T('Ruling Planets', 'Ruling Planets') + '</span><span class="kb-tile-s">' + T('දැන් පාලක ග්‍රහයන්', 'Instant Ruling Planets') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-ai">' +
            '<div class="kb-tile-top"><span class="kb-badge purp">AI</span>' + SVG_AI + '</div>' +
            '<div><span class="kb-tile-t">' + T('KP AI ගුරු', 'KP AI Guru') + '</span><span class="kb-tile-s">' + T('ප්‍රශ්න අසන්න · Offline', 'Ask Anything · Offline') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-prof">' +
            '<div class="kb-tile-top"><span class="kb-badge amb">' + T('සුරැකි', 'SAVED') + '</span>' + SVG_PROF + '</div>' +
            '<div><span class="kb-tile-t">' + T('සුරැකි කේන්දර', 'Saved Charts') + '</span><span class="kb-tile-s">' + T('පැතිකඩ & Backup', 'Profiles & Backup') + '</span></div>' +
          '</button>' +
          '<button type="button" class="kb-tile" id="hm-set">' +
            '<div class="kb-tile-top"><span class="kb-badge slat">KP</span>' + SVG_SET + '</div>' +
            '<div><span class="kb-tile-t">' + T('සැකසුම්', 'Settings') + '</span><span class="kb-tile-s">' + T('Ayanamsha & භාෂාව', 'Ayanamsha & Theme') + '</span></div>' +
          '</button>' +
        '</div>' +

        '<button type="button" class="kp-sp-home" id="hm-spir">' +
          '<div>' +
            '<b>🧘 ' + T('ආධ්‍යාත්මික සහන, ශබ්ද Studio & සතිපට්ඨාන භාවනා', 'Spiritual Remedies, Sound Studio & Meditation') + '</b>' +
            '<small>' + T('කේන්දර අපල/බාධා සඳහා Solfeggio ශබ්ද 11, Binaural, ආනාපානසති, සක්මන් & නිවන් මඟ', 'Chart-based Solfeggio Hz, Binaural, Nature Mixer & Theravada Satipatthana Guide') + '</small>' +
          '</div>' +
          '<span class="kp-sp-pill">' + T('විවෘත', 'OPEN') + ' ▸</span>' +
        '</button>' +

        '<div class="kb-devfoot">' +
          '<div><small>Developed by</small><b>W. Vihanga Rasanjana Withanage</b></div>' +
          '<button type="button" id="kp-appshare">📤 ' + T('බෙදාගන්න', 'Share') + '</button>' +
        '</div>';

      sb.insertAdjacentElement('afterend', hm);

      // 3. Dedicated Horary Screen (#kp-scr-horary) — Move Horary controls out of birth form!
      var formCard = $$('body > .card').find(function (el) { return $$('.sec', el).length >= 3; });
      var horScr = document.createElement('div');
      horScr.id = 'kp-scr-horary';
      horScr.className = 'card';
      horScr.innerHTML =
        '<h3>🔮 ' + T('KP Horary (ප්‍රශ්න අංකය 1–249)', 'KP Horary (Question Number 1–249)') + '</h3>' +
        '<div class="kh-loc"><span id="kh-loc-txt"></span><button type="button" id="kh-now-btn">⏱ ' + T('දැන්', 'Now') + '</button></div>' +
        '<div id="kh-mount"></div>';
      hm.insertAdjacentElement('afterend', horScr);

      // 4. Dedicated Settings Screen (#kp-scr-settings) — Move Ayanamsha controls out of birth form!
      var setScr = document.createElement('div');
      setScr.id = 'kp-scr-settings';
      setScr.className = 'card';
      setScr.innerHTML =
        '<h3>👑 ' + T('PRO බලපත්‍රය (License)', 'PRO License Status') + '</h3>' +
        '<div id="ks-lic-box"></div>' +
        '<h3 style="margin-top:14px">🖨️ ' + T('ජ්‍යොතිෂවේදී විස්තර (White-Label A4 PDF)', 'Astrologer Branding (White-Label PDF)') + '</h3>' +
        '<div class="sub" style="margin-bottom:6px">' + T('මෙහි ඇතුළත් කරන ඔබේ නම සහ දුරකථන අංකය, සේවාදායකයන්ට ලබා දෙන සෑම A4 PDF කේන්දර වාර්තාවකම ඉහළින් මුද්‍රණය වේ.', 'Your center name, phone, and address will appear as an executive letterhead on every exported A4 PDF chart report.') + '</div>' +
        '<label>' + T('නම / ආයතනය', 'Center / Name') + '<input id="br-name" placeholder="' + T('උදා: ශ්‍රී ලංකා KP ජ්‍යොතිෂ සේවය', 'e.g. Royal KP Astrology Center') + '"></label>' +
        '<label>' + T('උප ශීර්ෂය', 'Subtitle') + '<input id="br-sub" placeholder="' + T('ක්‍රිෂ්ණමූර්ති පද්ධති උපදේශක', 'KP Stellar Astrologer') + '"></label>' +
        '<label>' + T('දුරකථන / WA', 'Phone / WA') + '<input id="br-phone" placeholder="07X XXX XXXX"></label>' +
        '<label>' + T('ලිපිනය', 'Address') + '<input id="br-addr" placeholder="' + T('නගරය / ලිපිනය', 'City / Address') + '"></label>' +
        '<button type="button" class="p" id="br-save" style="width:100%;margin-top:6px">💾 ' + T('PDF විස්තර සුරකින්න', 'Save PDF Letterhead') + '</button>' +
        '<h3 style="margin-top:16px">⚙️ ' + T('Ayanamsha සහ ඇප් සැකසුම්', 'Ayanamsha & App Settings') + '</h3>' +
        '<div id="ks-mount"></div>' +
        '<div class="kh-row" style="margin-top:12px">' +
          '<button type="button" id="ks-lang">🌐 ' + T('ඉංග්‍රීසි (EN)', 'සිංහල (SI)') + '</button>' +
          '<button type="button" id="ks-theme">🌗 ' + T('තේමාව මාරු කරන්න', 'Toggle Theme') + '</button>' +
        '</div>';
      horScr.insertAdjacentElement('afterend', setScr);

      // Relocate Horary <details> and Ayanamsha <details> cleanly from Birth Form into their own dedicated screens!
      if (formCard) {
        $$('details.adv', formCard).forEach(function (det) {
          if (det.querySelector('#hb')) {
            var hmMount = E('kh-mount');
            Array.prototype.slice.call(det.childNodes).forEach(function (nd) {
              if (nd.nodeType === 1 && nd.tagName === 'SUMMARY') return;
              hmMount.appendChild(nd);
            });
            det.remove();
            // Style Horary buttons cleanly in a row
            var hb = E('hb');
            if (hb) {
              hb.className = 'p';
              var row = document.createElement('div'); row.className = 'kh-row';
              var rb = document.createElement('button'); rb.type = 'button'; rb.id = 'kp-rand-hn';
              rb.textContent = '🎲 ' + T('අහඹු (1–249)', 'Random 1–249');
              rb.onclick = function () {
                var n = Math.floor(Math.random() * 249) + 1;
                if (E('hn')) E('hn').value = n;
                if (E('now')) E('now').click();
                syncHoraryLoc();
                mnToast(T('🎲 KP Horary අංකය: ', '🎲 KP Horary Number: ') + n);
              };
              hb.parentNode.insertBefore(row, hb);
              row.appendChild(rb);
              row.appendChild(hb);
              var tb = document.createElement('button');
              tb.type = 'button';
              tb.style.cssText = 'width:100%;margin-top:8px;background:rgba(45,212,191,0.14);border-color:rgba(45,212,191,0.45);color:var(--teal);font-weight:800';
              tb.textContent = '⏱ ' + T('කාල ප්‍රශ්නය — අංකයක් නැතිව දැන් වේලාවෙන් (Time Horary)', 'Time-Based Horary (Exact Moment — No Number)');
              tb.onclick = function () { if (window.kpTimeHorary) window.kpTimeHorary(); };
              row.insertAdjacentElement('afterend', tb);
            }
          } else if (det.querySelector('#ay')) {
            var smMount = E('ks-mount');
            Array.prototype.slice.call(det.childNodes).forEach(function (nd) {
              if (nd.nodeType === 1 && nd.tagName === 'SUMMARY') return;
              smMount.appendChild(nd);
            });
            det.remove();
          }
        });
      }

      // Wire Home & Settings buttons
      E('kw-now').onclick = function () { castNowAndOpen('t1'); };
      E('hm-form').onclick = function () { goScr('form'); };
      E('hm-hor').onclick = function () { if (window.KPLic && !window.KPLic.allow('t13', '')) return; goScr('horary'); };
      E('hm-rp').onclick = function () { if (window.KPLic && !window.KPLic.allow('t16', '')) return; castNowAndOpen('t16'); };
      E('hm-ai').onclick = function () { if (window.KPLic && !window.KPLic.allow('t18', '')) return; if (!c) castNowAndOpen('t18'); else { nvB('t18', ''); openPage('t18'); } };
      E('hm-prof').onclick = function () { goScr('profiles'); };
      E('hm-set').onclick = function () { goScr('settings'); };
      E('hm-spir').onclick = function () { if (typeof window.nvB === 'function') window.nvB('t26', ''); openPage('t26'); };
      E('kp-resume-pill').onclick = function () { if (c) openPage(curTab || 't1'); };
      E('kh-now-btn').onclick = function () { if (E('now')) E('now').click(); syncHoraryLoc(); mnToast(T('දැන් වේලාව සකසා ගති', 'Updated to current time')); };
      E('ks-lang').onclick = function () { if (E('lgb')) E('lgb').click(); };
            E('ks-theme').onclick = function () { if (E('th')) E('th').click(); };

      function refreshLicUI() {
        if (!window.KPLic) return;
        var st = window.KPLic.getStatus();
        var pill = E('kp-lic-pill');
        if (pill) {
          if (st.active) {
            pill.className = 'kp-lic-pill on';
            pill.innerHTML = '<span>✅ <b>PRO ' + st.planName + '</b> · ' + (st.plan === 'LT' ? T('සදාකාලිකයි', 'Lifetime') : T('ඉතිරි දින ', '') + st.daysLeft + T('', ' days left')) + '</span><small>' + st.devId + '</small>';
          } else {
            pill.className = 'kp-lic-pill lock';
            var pcMode = !!(window.KPLic && window.KPLic.isPC && window.KPLic.isPC());
            pill.innerHTML = '<span>' + (pcMode ? '💻' : '👑') + ' <b>' + (pcMode ? T('Windows PC PRO බලපත්‍රය සක්‍රීය කරන්න', 'Activate Windows PC PRO') : T('PRO බලපත්‍රය සක්‍රීය කරන්න', 'Activate PRO License')) + '</b> · ' + (pcMode ? T('Rs. 3,000 සිට', 'From Rs. 3,000') : T('Rs. 2,000 සිට', 'From Rs. 2,000')) + '</span><b>🔓</b>';
          }
          pill.onclick = function () { window.KPLic.openModal(); };
        }
        var box = E('ks-lic-box');
        if (box) {
          box.innerHTML =
            '<div class="ks-lic-card ' + (st.active ? 'on' : 'off') + '">' +
              '<div><b>' + (st.active ? '✅ PRO ' + T('සක්‍රීයයි', 'Active') + ' (' + st.planName + ')' : (st.expired ? '⚠️ ' + T('බලපත්‍රය කල් ඉකුත් වී ඇත', 'License Expired') : '🔒 ' + T('සීමිත Demo මාදිලිය', 'Free Preview Mode'))) + '</b></div>' +
              '<small>📱 Device ID: <b>' + st.devId + '</b></small>' +
              (st.active ? '<small>📅 ' + T('කල් ඉකුත්වීම: ', 'Valid Until: ') + window.KPLic.fmtYmd(st.ymd) + (st.plan !== 'LT' ? ' (' + st.daysLeft + T(' දින ඉතිරි', ' days left') + ')' : '') + '</small>' : '') +
              '<button type="button" class="p" id="ks-open-lic" style="width:100%;margin-top:8px">' + (st.active ? '🔄 ' + T('පැකේජය අලුත් / උසස් කරන්න', 'Renew / Upgrade Plan') : '🔑 ' + T('Activation Key ඇතුළත් කරන්න', 'Enter Activation Key')) + '</button>' +
            '</div>';
          E('ks-open-lic').onclick = function () { window.KPLic.openModal(); };
        }
      }
      window.kpRefreshLicUI = refreshLicUI;
      refreshLicUI();
      ok(initOfflineTownPicker);

      // Load & Save White-Label Astrologer PDF Letterhead
      try {
        var br0 = JSON.parse(localStorage.getItem('kp_brand') || '{}');
        if (E('br-name') && br0.name) E('br-name').value = br0.name;
        if (E('br-sub') && br0.sub) E('br-sub').value = br0.sub;
        if (E('br-phone') && br0.phone) E('br-phone').value = br0.phone;
        if (E('br-addr') && br0.addr) E('br-addr').value = br0.addr;
      } catch (e) {}
      if (E('br-save')) E('br-save').onclick = function () {
        var obj = {
          name: (E('br-name').value || '').trim(),
          sub: (E('br-sub').value || '').trim(),
          phone: (E('br-phone').value || '').trim(),
          addr: (E('br-addr').value || '').trim()
        };
        try { localStorage.setItem('kp_brand', JSON.stringify(obj)); } catch (e) {}
        mnToast('✅ ' + T('PDF ජ්‍යොතිෂවේදී විස්තර සුරකින ලදී!', 'White-Label PDF letterhead saved!'));
      };
      E('kp-appshare').onclick = function () {
        var txt = T('✦ KP Astrology AI Pro — ක්‍රිෂ්ණමූර්ති පද්ධති ජන්ම පත්‍රය, KP AI ගුරු සහ දශා පලාපල!', '✦ KP Astrology AI Pro — Birth Chart, KP AI Guru & 5-Level Dasha Forecasts!');
        if (navigator.share) navigator.share({ title: 'KP Astrology AI Pro', text: txt, url: location.href }).catch(function () {});
        else window.open('https://wa.me/?text=' + encodeURIComponent(txt + ' ' + location.href), '_blank');
      };

      if (S.installPrompt) E('kp-install-btn').classList.add('show');
      E('kp-install-btn').onclick = function () {
        if (!S.installPrompt) return;
        S.installPrompt.prompt();
        S.installPrompt.userChoice.finally(function () { S.installPrompt = null; E('kp-install-btn').classList.remove('show'); });
      };
    }

    /* ==========================================================================
       SCREEN 6: SLIM 1-LINE CHART STRIP (#ksum) + DEDICATED KP GEMS PAGE (t19)
       ========================================================================== */
    function buildSum() {
      var res = E('res'); if (!res || !c) return;
      var d = ok(function () { return dayScore(today()); });
      var lg = Math.floor(c.cs[0] / 30), lgDeg = Math.floor(c.cs[0] % 30);
      var ds = ok(curDashaObj) || { names: [] };
      var nm = (E('nm') && E('nm').value.trim()) || T('ජන්ම පත්‍රය', 'Birth Chart');
      var avg = d ? d.avg : 50;
      var scCls = avg >= 55 ? 'sc-ok' : avg >= 40 ? 'sc-mid' : 'sc-bad';

      var card = E('ksum');
      if (!card) {
        card = document.createElement('div');
        card.id = 'ksum';
        res.insertBefore(card, E('nv') || res.firstChild);
      }

      card.innerHTML =
        '<div class="kp-mini-bar">' +
          '<div class="kp-mini-info">' +
            '<div class="kp-mini-l1">👤 ' + esc(nm) + ' · <b>' + SGN[lg] + ' ' + lgDeg + '°</b></div>' +
            '<div class="kp-mini-l2">' + T('දශාව: ', 'Dasha: ') + (ds.names.join('-') || '—') + ' · <span class="' + scCls + '">' + T('අද ', 'Today ') + avg + '%</span></div>' +
          '</div>' +
          '<div class="kp-mini-acts">' +
            '<button type="button" id="kmini-kpp" title="KP+">🧰<span class="pc-lbl"> KP+</span></button>' +
            '<button type="button" id="kmini-gem" title="' + T('KP මැණික් & පාට', 'KP Gems & Colors') + '">💎<span class="pc-lbl"> ' + T('මැණික්', 'Gems') + '</span></button>' +
            '<button type="button" id="kmini-pdf" title="A4 PDF">📄<span class="pc-lbl"> A4 PDF</span></button>' +
            '<button type="button" id="kmini-ed" title="' + T('උපන් විස්තර වෙනස් කරන්න', 'Edit Birth Data') + '">✏️<span class="pc-lbl"> ' + T('වෙනස්', 'Edit') + '</span></button>' +
          '</div>' +
        '</div>';

      E('kmini-kpp').onclick = function () { if (window.KPLic && !window.KPLic.allow('t14', 'kpPlus')) return; nvB('t14', 'kpPlus'); openPage('t14'); };
      E('kmini-gem').onclick = function () { if (window.KPLic && !window.KPLic.allow('t19', '')) return; nvB('t19', ''); openPage('t19'); };
      E('kmini-pdf').onclick = function () { if (window.KPLic && !window.KPLic.allow('', 'pdf')) return; if (window.pdf) window.pdf(); };
      E('kmini-ed').onclick = function () { goScr('form'); };

      S.day = d;
      updateResumePill();
    }

    // Dedicated Page t19: KP Gems, Colors & Metals (1st & 11th CSL) + 6-Pillar CSL Promise + Key Summary
    window.kpGemsTab = function () {
      var el = E('t19');
      if (!el || !c) return;
      var lg = Math.floor(c.cs[0] / 30), lgDeg = dms(c.cs[0] % 30), lgL = ok(function () { return lords(c.cs[0]); });
      var mo = c.pl.Mo, mn = Math.floor(mo / 30), moL = ok(function () { return lords(mo); });
      var nk = Math.floor(mo / (40 / 3)), pd = Math.floor((mo / (40 / 3) % 1) * 4) + 1;
      var ds = ok(curDashaObj) || { names: [], end: '' };
      var pillars = ok(computePillars) || [];
      var kpGems = ok(computeKPGems);

      el.innerHTML =
        '<h3>💎 ' + T('KP මැණික්, සුබ වර්ණ, ලෝහ & සාරාංශය', 'KP Gems, Colors, Metals & Summary') + '</h3>' +
        '<div class="kl-grid">' +
          '<div class="kl-box"><small>' + T('ලග්නය (RL / NL / SL / SSL)', 'LAGNA CHAIN') + '</small><b>' + SGN[lg] + ' ' + lgDeg + '</b><small>' + (lgL ? PLN[lgL.rl] + ' · ' + PLN[lgL.nl] + ' · ' + PLN[lgL.sl] + ' · ' + PLN[lgL.ssl] : '') + '</small></div>' +
          '<div class="kl-box"><small>' + T('චන්ද්‍ර රාශිය & නැකත', 'MOON & NAKSHATRA') + '</small><b>' + SGN[mn] + ' · ' + NKN[nk % 27] + '</b><small>' + T('පාදය ', 'Pada ') + pd + (moL ? ' · SSL ' + PLN[moL.ssl] : '') + '</small></div>' +
          '<div class="kl-box" style="grid-column:1/-1"><small>' + T('දැන් පවතින දශාව (DBA)', 'RUNNING DASHA (DBA)') + '</small><b style="color:var(--ac)">' + (ds.names.join(' → ') || '—') + '</b>' + (ds.end ? '<small>' + T('අවසන්: ', 'Until: ') + ds.end + '</small>' : '') + '</div>' +
        '</div>' +

        (kpGems ? '<div class="kb-subhd">💎 ' + T('KP මැණික්, සුබ වර්ණ & ලෝහ (1 / 11 උප-අධිපති)', 'KP Gems, Colors & Metals (1st / 11th CSL)') + '</div>' +
          '<div class="kl-grid">' +
            [kpGems.c1, kpGems.c11].map(function (it) {
              return '<div class="kl-box"><small>' + it.label + '</small>' +
                '<b style="color:' + (it.ok ? 'var(--hl)' : 'var(--hn)') + '">' + (SI ? it.meta.si : it.meta.en) + ' — ' + (it.ok ? T('✅ සුදුසුයි', '✅ Eligible') : T('❌ නුසුදුසුයි', '❌ Avoid')) + '</b>' +
                '<small style="margin-top:2px">' + T('භාව: ', 'Houses: ') + (it.houses.join(', ') || '—') + (it.bad.length ? ' (' + T('6/8/12 ඇත: ', 'Has: ') + it.bad.join(',') + ')' : '') + '</small>' +
              '</div>';
            }).join('') +
          '</div>' +
          (kpGems.eligible.length
            ? kpGems.eligible.map(function (it) {
                var m = it.meta;
                return '<div class="kl-rec">' +
                  '<div class="kl-rec-hd">✨ ' + (SI ? m.si : m.en) + ' (' + (it.both ? T('1 සහ 11 භාව උප-අධිපති', '1st & 11th CSL') : (it.cusp === 1 ? T('1 වන භාව උප-අධිපති', '1st CSL') : T('11 වන භාව උප-අධිපති', '11th CSL'))) + ')</div>' +
                  '<div class="kl-grid">' +
                    '<div class="kl-box"><small>💎 ' + T('සුදුසු මැණික', 'Gemstone') + '</small><b style="color:var(--pl)">' + (SI ? m.gemSi : m.gemEn) + '</b></div>' +
                    '<div class="kl-box"><small>🎨 ' + T('ග්‍රහයාට අයත් පාට', 'Color') + '</small><b>' + (SI ? m.colSi : m.colEn) + '</b></div>' +
                    '<div class="kl-box" style="grid-column:1/-1"><small>⚙️ ' + T('පාලනය කරන ලෝහය', 'Metal Ruled') + '</small><b>' + (SI ? m.metSi : m.metEn) + '</b></div>' +
                  '</div>' +
                '</div>';
              }).join('')
            : '<div class="kl-warn">⚠️ ' + T('මෙම ජන්ම පත්‍රයේ 1 වන සහ 11 වන උප-අධිපතීන් දෙදෙනාම 6, 8 හෝ 12 භාව සම්බන්ධ කරන බැවින්, ක්‍රිෂ්ණමූර්ති (KP) සිද්ධාන්තය අනුව මැණික් පැළඳීම නිර්දේශ නොකෙරේ.', 'Both 1st and 11th Cuspal Sub-Lords signify 6, 8, or 12 in this chart, so KP rules advise against wearing a gemstone.') + '</div>') +
          '<div class="kl-note">' + T('KP සිද්ධාන්තය: මැණිකක් පැළඳීමට සුදුසු වන්නේ 1 වන හෝ 11 වන භාව උප-අධිපති 6, 8, 12 භාව ලබා නොදෙන්නේ නම් පමණි.', 'KP Rule: A gemstone is recommended ONLY for the 1st or 11th Cuspal Sub-Lord, and strictly if it does NOT signify 6, 8, or 12.') + '</div>' : '') +

        (pillars.length ? '<div class="kb-subhd">✦ ' + T('ප්‍රධාන භාව උප-අධිපති පොරොන්දුව (CSL)', 'KP Cuspal Sub-Lord Promise') + '</div>' +
          '<div class="kp-pgrid">' +
            pillars.map(function (pl) {
              var cls = pl.pct >= 60 ? 'ok' : pl.pct >= 42 ? 'mid' : 'bad';
              var bg = pl.pct >= 60 ? '#10b981' : pl.pct >= 42 ? '#38bdf8' : '#f43f5e';
              return '<div class="kp-pitem" data-ptab="' + pl.tab + '">' +
                '<span class="plb">' + pl.label + ' (' + pl.csl + ')</span>' +
                '<span class="pval ' + cls + '">' + pl.pct + '%</span>' +
                '<div class="pbar"><i style="width:' + pl.pct + '%;background:' + bg + '"></i></div>' +
              '</div>';
            }).join('') +
          '</div>' : '');

      $$('.kp-pitem', el).forEach(function (it) {
        it.onclick = function () { var pt = it.dataset.ptab, qf = pt === 't14' ? 'kpPlus' : ''; nvB(pt, qf); openPage(pt); };
      });
    };


    /* ---------- Authentic KP Astrologer Narrative Generator (v29) ---------- */
    function buildKpNarrative(ti, dateIso) {
      if (!c || !TOP[ti]) return '';
      var t = TOP[ti], name = t[0], hc = t[1], fav = t[2], bad = t[3];
      var K = ok(kpw); if (!K) return '';
      var W = K.W, Tset = K.TF[ti];

      // 1. Cusp Sub-Lord (CSL) -> Star-Lord (NL) -> Sub-Lord (SL) chain
      var cuspL = lords(c.cs[hc - 1]);
      var cslCode = P[cuspL.sl], cslName = plLbl(cslCode);
      var cslLon = c.pl[cslCode], cslChain = lords(cslLon);
      var nlCode = P[cslChain.nl], nlName = plLbl(nlCode);
      var sl2Code = P[cslChain.sl], sl2Name = plLbl(sl2Code);
      var cslRx = !!(c.rt[cslCode] || cslCode === 'Ra' || cslCode === 'Ke');
      var nlRx = !!(c.rt[nlCode] || nlCode === 'Ra' || nlCode === 'Ke');

      var w = W[cslCode] || {};
      var hitFav = fav.filter(function (h) { return w[h]; });
      var strongFav = fav.filter(function (h) { return w[h] >= 3; });
      var hitBad = bad.filter(function (h) { return w[h]; });
      var strongBad = bad.filter(function (h) { return w[h] >= 3; });

      var promLvl = (hitFav.length >= 2 && strongFav.length) ? 0 : (hitFav.length >= 1 ? 1 : 2);

      // 2. Selected Date Dasha (Maha / Antar / Pratyantar)
      var q = (dateIso || today()).split('-').map(Number);
      var sj = (q.length === 3 && q[0]) ? JD(q[0], q[1], q[2], 12 - tz) : kNow();
      var dl = dashL(sj) || [];
      var dlNames = dl.map(plLbl);
      var dlSupport = dl.filter(function (p) { return Tset && Tset.has(p); });

      // 3. Slow Transit Check (Jupiter & Saturn)
      var trHits = [];
      try {
        ['Ju', 'Sa'].forEach(function (tp) {
          var o = lords(tl(tp, sj));
          if (Tset && (Tset.has(P[o.nl]) || Tset.has(P[o.sl]))) {
            trHits.push(plLbl(tp) + ' (' + plLbl(P[o.nl]) + '/' + plLbl(P[o.sl]) + ')');
          }
        });
      } catch (e) {}

      // 4. Construct Flowing Astrological Narrative Paragraphs (Sinhala & English)
      var p1 = '', p2 = '', p3 = '', p4 = '';
      if (SI) {
        if (promLvl === 0) {
          p1 = 'ක්‍රිෂ්ණමූර්ති පද්ධතියේ (KP) මූලික සිද්ධාන්තය අනුව, <b>' + name + '</b> පිළිබඳ අවසන් තීරණය ලබා දෙන <b>' + hc + ' වන භාවයේ උප-අධිපති ' + cslName + '</b> ග්‍රහයායි. ' +
               cslName + ' ග්‍රහයා ' + nlName + ' නැකතේ සහ ' + sl2Name + ' උප-කොටසේ තැන්පත්ව, මෙම ක්ෂේත්‍රයට අවශ්‍ය ප්‍රධාන සුබ භාව (' + hitFav.join(', ') + ') ඉතා ප්‍රබලව සම්බන්ධ කරන බැවින් ඔබේ ජන්ම පත්‍රය තුළ <b>ශක්තිමත් සාර්ථකත්වයක පොරොන්දුවක්</b> පැහැදිලිවම සටහන් වී තිබේ.';
        } else if (promLvl === 1) {
          p1 = 'KP පද්ධතිය අනුව <b>' + name + '</b> පාලනය කරන <b>' + hc + ' වන භාව උප-අධිපති ' + cslName + '</b> (' + nlName + ' නැකත / ' + sl2Name + ' උප) මෙම ක්ෂේත්‍රයට අදාළ සුබ භාව (' + hitFav.join(', ') + ') මධ්‍යස්ථ මට්ටමින් සම්බන්ධ කරයි. එබැවින් මෙම කාරණය <b>ඉටුවීමට ඉඩ ඇති නමුත්</b>, යම් ප්‍රමාදයක් හෝ වැඩි උත්සාහයක් දැරීමෙන් පසුව සාර්ථක ප්‍රතිඵල ලැබෙන බව පෙනේ.';
        } else {
          p1 = 'KP සිද්ධාන්තය අනුව <b>' + name + '</b> සඳහා වන <b>' + hc + ' වන භාව උප-අධිපති ' + cslName + '</b> (' + nlName + ' නැකත / ' + sl2Name + ' උප) අවශ්‍ය ප්‍රබල සුබ භාව (' + fav.join(', ') + ') සෘජුවම සම්බන්ධ නොකරයි. එනිසා ස්වභාවිකවම මෙම ක්ෂේත්‍රයේ <b>පොරොන්දුව දුර්වල හෝ බාධක සහිත</b> වන අතර, විශේෂිත සුබ දශා-ගෝචර කාලවලදී පමණක් සීමිත ප්‍රතිඵල අපේක්ෂා කළ හැකිය.';
        }

        if (strongBad.length) {
          p1 += ' තවද ප්‍රතිවිරුද්ධ/බාධක භාව (' + strongBad.join(', ') + ') ද සම්බන්ධ වන නිසා අතරමඟ බාධා හෝ අමතර කැපවීමක් අවශ්‍ය විය හැකිය.';
        }
        if (cslRx && cslCode !== 'Ra' && cslCode !== 'Ke') {
          p1 += ' ' + cslName + ' ජන්මයේදී <b>වක්‍ර (Retrograde)</b> බැවින් KP නීතිය අනුව ප්‍රතිඵල ලැබීමේදී ප්‍රමාදයක් හෝ දෙවන උත්සාහයකදී සාර්ථක වීමේ ස්වභාවයක් පෙන්වයි' + (nlRx ? '.' : ' (නමුත් නැකත් අධිපති ' + nlName + ' සෘජු බැවින් ප්‍රතිඵල අහිමි නොවේ).');
        }

        p2 = '<b>' + dateIso + '</b> දිනය වන විට ඔබට ක්‍රියාත්මක වන්නේ <b>' + (dlNames.join(' → ') || '—') + '</b> දශා කාලයයි. ';
        if (dlSupport.length >= 2) {
          p2 += 'මෙම දශා අධිපතීන්ගෙන් <b>' + dlSupport.map(plLbl).join(' සහ ') + '</b> මෙම ක්ෂේත්‍රයේ භාව සෘජුවම සක්‍රීය කරන බැවින්, මෙය <b>' + name + ' සඳහා ක්‍රියාත්මක වීමට ඉතා සුබ හා ප්‍රතිඵලදායක කාල පරිච්ඡේදයකි</b>.';
        } else if (dlSupport.length === 1) {
          p2 += 'මින් <b>' + plLbl(dlSupport[0]) + '</b> පමණක් මෙම ක්ෂේත්‍රයට සහය දෙන බැවින්, මෙම කාලය <b>මධ්‍යස්ථ සූදානම් වීමේ අවධියක්</b> ලෙස සැලකිය හැකිය. සම්පූර්ණ ප්‍රතිඵල සඳහා අන්තර්/ප්‍රත්‍යන්තර දශා මාරුවීම් වැදගත් වේ.';
        } else {
          p2 += 'දැනට ක්‍රියාත්මක දශා අධිපතීන් මෙම ක්ෂේත්‍රයේ භාව ප්‍රබලව සක්‍රීය නොකරන නිසා, මෙම කාලයේදී ඉක්මන් තීරණ නොගෙන පහත දැක්වෙන <b>ඉදිරි සුබ දශා කාල</b> වෙත අවධානය යොමු කිරීම නුවණට හුරුය.';
        }

        p3 = trHits.length
          ? '<b>ගෝචර සහාය:</b> තෝරාගත් කාලයේදී ' + trHits.join(' සහ ') + ' ගෝචරයෙන් මෙම ක්ෂේත්‍රයේ සංඥාකාරක නැකත්/උප-කොටස් හරහා ගමන් කරමින් KP කාල නිර්ණයට ධනාත්මක උත්තේජනයක් (Transit Trigger) ලබා දෙයි.'
          : '<b>ගෝචර සහාය:</b> ගුරු සහ ශනි ගෝචරය තවම මෙම ක්ෂේත්‍රයේ ප්‍රබල නැකත්/උප-කොටස් සම්පූර්ණයෙන් සක්‍රීය කර නොමැති බැවින්, ඉදිරි මාසවල ගෝචර මාරුවීම් සමඟ වේගය වැඩි වේ.';

        p4 = promLvl === 0
          ? '<b>KP උපදෙස:</b> ඔබේ ජන්ම පොරොන්දුව ප්‍රබලයි. පහත දැක්වෙන සක්‍රීය දශා සහ සුබ මුහුර්ත කාලවලදී විශ්වාසයෙන් පියවර තැබීමෙන් උපරිම සාර්ථකත්වයක් ලබාගත හැකිය.'
          : (promLvl === 1
            ? '<b>KP උපදෙස:</b> ඉවසීමෙන් හා සැලසුම් සහගතව කටයුතු කරන්න. පහත "මාස 12" හෝ "වසර 120" තුළ ඉහළම ලකුණු (%) පෙන්වන කාල තෝරාගෙන ක්‍රියාත්මක වීමෙන් බාධා අවම කරගත හැකිය.'
            : '<b>KP උපදෙස:</b> අනවශ්‍ය අවදානම් ගැනීමෙන් වළකින්න. දශා සහ ගෝචර දෙකම ඉහළින්ම ගැළපෙන සීමිත සුබ මාස පමණක් තෝරාගෙන සැලකිල්ලෙන් කටයුතු කිරීම වඩාත් ආරක්ෂිතයි.');
      } else {
        if (promLvl === 0) {
          p1 = 'Under Krishnamurti Paddhati (KP) principles, the <b>' + hc + 'th Cusp Sub-Lord (' + cslName + ')</b> governs <b>' + name + '</b>. Placed in the star of ' + nlName + ' and sub of ' + sl2Name + ', ' + cslName + ' strongly signifies the fruitful houses (' + hitFav.join(', ') + '), confirming a <b>clear natal promise of success</b>.';
        } else if (promLvl === 1) {
          p1 = 'For <b>' + name + '</b>, the <b>' + hc + 'th Cusp Sub-Lord (' + cslName + ')</b> (in ' + nlName + ' star / ' + sl2Name + ' sub) moderately connects to the supportive houses (' + hitFav.join(', ') + '). The event is <b>promised with some delay or extra effort</b>.';
        } else {
          p1 = 'For <b>' + name + '</b>, the <b>' + hc + 'th Cusp Sub-Lord (' + cslName + ')</b> does not strongly link to the primary favorable houses (' + fav.join(', ') + '), indicating a <b>weak or challenging natal promise</b> where results rely heavily on selective favorable dasha-transit windows.';
        }
        if (strongBad.length) p1 += ' Strong links to opposing houses (' + strongBad.join(', ') + ') also suggest periodic hurdles.';
        if (cslRx && cslCode !== 'Ra' && cslCode !== 'Ke') p1 += ' Because ' + cslName + ' is <b>retrograde</b>, KP rules indicate initial delays or success on a second attempt.';

        p2 = 'On <b>' + dateIso + '</b>, the running Dasha-Bhukti-Antara is <b>' + (dlNames.join(' → ') || '—') + '</b>. ' +
             (dlSupport.length >= 2
               ? 'With <b>' + dlSupport.map(plLbl).join(' & ') + '</b> jointly signifying this area, this is an <b>active, supportive period for concrete results</b>.'
               : dlSupport.length === 1
                 ? 'Only <b>' + plLbl(dlSupport[0]) + '</b> supports this area right now, making this a <b>preparatory or moderate phase</b>.'
                 : 'The current dasha lords do not strongly trigger these houses; focus on the upcoming active windows listed below.');

        p3 = trHits.length
          ? '<b>Transit Support:</b> ' + trHits.join(' & ') + ' transits are actively supporting the significator stars/subs during this period.'
          : '<b>Transit Support:</b> Major slow transits (Jupiter/Saturn) are currently neutral for this topic; momentum builds as they shift into significator stars.';

        p4 = promLvl === 0
          ? '<b>KP Guidance:</b> Your natal promise is strong — act confidently during the peak months and auspicious muhurtas below.'
          : (promLvl === 1
            ? '<b>KP Guidance:</b> Stay patient and time key actions during the highest-scoring months in 12 Months / 120 Years.'
            : '<b>KP Guidance:</b> Avoid unnecessary risk; wait for peak dasha + transit alignment before making major commitments.');
      }

      var plainCopy = (name + ' (' + dateIso + ')\n\n' + p1 + '\n\n' + p2 + '\n\n' + p3 + '\n\n' + p4).replace(/<[^>]+>/g, '');
      window._kpLastNarr = plainCopy;

      return '<div class="kp-narr">' +
        '<div class="kp-narr-hd"><span>✨ ' + T('KP සිද්ධාන්ත විග්‍රහය (සවිස්තර පලාපල)', 'KP Master Narrative Reading') + '</span>' +
        '<button type="button" class="kp-minia" onclick="try{navigator.clipboard.writeText(window._kpLastNarr||&quot;&quot;);if(window.KPB&&window.KPB.mnToast)window.KPB.mnToast(&quot;📋 ' + T('විස්තරය කොපි විය!', 'Reading copied!') + '&quot;)}catch(e){}">📋 ' + T('කොපි', 'Copy') + '</button></div>' +
        '<p>' + p1 + '</p>' +
        '<p>' + p2 + '</p>' +
        '<p>' + p3 + '</p>' +
        '<p class="kp-narr-tip">' + p4 + '</p>' +
      '</div>';
    }

    /* ==========================================================================
       t5: CLEAN FOCUSED KP FORECAST STUDIO (Instant Auto-Update on Area/Date)
       ========================================================================== */
    var fcMode = 'ev';
    var fcTopic = 0;
    var fcDate = '';

    window.kpForecastTab = function () {
      var el = E('t5');
      if (!el || !c) return;
      if (!fcDate) fcDate = kIso(kNow());

      // Sync #kd if KP+ (#t14) already exists, without creating a duplicate hidden #kd
      if (E('kd')) E('kd').value = fcDate;

      function renderBody() {
        var out = E('kp-fc-out');
        if (!out) return;
        if (E('kd')) E('kd').value = fcDate;
        try {
          var html = '';
          if (fcMode === 'ev') html = buildKpNarrative(fcTopic, fcDate) + evRep(fcTopic);
          else if (fcMode === 'mo') html = monRep(fcTopic);
          else if (fcMode === 'lf') html = lifeRep(fcTopic);
          else if (fcMode === 'mu') html = muhRep(fcTopic);
          out.innerHTML = html;
        } catch (e) {
          out.innerHTML = '<div class="sub">' + T('දෝෂයක්: ', 'Error: ') + esc(e.message) + '</div>';
        }
        $$('#kp-fc-tabs button', el).forEach(function (b) {
          b.classList.toggle('p', b.dataset.fm === fcMode);
        });
      }

      // Hook kShiftDate / kSetBirth / kSetToday / kJump / kLifeShift when on t5 so inline nav buttons work seamlessly!
      el.innerHTML =
        '<h3>🔮 ' + T('KP පලාපල (ක්ෂේත්‍රය අනුව)', 'KP Forecast Studio') + '</h3>' +
        '<label>' + T('ක්ෂේත්‍රය තෝරන්න', 'Select Area') + ' <select id="kp-fc-q">' +
          TOP.map(function (x, i) { return '<option value="' + i + '"' + (i === fcTopic ? ' selected' : '') + '>' + x[0] + '</option>'; }).join('') +
        '</select></label>' +
        '<label>' + T('දිනය (අතීත / අනාගත)', 'Target Date (Past / Future)') + ' <input type="date" id="kp-fc-d" value="' + fcDate + '"></label>' +
        '<div class="bar" id="kp-fc-tabs">' +
          '<button type="button" data-fm="ev">🎯 ' + T('පලාපල', 'Events') + '</button>' +
          '<button type="button" data-fm="mo">📅 ' + T('මාස 12', '12 Months') + '</button>' +
          '<button type="button" data-fm="lf">♾️ ' + T('වසර 120', '120 Yrs') + '</button>' +
          '<button type="button" data-fm="mu">🕉️ ' + T('මුහුර්ත', 'Muhurta') + '</button>' +
        '</div>' +
        '<div id="kp-fc-out"></div>' +
        '<div style="margin-top:10px">' +
          '<button type="button" id="kp-fc-spir" style="width:100%;margin-bottom:7px;background:rgba(168,85,247,0.16);border-color:rgba(168,85,247,0.45)">🧘 ' + T('මෙම බාධා/අපල සමනයට ශබ්ද & භාවනා සහන බලන්න', 'Open Chart Sound Frequencies & Meditation Remedies') + '</button>' +
          '<button type="button" id="kp-fc-all" style="width:100%">📋 ' + T('සියලු ක්ෂේත්‍ර (18) සාරාංශ ලැයිස්තුව බලන්න', 'View All 18 Topics Summary List') + '</button>' +
        '</div>';

      E('kp-fc-q').onchange = function () {
        fcTopic = +this.value;
        renderBody();
      };
      E('kp-fc-d').onchange = function () {
        fcDate = this.value || kIso(kNow());
        if (E('kd')) E('kd').value = fcDate;
        renderBody();
      };
      window.KPLAST = fcMode;
      E('kp-fc-tabs').onclick = function (e) {
        var b = e.target.closest('button[data-fm]');
        if (!b) return;
        fcMode = b.dataset.fm;
        window.KPLAST = fcMode;
        renderBody();
      };
      E('kp-fc-spir').onclick = function () { if (typeof window.nvB === 'function') window.nvB('t26', ''); openPage('t26'); };
      E('kp-fc-all').onclick = function () {
        if (E('t23') && !E('t23').innerHTML && typeof window.go === 'function') {
          try { window.go(); } catch (e) {}
        }
        if (typeof window.nvB === 'function') window.nvB('t23', '');
        openPage('t23');
      };

      // Also sync kpx() calls triggered by inline buttons inside evRep/monRep/lifeRep/muhRep when t5 is active!
      if (!window._kpKpxWrapped && typeof window.kpx === 'function') {
        window._kpKpxWrapped = true;
        var origKpx = window.kpx;
        window.kpx = function (f) {
          var t5El = E('t5');
          if (t5El && t5El.style.display === 'block') {
            var nd = (E('kp-fc-d') && E('kp-fc-d').value) || (E('kd') && E('kd').value);
            if (nd) {
              fcDate = nd;
              if (E('kp-fc-d')) E('kp-fc-d').value = fcDate;
              if (E('kd')) E('kd').value = fcDate;
            }
            if (f === 'ev' || f === 'mo' || f === 'lf' || f === 'mu') {
              fcMode = f;
              window.KPLAST = f;
            }
            renderBody();
            return;
          }
          return origKpx(f);
        };
      }

      renderBody();
    };

    /* ==========================================================================
       t20: AUTHENTIC KP ASPECTS (WESTERN 3°20' / 6°40' ORBS + VEDIC DRISHTI)
       ========================================================================== */
    var KP_ASP_DEFS = [
      { ang: 0,   sym: '☌', si: 'සංයෝග (0°)',  en: 'Conjunction (0°)',  cls: 'con', descSi: 'බල ඒකාබද්ධ වීම',     descEn: 'Union / Intensification' },
      { ang: 60,  sym: '⚹', si: 'ෂෂ්ටාංශ (60°)', en: 'Sextile (60°)',    cls: 'ok',  descSi: 'සහයෝගී / අවස්ථා',   descEn: 'Constructive / Opportunity' },
      { ang: 90,  sym: '□', si: 'චතුරශ්‍ර (90°)', en: 'Square (90°)',     cls: 'bad', descSi: 'ඝට්ටන / ප්‍රමාද',    descEn: 'Friction / Effort' },
      { ang: 120, sym: '△', si: 'ත්‍රිකෝණ (120°)', en: 'Trine (120°)',     cls: 'ok',  descSi: 'සුමට / සුබ සහය',    descEn: 'Harmonious / Easy Flow' },
      { ang: 180, sym: '☍', si: 'ප්‍රතිමුඛ (180°)', en: 'Opposition (180°)', cls: 'bad', descSi: 'විරුද්ධ / බාහිර බල', descEn: 'Polarization / Confrontation' }
    ];
    var ASP_PL = ['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'];
    var PL_SI_MAP = { Su:'රවි', Mo:'චන්ද්‍ර', Ma:'කුජ', Me:'බුධ', Ju:'ගුරු', Ve:'සිකුරු', Sa:'ශනි', Ra:'රාහු', Ke:'කේතු' };
    var PL_EN_MAP = { Su:'Sun', Mo:'Moon', Ma:'Mars', Me:'Mercury', Ju:'Jupiter', Ve:'Venus', Sa:'Saturn', Ra:'Rahu', Ke:'Ketu' };
    function plLbl(code) { return SI ? (PL_SI_MAP[code] || code) : (PL_EN_MAP[code] || code); }

    function angDiff(a, b) {
      var d = Math.abs(a - b) % 360;
      return d > 180 ? 360 - d : d;
    }
    function fmtOrb(deg) {
      var d = Math.floor(deg), m = Math.round((deg - d) * 60);
      if (m === 60) { d++; m = 0; }
      return d + '°' + String(m).padStart(2, '0') + "'";
    }
    function planetSigHouses(code, sigObj) {
      var lv = (sigObj && sigObj[code]) || [[], [], [], []], out = [];
      [0, 1, 2, 3].forEach(function (i) { (lv[i] || []).forEach(function (h) { if (out.indexOf(h) === -1) out.push(h); }); });
      return out.sort(function (a, b) { return a - b; });
    }
    function planetSpeed(code) {
      try {
        var l1 = tl(code, bjd), l2 = tl(code, bjd + 0.04);
        var df = l2 - l1;
        if (df > 180) df -= 360;
        if (df < -180) df += 360;
        return df / 0.04;
      } catch (e) { return 0; }
    }

    var aspMode = 'pp';
    window.kpAspectsTab = function () {
      var el = E('t20');
      if (!el || !c) return;
      var _sg = ok(function () { return signif(c); });
      var sigObj = (_sg && (_sg.out || _sg)) || {};
      var speeds = {};
      ASP_PL.forEach(function (p) { speeds[p] = planetSpeed(p); });

      // 1. Planet-to-Planet Western KP Aspects (3°20' orb; 6°40' for Sun)
      var ppRows = [];
      for (var i = 0; i < ASP_PL.length; i++) {
        for (var j = i + 1; j < ASP_PL.length; j++) {
          var p1 = ASP_PL[i], p2 = ASP_PL[j];
          if ((p1 === 'Ra' && p2 === 'Ke') || (p1 === 'Ke' && p2 === 'Ra')) continue;
          var l1 = c.pl[p1], l2 = c.pl[p2];
          var diff = angDiff(l1, l2);
          var maxOrb = (p1 === 'Su' || p2 === 'Su') ? (6 + 40 / 60) : (3 + 20 / 60);
          for (var k = 0; k < KP_ASP_DEFS.length; k++) {
            var ad = KP_ASP_DEFS[k], orb = Math.abs(diff - ad.ang);
            if (orb <= maxOrb) {
              var diffNext = angDiff((l1 + speeds[p1] * 0.05 + 360) % 360, (l2 + speeds[p2] * 0.05 + 360) % 360);
              var applying = Math.abs(diffNext - ad.ang) < orb;
              ppRows.push({
                p1: p1, p2: p2, asp: ad, orb: orb, applying: applying,
                h1: planetSigHouses(p1, sigObj).join(','),
                h2: planetSigHouses(p2, sigObj).join(',')
              });
              break;
            }
          }
        }
      }
      ppRows.sort(function (a, b) { return a.orb - b.orb; });

      // 2. Planet-to-Cusp Western KP Aspects (3°20' orb; 6°40' for Sun)
      var pcRows = [];
      for (var pi = 0; pi < ASP_PL.length; pi++) {
        var pl = ASP_PL[pi], lp = c.pl[pl];
        var mOrb = pl === 'Su' ? (6 + 40 / 60) : (3 + 20 / 60);
        for (var ci = 0; ci < 12; ci++) {
          var lc = c.cs[ci], df = angDiff(lp, lc);
          for (var ki = 0; ki < KP_ASP_DEFS.length; ki++) {
            var ad2 = KP_ASP_DEFS[ki], ob2 = Math.abs(df - ad2.ang);
            if (ob2 <= mOrb) {
              var dfN = angDiff((lp + speeds[pl] * 0.05 + 360) % 360, lc);
              pcRows.push({
                pl: pl, cusp: ci + 1, asp: ad2, orb: ob2,
                applying: Math.abs(dfN - ad2.ang) < ob2,
                hp: planetSigHouses(pl, sigObj).join(',')
              });
              break;
            }
          }
        }
      }
      pcRows.sort(function (a, b) { return a.cusp - b.cusp || a.orb - b.orb; });

      // 3. Vedic Aspects (Drishti)
      var VEDIC_OFF = { Su:[7], Mo:[7], Ma:[4,7,8], Me:[7], Ju:[5,7,9], Ve:[7], Sa:[3,7,10], Ra:[5,7,9], Ke:[5,7,9] };
      var lagnaSg = Math.floor(c.cs[0] / 30);
      var plByHouse = {};
      ASP_PL.forEach(function (p) {
        var hs = ((Math.floor(c.pl[p] / 30) - lagnaSg + 12) % 12) + 1;
        (plByHouse[hs] = plByHouse[hs] || []).push(p);
      });
      var vedRows = ASP_PL.map(function (p) {
        var h0 = ((Math.floor(c.pl[p] / 30) - lagnaSg + 12) % 12) + 1;
        var tgt = VEDIC_OFF[p].map(function (off) {
          var th = ((h0 - 1 + off - 1) % 12) + 1;
          var occ = (plByHouse[th] || []).filter(function (x) { return x !== p; });
          return { h: th, occ: occ };
        });
        return { p: p, h0: h0, tgt: tgt, sig: planetSigHouses(p, sigObj).join(',') };
      });

      var bodyHtml = '';
      if (aspMode === 'pp') {
        bodyHtml = ppRows.length
          ? ppRows.map(function (r) {
              return '<div class="r">' +
                '<div class="kp-drow">' +
                  '<span><span class="pc pc-' + r.p1 + '">' + r.p1 + '</span> <b>' + r.asp.sym + ' ' + (SI ? r.asp.si : r.asp.en) + '</b> <span class="pc pc-' + r.p2 + '">' + r.p2 + '</span></span>' +
                  '<span class="kp-tag-s">' + fmtOrb(r.orb) + ' · ' + (r.applying ? T('ළංවෙන', 'App') : T('ඈත්වෙන', 'Sep')) + '</span>' +
                '</div>' +
                '<small>' + plLbl(r.p1) + ' (' + T('භාව: ', 'H: ') + (r.h1 || '—') + ') ↔ ' + plLbl(r.p2) + ' (' + T('භාව: ', 'H: ') + (r.h2 || '—') + ') · ' + (SI ? r.asp.descSi : r.asp.descEn) + '</small>' +
              '</div>';
            }).join('')
          : '<div class="sub">' + T('3°20′ (රවි 6°40′) KP සීමාව තුළ ග්‍රහ–ග්‍රහ දෘෂ්ටි හමු නොවීය.', 'No planet-to-planet aspects within strict KP orb (3°20′, Sun 6°40′).') + '</div>';
      } else if (aspMode === 'pc') {
        bodyHtml = pcRows.length
          ? pcRows.map(function (r) {
              return '<div class="r">' +
                '<div class="kp-drow">' +
                  '<span><span class="pc pc-' + r.pl + '">' + r.pl + '</span> <b>' + r.asp.sym + ' ' + (SI ? r.asp.si : r.asp.en) + '</b> → <b>' + T(r.cusp + ' භාව සන්ධිය', 'Cusp ' + r.cusp) + '</b></span>' +
                  '<span class="kp-tag-s">' + fmtOrb(r.orb) + ' · ' + (r.applying ? T('ළංවෙන', 'App') : T('ඈත්වෙන', 'Sep')) + '</span>' +
                '</div>' +
                '<small>' + plLbl(r.pl) + ' ' + T('සම්බන්ධ කරන භාව: ', 'signifies houses: ') + '<b>' + (r.hp || '—') + '</b> · ' + (SI ? r.asp.descSi : r.asp.descEn) + '</small>' +
              '</div>';
            }).join('')
          : '<div class="sub">' + T('KP සීමාව තුළ ග්‍රහ–භාව දෘෂ්ටි හමු නොවීය.', 'No planet-to-cusp aspects within strict KP orb.') + '</div>';
      } else {
        bodyHtml = vedRows.map(function (r) {
          return '<div class="r">' +
            '<div class="kp-drow"><span><span class="pc pc-' + r.p + '">' + r.p + '</span> <b>' + plLbl(r.p) + '</b> (' + T(r.h0 + ' භාවයේ', 'in H' + r.h0) + ')</span><small>' + T('භාව: ', 'Sig: ') + (r.sig || '—') + '</small></div>' +
            '<small>' + T('වෛදික දෘෂ්ටි: ', 'Vedic Drishti: ') + r.tgt.map(function (x) { return '<b>' + x.h + '</b>' + (x.occ.length ? ' (' + x.occ.join(',') + ')' : ''); }).join(' · ') + '</small>' +
          '</div>';
        }).join('');
      }

      el.innerHTML =
        '<h3>📐 ' + T('KP දෘෂ්ටි වගුව (Western & Vedic Aspects)', 'KP Aspects (Western & Vedic)') + '</h3>' +
        '<div class="sub">' + T('KP සිද්ධාන්තය: දෘෂ්ටි සීමාව (Orb) සාමාන්‍ය ග්‍රහයන්ට 3°20′ සහ රවිට 6°40′ වේ. දෘෂ්ටිය සුබ/අසුබ තීරණය වන්නේ කෝණයෙන් පමණක් නොව, දෘෂ්ටි හෙළන ග්‍රහයා සම්බන්ධ කරන භාව (Significators) අනුවයි.', 'KP Rule: Strict orb is 3°20′ for planets and 6°40′ for Sun. An aspect is judged improving or non-improving by the houses signified by the aspecting planet, not by angle alone.') + '</div>' +
        '<div class="bar" id="kp-asp-bar">' +
          '<button type="button" class="' + (aspMode === 'pp' ? 'p' : '') + '" data-am="pp">🪐 ' + T('ග්‍රහ–ග්‍රහ', 'Planet–Planet') + ' (' + ppRows.length + ')</button>' +
          '<button type="button" class="' + (aspMode === 'pc' ? 'p' : '') + '" data-am="pc">🏠 ' + T('ග්‍රහ–භාව', 'Planet–Cusp') + ' (' + pcRows.length + ')</button>' +
          '<button type="button" class="' + (aspMode === 'vd' ? 'p' : '') + '" data-am="vd">🕉️ ' + T('වෛදික', 'Vedic') + '</button>' +
        '</div>' +
        bodyHtml;

      E('kp-asp-bar').onclick = function (e) {
        var b = e.target.closest('button[data-am]');
        if (!b) return;
        aspMode = b.dataset.am;
        window.kpAspectsTab();
      };
    };

    /* ==========================================================================
       t21: EXACT PLANETARY TRANSIT INGRESS TIMES (SIGN / STAR / SUB / RETROGRADE)
       ========================================================================== */
    function fmtJDFull(jd) {
      var d = new Date((jd - 2440587.5) * 864e5 + tz * 36e5);
      return d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0') + '-' + String(d.getUTCDate()).padStart(2, '0') +
        ' ' + String(d.getUTCHours()).padStart(2, '0') + ':' + String(d.getUTCMinutes()).padStart(2, '0');
    }
    function findNextChange(pl, startJD, keyFn, stepDays, maxDays) {
      var k0 = keyFn(tl(pl, startJD));
      var tPrev = startJD;
      for (var d = stepDays; d <= maxDays; d += stepDays) {
        var tCur = startJD + d;
        var kCur = keyFn(tl(pl, tCur));
        if (kCur !== k0) {
          var lo = tPrev, hi = tCur;
          for (var it = 0; it < 18; it++) {
            var mid = (lo + hi) / 2;
            if (keyFn(tl(pl, mid)) === k0) lo = mid; else hi = mid;
          }
          return { jd: hi, val: keyFn(tl(pl, hi + 1e-4)) };
        }
        tPrev = tCur;
      }
      return null;
    }
    function findNextStation(pl, startJD, maxDays) {
      if (pl === 'Su' || pl === 'Mo' || pl === 'Ra' || pl === 'Ke') return null;
      function isRx(jd) {
        var df = tl(pl, jd + 0.05) - tl(pl, jd);
        if (df > 180) df -= 360;
        if (df < -180) df += 360;
        return df < 0;
      }
      var r0 = isRx(startJD), step = pl === 'Me' || pl === 'Ve' ? 2 : 5, prev = startJD;
      for (var d = step; d <= maxDays; d += step) {
        var cur = startJD + d;
        if (isRx(cur) !== r0) {
          var lo = prev, hi = cur;
          for (var it = 0; it < 16; it++) {
            var mid = (lo + hi) / 2;
            if (isRx(mid) === r0) lo = mid; else hi = mid;
          }
          return { jd: hi, toRx: !r0 };
        }
        prev = cur;
      }
      return null;
    }

    var exactTrDate = '';
    window.kpExactTrTab = function () {
      var el = E('t21');
      if (!el) return;
      if (!exactTrDate) exactTrDate = today();
      var q = exactTrDate.split('-').map(Number);
      var j0 = (q.length === 3 && q[0]) ? JD(q[0], q[1], q[2], 12 - tz) : (Date.now() / 864e5 + 2440587.5);

      var cfg = [
        ['Mo', 0.05, 0.25, 0.5, 40],
        ['Su', 0.25, 1, 2, 45],
        ['Me', 0.2, 0.8, 1.5, 90],
        ['Ve', 0.2, 1, 2, 120],
        ['Ma', 0.5, 2, 4, 240],
        ['Ju', 1.5, 5, 10, 420],
        ['Sa', 2.5, 10, 15, 950],
        ['Ra', 2, 8, 15, 620],
        ['Ke', 2, 8, 15, 620]
      ];

      var rows = cfg.map(function (cf) {
        var pl = cf[0], lon = tl(pl, j0), ld = lords(lon);
        var df = tl(pl, j0 + 0.05) - lon;
        if (df > 180) df -= 360; if (df < -180) df += 360;
        var isR = (pl === 'Ra' || pl === 'Ke') ? true : (df < 0);

        var nxSub = findNextChange(pl, j0, function (l) { return lords(l).sl; }, cf[1], Math.min(cf[4], 180));
        var nxStar = findNextChange(pl, j0, function (l) { return lords(l).nk; }, cf[2], cf[4]);
        var nxSign = findNextChange(pl, j0, function (l) { return Math.floor(l / 30); }, cf[3], cf[4]);
        var nxSt = findNextStation(pl, j0, 260);

        return '<div class="r">' +
          '<div class="kp-drow">' +
            '<span><span class="pc pc-' + pl + '">' + pl + (isR ? '<sup>R</sup>' : '') + '</span> <b>' + plLbl(pl) + '</b> · ' + SGN[ld.sg] + ' ' + dms(lon % 30) + '</span>' +
            '<span class="kp-tag-s">' + PLN[ld.nl] + ' / ' + PLN[ld.sl] + '</span>' +
          '</div>' +
          '<div style="font-size:11.5px;color:var(--mu);margin-top:4px;line-height:1.6">' +
            '• <b>' + T('උප-අධිපති මාරුව:', 'Next Sub:') + '</b> ' + (nxSub ? '<b style="color:var(--ac)">' + PLN[nxSub.val] + '</b> · ' + fmtJDFull(nxSub.jd) : '—') + '<br>' +
            '• <b>' + T('නැකත් මාරුව:', 'Next Star:') + '</b> ' + (nxStar ? '<b style="color:var(--hl)">' + NKN[nxStar.val % 27] + ' (' + PLN[nxStar.val % 9] + ')</b> · ' + fmtJDFull(nxStar.jd) : '—') + '<br>' +
            '• <b>' + T('රාශි මාරුව:', 'Next Sign:') + '</b> ' + (nxSign ? '<b style="color:var(--gold)">' + SGN[nxSign.val % 12] + '</b> · ' + fmtJDFull(nxSign.jd) : '—') +
            (nxSt ? '<br>• <b>' + T('වක්‍ර/සෘජු මාරුව:', 'Station:') + '</b> ' + (nxSt.toRx ? T('⟲ වක්‍ර වීම', '⟲ Turns Retrograde') : T('➜ සෘජු වීම', '➜ Turns Direct')) + ' · ' + fmtJDFull(nxSt.jd) : '') +
          '</div>' +
        '</div>';
      }).join('');

      el.innerHTML =
        '<h3>⏱ ' + T('නිශ්චිත ගෝචර මාරුවීම් (Exact Sign / Star / Sub)', 'Exact Planetary Transits (Sign / Star / Sub)') + '</h3>' +
        '<label>' + T('ආරම්භක දිනය', 'Start Date') + ' <input type="date" id="kp-etr-dt" value="' + exactTrDate + '"></label>' +
        '<div class="sub">' + T('සෑම ග්‍රහයෙකුම ඊළඟ උප-අධිපති (Sub), නැකත (Star), රාශිය (Sign) සහ වක්‍ර/සෘජු වන නිශ්චිත දිනය සහ වේලාව (මිනිත්තුවටම).', 'Exact date & time (to the minute) when each planet changes Sub-Lord, Star (Nakshatra), Sign (Rasi), or turns Retrograde/Direct.') + '</div>' +
        rows;

      E('kp-etr-dt').onchange = function () {
        exactTrDate = this.value || today();
        window.kpExactTrTab();
      };
    };

    /* ==========================================================================
       t22: AUTHENTIC KP PRINCIPLES & HOUSE GROUPINGS GUIDE (BILINGUAL)
       ========================================================================== */
    window.kpLearnTab = function () {
      var el = E('t22');
      if (!el) return;
      el.innerHTML =
        '<h3>📚 ' + T('ක්‍රිෂ්ණමූර්ති පද්ධති (KP) මූලික සිද්ධාන්ත අත්පොත', 'Krishnamurti Paddhati (KP) Principles Handbook') + '</h3>' +
        '<div class="sub">' + T('නිවැරදි KP පලාපල කීම සඳහා අත්‍යවශ්‍ය මූලික නීති, භාව සංයෝජන සහ පියවර සාරාංශය.', 'Essential KP astrology principles, A-B-C-D significators, house groupings, aspects, and timing workflow.') + '</div>' +

        '<details class="adv" open><summary>1️⃣ ' + T('භාව උප-අධිපති (Cusp Sub-Lord) තීරණ නීතිය', 'Cusp Sub-Lord (CSL) Judgment Rule') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.7">' +
          T('KP පද්ධතියේ ඕනෑම සිදුවීමක් <b>සිදුවෙනවාද / නැද්ද</b> තීරණය කරන්නේ අදාළ භාව සන්ධියේ <b>උප-අධිපති (CSL)</b> විසිනි:<br>• <b>ග්‍රහයා</b> = ප්‍රභවය (Source)<br>• <b>නක්ෂත්‍රාධිපති (Star-Lord)</b> = සැබෑ ප්‍රතිඵලය (Result)<br>• <b>උප-අධිපති (Sub-Lord)</b> = අවසන් තීරණය — සුබද / අසුබද (Final Verdict).<br>ඕනෑම භාවයකින් 12 වන භාවය (උදා: 7ට 6, 11ට 10) එම භාවයේ ඵල ප්‍රතික්ෂේප හෝ දුර්වල කරයි.',
            'In KP astrology, the <b>Cuspal Sub-Lord (CSL)</b> decides whether an event is promised or denied:<br>• <b>Planet</b> = Source<br>• <b>Star-Lord (NL)</b> = Actual Result<br>• <b>Sub-Lord (SL)</b> = Final Verdict (Quality / Yes or No).<br>The 12th house from any relevant cusp tends to negate or reduce its results.') +
        '</div></details>' +

        '<details class="adv" open><summary>2️⃣ ' + T('A, B, C, D භාව සංඥාකාරක ශක්ති අනුපිළිවෙළ (4-Level Significators)', '4-Level House Significators (A, B, C, D)') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.7">' +
          T('• <b>A (ඉතා ප්‍රබල):</b> භාවයේ සිටින ග්‍රහයෙකුගේ නැකතේ සිටින ග්‍රහයන්.<br>• <b>B (ප්‍රබල):</b> භාවය තුළ සෘජුවම සිටින ග්‍රහයන් (Occupants).<br>• <b>C (සාමාන්‍ය):</b> භාව අධිපතිගේ නැකතේ සිටින ග්‍රහයන්.<br>• <b>D (දුර්වල):</b> භාව අධිපති (Owner) — භාවයේ ග්‍රහයන් නැති විට වැදගත් වේ.',
            '• <b>A (Very Strong):</b> Planets in the star of occupants of the house.<br>• <b>B (Strong):</b> Planets directly occupying the house.<br>• <b>C (Moderate):</b> Planets in the star of the house owner.<br>• <b>D (Weak):</b> Owner of the house.') +
        '</div></details>' +

        '<details class="adv" open><summary>3️⃣ ' + T('ප්‍රධාන ජීවිත ක්ෂේත්‍ර සඳහා KP භාව සංයෝජන', 'KP House Groupings for Major Life Events') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.75">' +
          '• <b>' + T('විවාහය:', 'Marriage:') + '</b> 2, 7, 11 <small>(' + T('වෙන්වීම / බාධා:', 'Denial/Separation:') + ' 1, 6, 10, 12)</small><br>' +
          '• <b>' + T('ආදර විවාහය:', 'Love Marriage:') + '</b> 5, 7, 11<br>' +
          '• <b>' + T('රැකියාව / වෘත්තිය:', 'Job / Career:') + '</b> 2, 6, 10, 11<br>' +
          '• <b>' + T('ව්‍යාපාර:', 'Business:') + '</b> 2, 7, 10, 11<br>' +
          '• <b>' + T('අධ්‍යාපනය:', 'Education:') + '</b> 4, 5, 9, 11<br>' +
          '• <b>' + T('දේපළ / නිවාස / වාහන:', 'Property / Vehicle:') + '</b> 4, 11, 12<br>' +
          '• <b>' + T('දරුඵල:', 'Childbirth:') + '</b> 2, 5, 11<br>' +
          '• <b>' + T('විදේශ ගමන් / පදිංචිය:', 'Foreign Travel / PR:') + '</b> 3, 9, 12<br>' +
          '• <b>' + T('නඩුහබ ජයග්‍රහණය:', 'Litigation Victory:') + '</b> 6, 11 <small>(' + T('ප්‍රතිවාදියා:', 'Opponent:') + ' 7)</small><br>' +
          '• <b>' + T('සෞඛ්‍ය බාධා:', 'Health Issues:') + '</b> 1, 6, 8, 12 <small>(' + T('සුවය:', 'Recovery:') + ' 1, 5, 11)</small><br>' +
          '• <b>' + T('මැණික් පැළඳීම:', 'KP Gemstones:') + '</b> ' + T('1 හෝ 11 උප-අධිපති 6, 8, 12 ලබා නොදේ නම් පමණි.', 'Strictly 1st or 11th CSL only if free from 6, 8, 12.') +
        '</div></details>' +

        '<details class="adv"><summary>4️⃣ ' + T('KP දෘෂ්ටි (Aspects) සහ Orb සීමා', 'KP Aspects & Strict Orbs') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.7">' +
          T('• <b>සීමාව (Orb):</b> සාමාන්‍ය ග්‍රහයන්ට <b>3°20′</b>; රවිට <b>6°40′</b>.<br>• <b>ප්‍රධාන දෘෂ්ටි:</b> සංයෝග (0°), ෂෂ්ටාංශ (60°), චතුරශ්‍ර (90°), ත්‍රිකෝණ (120°), ප්‍රතිමුඛ (180°).<br>• <b>Applying (ළංවෙන)</b> දෘෂ්ටි Separating (ඈත්වෙන) දෘෂ්ටිවලට වඩා ප්‍රබලයි.<br>• දෘෂ්ටියක් හොඳද නරකද තීරණය වන්නේ දෘෂ්ටි හෙළන ග්‍රහයා සම්බන්ධ කරන භාව (Significators) අනුවයි.',
            '• <b>Strict Orbs:</b> <b>3°20′</b> for all planets; <b>6°40′</b> for Sun.<br>• <b>Major Aspects:</b> Conjunction (0°), Sextile (60°), Square (90°), Trine (120°), Opposition (180°).<br>• <b>Applying</b> aspects are more active than Separating aspects.<br>• Benefic/malefic effect depends on the houses signified by the aspecting planet.') +
        '</div></details>' +

        '<details class="adv"><summary>5️⃣ ' + T('කාල නිර්ණය (පියවර 3: පොරොන්දුව → දශා → ගෝචර & RP)', '3-Step Timing (Promise → DBA → Transit & RP)') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.7">' +
          T('1. <b>ජන්ම පොරොන්දුව:</b> අදාළ භාව උප-අධිපති (CSL) සිදුවීම පොරොන්දු විය යුතුයි.<br>2. <b>දශා-භුක්ති-අන්තර (DBA):</b> මහා, අන්තර් සහ ප්‍රත්‍යන්තර දශා අධිපතීන් එම භාව සම්බන්ධ කරන කාලය තෝරන්න.<br>3. <b>ගෝචර සහ Ruling Planets (RP):</b> ගුරු, ශනි, රවි සහ චන්ද්‍රයා එම සංඥාකාරක ග්‍රහයන්ගේ නැකත්/උප-අධිපති හරහා ගමන් කරන නිශ්චිත දිනයේදී සිදුවීම සිදුවේ.',
            '1. <b>Promise:</b> Confirm the relevant Cusp Sub-Lord promises the event.<br>2. <b>Dasha-Bhukti-Antara (DBA):</b> Find joint running periods of significators.<br>3. <b>Transit & Ruling Planets:</b> Pinpoint the exact date when Jupiter, Saturn, Sun & Moon transit the stars/subs of the joint significators.') +
        '</div></details>';
    };

    /* ==========================================================================
       v27: NATIVE ANDROID A4 PDF EXPORT & PREVIEW MODAL
       ========================================================================== */
    window.kpExportPdf = function (htmlBody, docTitle) {
      var title = docTitle || 'KP-Astrology-Report';
      var safeName = title.replace(/[^A-Za-z0-9_\u0D80-\u0DFF-]+/g, '_').slice(0, 48) || 'KP-Report';
      var fullDoc = '<!DOCTYPE html><html lang="' + (SI ? 'si' : 'en') + '"><head><meta charset="utf-8">' +
        '<meta name="viewport" content="width=device-width,initial-scale=1">' +
        '<title>' + esc(title) + '</title>' +
        '<style>' +
          '@page{size:A4;margin:12mm}' +
          'body{font-family:"Noto Sans Sinhala","Iskoola Pota",system-ui,sans-serif;color:#0f172a;background:#fff;margin:0;padding:14px;line-height:1.5;font-size:13px}' +
          'h2,h3{color:#0369a1;margin:10px 0 6px}table{width:100%;border-collapse:collapse;margin:8px 0;font-size:11.5px}' +
          'th,td{border:1px solid #cbd5e1;padding:5px 6px;text-align:left}th{background:#e0f2fe;font-weight:700}' +
          '.r,.ln{border:1px solid #e2e8f0;border-radius:8px;padding:7px 9px;margin:6px 0;background:#f8fafc}' +
          '.pg{page-break-inside:avoid;margin-bottom:12px}svg{max-width:310px;height:auto;display:block;margin:8px auto;background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px}' +
          '.kct,.kp-qdt,.kp-minia,button{display:none!important}' +
        '</style></head><body>' + htmlBody + '</body></html>';

      function buildPlainReport() {
        var tmp = document.createElement('div');
        tmp.innerHTML = htmlBody;
        $$('button,svg,.kct,.kp-qdt,.kp-minia,script,style', tmp).forEach(function (n) { n.remove(); });
        var lines = [];
        var raw = (tmp.innerText || tmp.textContent || '').split(/\r?\n/);
        for (var i = 0; i < raw.length; i++) {
          var s = raw[i].replace(/\s+/g, ' ').trim();
          if (s) lines.push(s);
        }
        return lines.join('\n').slice(0, 12000);
      }

      function copyStr(txt) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          return navigator.clipboard.writeText(txt).then(function () { return true; }, function () { return fallbackCopy(txt); });
        }
        return Promise.resolve(fallbackCopy(txt));
      }
      function fallbackCopy(txt) {
        try {
          var ta = document.createElement('textarea');
          ta.value = txt;
          ta.setAttribute('readonly', '');
          ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
          document.body.appendChild(ta);
          ta.focus(); ta.select();
          var okc = document.execCommand('copy');
          ta.remove();
          return !!okc;
        } catch (e) { return false; }
      }

      var m = E('kp-pdf-modal');
      if (!m) {
        m = document.createElement('div');
        m.id = 'kp-pdf-modal';
        document.body.appendChild(m);
      }
      var hasNativePrint = !!(window.AndroidPrint && typeof window.AndroidPrint.printHtml === 'function');
      var hasDesktop = !!(window.KPDesktop && typeof window.KPDesktop.savePdf === 'function');
      m.innerHTML =
        '<div class="kpdf-sheet">' +
          '<div class="kpdf-head">' +
            '<span>📄 ' + T('A4 PDF කේන්දර වාර්තාව', 'A4 PDF Chart Report') + '</span>' +
            '<button type="button" class="em-x" id="kpdf-x">✕</button>' +
          '</div>' +
          '<div class="kpdf-acts ' + (hasDesktop ? 'kpdf-acts-4' : 'kpdf-acts-3') + '">' +
            '<button type="button" class="p" id="kpdf-save">📄 ' + T('PDF සුරකින්න', 'Save A4 PDF') + '</button>' +
            (hasDesktop ? '<button type="button" id="kpdf-prn">🖨️ ' + T('Printer ප්‍රින්ට්', 'Print') + '</button>' : '') +
            '<button type="button" class="kpdf-wa" id="kpdf-wa">💬 ' + T('WhatsApp යවන්න', 'WhatsApp') + '</button>' +
            '<button type="button" id="kpdf-cp">📋 ' + T('කොපි', 'Copy') + '</button>' +
          '</div>' +
          '<div class="kpdf-st" id="kpdf-st"></div>' +
          '<div class="kpdf-prev" id="kpdf-prev">' + htmlBody + '</div>' +
          '<div class="kpdf-note">' + (hasDesktop
            ? T('💡 "PDF සුරකින්න" මඟින් A4 PDF ගොනුව පරිගණකයට සුරකින්න, හෝ "Printer ප්‍රින්ට්" මඟින් කෙළින්ම A4 ප්‍රින්ටරයෙන් මුද්‍රණය කරන්න.', '💡 Save crisp A4 PDF directly to your PC or print straight to your office printer.')
            : hasNativePrint
              ? T('💡 "PDF සුරකින්න" එබූ විට Android Save as PDF පිටුව විවෘත වේ. වාර්තාව කෙළින්ම WhatsApp කිරීමට "WhatsApp යවන්න" ඔබන්න.', '💡 Tap "Save A4 PDF" for native Android Save as PDF, or "WhatsApp" to share the report directly.')
              : T('💡 "PDF සුරකින්න" මඟින් A4 PDF සුරකින්න, හෝ "WhatsApp යවන්න" / "කොපි" මඟින් සේවාදායකයාට කෙළින්ම යවන්න.', '💡 Use "Save A4 PDF" to print/save A4 PDF, or "WhatsApp" / "Copy" to send directly.')) +
          '</div>' +
        '</div>';

      function showSt(msg) {
        var st = E('kpdf-st');
        if (!st) return;
        st.textContent = msg;
        st.classList.add('on');
        clearTimeout(st._t);
        st._t = setTimeout(function () { st.classList.remove('on'); }, 3500);
      }

      m.classList.add('on');
      m.onclick = function (e) { if (e.target === m) m.classList.remove('on'); };
      E('kpdf-x').onclick = function () { m.classList.remove('on'); };

      if (E('kpdf-prn')) {
        E('kpdf-prn').onclick = function () {
          if (window.KPDesktop && typeof window.KPDesktop.printHtml === 'function') {
            showSt('🖨️ ' + T('Windows Printer කවුළුව විවෘත වෙමින් පවතී...', 'Opening Windows Print dialog...'));
            window.KPDesktop.printHtml(fullDoc, safeName).catch(function () {});
          }
        };
      }

      E('kpdf-save').onclick = function () {
        if (window.KPDesktop && typeof window.KPDesktop.savePdf === 'function') {
          showSt('📄 ' + T('A4 PDF සුරකින ස්ථානය තෝරන්න...', 'Choose where to save A4 PDF...'));
          window.KPDesktop.savePdf(fullDoc, safeName).then(function (res) {
            if (res && res.saved) showSt('✅ ' + T('A4 PDF සුරැකී විවෘත විය!', 'A4 PDF saved and opened!'));
            else if (res && res.canceled) showSt('ℹ️ ' + T('සුරැකීම අවලංගු කළා.', 'Save canceled.'));
            else showSt('⚠️ ' + T('PDF සුරැකීමේ දෝෂයක්.', 'PDF save error.'));
          }).catch(function () { showSt('⚠️ ' + T('PDF සුරැකීමේ දෝෂයක්.', 'PDF save error.')); });
          return;
        }
        if (window.AndroidPrint && typeof window.AndroidPrint.printHtml === 'function') {
          showSt('📄 ' + T('Android Save as PDF විවෘත වෙමින් පවතී...', 'Opening Android Save as PDF...'));
          try {
            window.AndroidPrint.printHtml(fullDoc, safeName);
            return;
          } catch (e) {}
        }
        var pa = E('pa');
        if (pa) pa.innerHTML = htmlBody;
        m.classList.remove('on');
        document.body.classList.add('pp');
        setTimeout(function () {
          try { window.print(); } catch (e) {}
          document.body.classList.remove('pp');
        }, 120);
      };

      E('kpdf-wa').onclick = function () {
        var txt = buildPlainReport();
        var waTxt = txt.length > 3600 ? (txt.slice(0, 3550) + '\n...\n(KP Astrology AI Pro)') : txt;
        if (window.AndroidPrint && typeof window.AndroidPrint.shareText === 'function') {
          try { window.AndroidPrint.shareText(txt, title); return; } catch (e) {}
        }
        if (navigator.share) {
          navigator.share({ title: title, text: waTxt }).catch(function () {
            window.open('https://wa.me/?text=' + encodeURIComponent(waTxt), '_blank');
          });
          showSt('📤 ' + T('Share කවුළුව විවෘත විය', 'Share opened'));
          return;
        }
        copyStr(txt);
        showSt('💬 ' + T('WhatsApp විවෘත වෙමින් පවතී (සම්පූර්ණ වාර්තාව කොපි ද විය)', 'Opening WhatsApp (full report also copied)'));
        try {
          var a = document.createElement('a');
          a.href = 'https://wa.me/?text=' + encodeURIComponent(waTxt);
          a.target = '_blank';
          a.rel = 'noopener';
          document.body.appendChild(a);
          a.click();
          a.remove();
        } catch (e) {
          location.href = 'https://wa.me/?text=' + encodeURIComponent(waTxt);
        }
      };

      E('kpdf-cp').onclick = function () {
        var txt = buildPlainReport();
        copyStr(txt).then(function (okc) {
          showSt(okc
            ? ('✅ ' + T('සම්පූර්ණ කේන්දර වාර්තාව කොපි විය! WhatsApp හි Paste කරන්න.', 'Full report copied! Paste in WhatsApp or Notes.'))
            : ('⚠️ ' + T('කොපි කිරීමට නොහැකි විය — "WhatsApp යවන්න" ඔබන්න.', 'Could not copy — tap WhatsApp instead.')));
        });
      };
    };

    /* ==========================================================================
       t24: COMPLETE 1–12 HOUSES KP ANALYSIS (ALL 12 CUSPAL SUB-LORDS)
       ========================================================================== */
    var H12_DEFS = [
      { h:1,  si:'1 වන භාවය — ලග්නය, පෞරුෂය, ශරීර ශක්තිය & ආයුෂ', en:'1st House — Self, Personality, Vitality & Longevity', fav:[1,5,9,11], bad:[6,8,12],
        goodSi:'ශක්තිමත් ආත්ම විශ්වාසය, හොඳ ශරීර සෞඛ්‍යය සහ ජීවිතයේ ඉදිරියට යාමේ ප්‍රබල හැකියාවක් ඇත.',
        midSi:'සාමාන්‍ය ශරීර ශක්තියක් ඇත. විටින් විට වෙහෙස හෝ සුළු බාධා ඇති වුවත් ඒවා ජයගත හැකිය.',
        badSi:'ශරීර සෞඛ්‍යය සහ මානසික සන්සුන්කම ගැන වැඩි සැලකිල්ලක් දැක්විය යුතුයි.',
        goodEn:'Strong vitality, self-confidence, and natural drive to succeed.',
        midEn:'Moderate vitality; minor hurdles can be overcome with steady discipline.',
        badEn:'Requires extra care for physical vitality, immunity, and stress management.' },
      { h:2,  si:'2 වන භාවය — ධනය, ඉතිරිකිරීම්, පවුල & කතාව', en:'2nd House — Wealth, Savings, Family & Speech', fav:[2,6,11], bad:[5,8,12],
        goodSi:'ධනය රැස් කිරීමේ හැකියාව, පවුලේ සමගිය සහ ප්‍රියමනාප කතාව මඟින් ආර්ථික ස්ථාවරත්වය ලැබේ.',
        midSi:'ආදායම් ලැබුණත් වියදම් පාලනය කර ගැනීමෙන් ඉතිරිකිරීම් වර්ධනය කරගත හැකිය.',
        badSi:'මුදල් ඉතිරි කිරීමේදී බාධා හෝ අනපේක්ෂිත වියදම් ඇති විය හැකි බැවින් මූල්‍ය සැලසුම් අත්‍යවශ්‍යයි.',
        goodEn:'Strong promise for accumulated wealth, bank balance, and family harmony.',
        midEn:'Steady earnings possible, though savings require mindful budgeting.',
        badEn:'Expenses or fluctuations may challenge savings; careful financial planning advised.' },
      { h:3,  si:'3 වන භාවය — සහෝදර, ධෛර්යය, කෙටි ගමන් & සන්නිවේදනය', en:'3rd House — Siblings, Courage, Short Trips & Communication', fav:[3,9,11], bad:[2,8,12],
        goodSi:'ප්‍රබල ධෛර්යය, සන්නිවේදන/ලේඛන හැකියාව, කෙටි ගමන් සහ ස්වයං උත්සාහයෙන් ජයග්‍රහණ ලැබේ.',
        midSi:'සාමාන්‍ය උත්සාහයෙන් කටයුතු සාර්ථක වේ; සහෝදර/අසල්වැසි සබඳතා මධ්‍යස්ථයි.',
        badSi:'තීරණ ගැනීමේදී පසුබට වීම හෝ සන්නිවේදන ගැටළු ඇති විය හැකි නිසා පැහැදිලිව කටයුතු කරන්න.',
        goodEn:'High courage, strong communication skills, and success through self-effort.',
        midEn:'Moderate results in short travels, writing, and sibling relations.',
        badEn:'Avoid hesitation or misunderstandings in agreements and communication.' },
      { h:4,  si:'4 වන භාවය — මව, නිවාස, ඉඩම්, වාහන & මූලික අධ්‍යාපනය', en:'4th House — Mother, Home, Property, Vehicles & Education', fav:[4,11,12], bad:[3,8,10],
        goodSi:'නිවාස, ඉඩකඩම්, වාහන හිමිකාරිත්වය, මවගේ ආශිර්වාදය සහ ගෘහ සැපපහසුව හොඳින් හිමිවේ.',
        midSi:'දේපළ සහ වාහන ලැබීමට ඉඩ ඇතත් යම් ප්‍රමාදයක් හෝ උත්සාහයක් අවශ්‍ය වේ.',
        badSi:'නිවාස/ඉඩම් ගනුදෙනුවලදී ලියකියවිලි පරීක්ෂා කිරීම සහ ඉවසීමෙන් කටයුතු කිරීම වැදගත්.',
        goodEn:'Strong promise for owning property, vehicles, domestic comfort, and foundational education.',
        midEn:'Property and comforts come with steady effort or slight delay.',
        badEn:'Exercise caution with real-estate paperwork and domestic peace.' },
      { h:5,  si:'5 වන භාවය — දරුඵල, ආදරය, බුද්ධිය & ආයෝජන වාසනාව', en:'5th House — Children, Romance, Intelligence & Speculation', fav:[2,5,11], bad:[1,4,10],
        goodSi:'තියුණු බුද්ධිය, නිර්මාණශීලීත්වය, දරුඵල සතුට සහ සාර්ථක ආදර/ආයෝජන අවස්ථා පොරොන්දු වේ.',
        midSi:'ආදර සබඳතා සහ ආයෝජනවලදී මධ්‍යස්ථ ප්‍රතිඵල ලැබේ; ඉවසීමෙන් තීරණ ගන්න.',
        badSi:'අවදානම් ආයෝජනවලින් වළකින්න; දරුඵල හෝ ආදර කටයුතුවලදී ප්‍රමාද ඇති විය හැකිය.',
        goodEn:'Sharp intellect, creative talent, joy from children, and favorable romance/investments.',
        midEn:'Moderate promise in romance and speculation; avoid impulsive risks.',
        badEn:'Avoid high-risk speculation; patience needed in romance or childbirth matters.' },
      { h:6,  si:'6 වන භාවය — සේවය, තරඟ ජය, ණය & රෝග ස්වභාවය', en:'6th House — Service, Competition, Debts & Disease', fav:[6,10,11], bad:[5,8,12],
        goodSi:'රැකියාවේ දියුණුව, තරඟ/විභාග ජයග්‍රහණය සහ සතුරන් අභිබවා යාමේ ශක්තිය ප්‍රබලයි.',
        midSi:'සේවා කටයුතු සාමාන්‍ය ලෙස ඉදිරියට යයි; ණය සහ සෞඛ්‍යය සමබරව පවත්වා ගන්න.',
        badSi:'ණය ගනුදෙනු, නීතිමය ආරවුල් සහ රෝග තත්ත්වයන් ගැන අවධානයෙන් සිටින්න (🩺 KP ලෙඩරෝග බලන්න).',
        goodEn:'Strong ability to win competitions, excel in service/jobs, and overcome rivals.',
        midEn:'Balanced service life; keep debts and health routines under control.',
        badEn:'Watch out for debts, disputes, or health strain (see Medical KP tab).' },
      { h:7,  si:'7 වන භාවය — විවාහය, සහකරු & හවුල් ව්‍යාපාර', en:'7th House — Marriage, Spouse & Business Partnerships', fav:[2,7,11], bad:[1,6,10],
        goodSi:'සාර්ථක විවාහ ජීවිතයක්, ගැළපෙන සහකරුවෙකු සහ ලාභදායී හවුල් ව්‍යාපාර පොරොන්දු වේ.',
        midSi:'විවාහය හෝ සබඳතාව ඉටුවේ, නමුත් යම් ප්‍රමාදයක් හෝ අන්‍යෝන්‍ය අවබෝධය වැඩි කරගැනීම අවශ්‍ය වේ.',
        badSi:'විවාහ තීරණ සහ හවුල් ව්‍යාපාරවලදී ඉක්මන් නොවී පොරොන්දම්/KP ගැළපීම හොඳින් පරීක්ෂා කරන්න.',
        goodEn:'Strong promise for a harmonious marriage, supportive spouse, and profitable partnerships.',
        midEn:'Marriage is promised with some delay or need for mutual patience.',
        badEn:'Take care before finalizing marriage or business partnerships.' },
      { h:8,  si:'8 වන භාවය — ආයුෂ, උරුම, පර්යේෂණ & අනපේක්ෂිත සිදුවීම්', en:'8th House — Longevity, Inheritance, Research & Sudden Events', fav:[2,8,11], bad:[6,8,12],
        goodSi:'ගැඹුරු පර්යේෂණ, ගුප්ත/ජ්‍යොතිෂ ඥානය, රක්ෂණ හෝ අනපේක්ෂිත ලාභ සඳහා සුවිශේෂී හැකියාවක් ඇත.',
        midSi:'ජීවිතයේ විටින් විට වෙනස්කම් සිදු වුවත් ඒවායින් නව අත්දැකීම් ලැබේ.',
        badSi:'අනපේක්ෂිත බාධා, අනතුරු හෝ හදිසි ගැටළු වළක්වා ගැනීමට ප්‍රවේශම් වන්න.',
        goodEn:'Talent for deep research, occult/astrology, insurance, or unexpected gains.',
        midEn:'Periodic transformations bring growth; stay adaptable.',
        badEn:'Be cautious against sudden obstacles, accidents, or unexpected delays.' },
      { h:9,  si:'9 වන භාවය — භාග්‍යය, පියා, උසස් අධ්‍යාපනය & ධර්මය', en:'9th House — Fortune, Father, Higher Education & Spirituality', fav:[4,9,11], bad:[8,12],
        goodSi:'පෙර පින් භාග්‍යය, උසස් අධ්‍යාපනය, දුර ගමන්, ගුරු/පියාගේ ආශිර්වාදය සහ ධාර්මික දියුණුව හිමිවේ.',
        midSi:'උසස් අධ්‍යාපනය සහ භාග්‍යය මධ්‍යස්ථ මට්ටමින් ලැබේ; කැපවීමෙන් ඉහළට යා හැකිය.',
        badSi:'උසස් අධ්‍යාපන හෝ දුර ගමන් සැලසුම්වලදී අමතර සූදානමක් සහ ඉවසීමක් අවශ්‍ය වේ.',
        goodEn:'Strong fortune, higher studies, long-distance travel, mentors, and spiritual growth.',
        midEn:'Steady progress in higher education and spiritual pursuits.',
        badEn:'Extra preparation needed for higher education, visas, or long journeys.' },
      { h:10, si:'10 වන භාවය — රැකියාව, වෘත්තිය, කීර්තිය & සමාජ තත්ත්වය', en:'10th House — Career, Profession, Fame & Status', fav:[2,6,10,11], bad:[5,8,12],
        goodSi:'වෘත්තීය දියුණුව, උසස්වීම්, සමාජ පිළිගැනීම සහ ස්ථාවර රැකියා/ව්‍යාපාර සාර්ථකත්වය පොරොන්දු වේ.',
        midSi:'වෘත්තීය ජීවිතය සාර්ථක වුවත් විටින් විට වෙනස්කම් හෝ වැඩි වගකීම් පැවරිය හැකිය.',
        badSi:'රැකියාවේ ස්ථාවරත්වය රැකගැනීමට ඉවසීමෙන් සහ උපායශීලීව කටයුතු කරන්න.',
        goodEn:'Strong career rise, authority, social recognition, and professional fulfillment.',
        midEn:'Good career path with occasional changes or extra responsibilities.',
        badEn:'Avoid abrupt career shifts; build stability step by step.' },
      { h:11, si:'11 වන භාවය — ලාභ, ආදායම්, බලාපොරොත්තු ඉටුවීම & මිතුරන්', en:'11th House — Gains, Income, Fulfillment of Desires & Friends', fav:[2,6,10,11], bad:[6,8,12],
        goodSi:'ජීවිතයේ ප්‍රධාන බලාපොරොත්තු ඉටුවීම, බහු ආදායම් මාර්ග සහ හිතවත් මිතුරන්ගේ සහයෝගය ප්‍රබලව ලැබේ.',
        midSi:'උත්සාහයට සරිලන ලාභ සහ ආදායම් ක්‍රමයෙන් ලැබේ.',
        badSi:'මිතුරන් තෝරාගැනීමේදී සැලකිලිමත් වන්න; බලාපොරොත්තු ඉටුවීමට යම් කාලයක් ගතවේ.',
        goodEn:'Excellent fulfillment of desires, steady gains, and supportive social network.',
        midEn:'Gains arrive steadily through consistent work.',
        badEn:'Be selective with social circles; major wishes need patience.' },
      { h:12, si:'12 වන භාවය — විදේශ පදිංචිය, ආයෝජන, වියදම් & මෝක්ෂය', en:'12th House — Foreign Settlement, Investments, Expenses & Liberation', fav:[3,9,12], bad:[6,8,12],
        goodSi:'විදේශ ගමන්, විදේශ රැකියා/පදිංචිය, ආයෝජන සහ අධ්‍යාත්මික දියුණුව සඳහා ඉතා සුබ පොරොන්දුවකි.',
        midSi:'විදේශ සබඳතා සහ ආයෝජනවලට මධ්‍යස්ථ ඉඩකඩක් ඇත; වියදම් පාලනය කරගන්න.',
        badSi:'අනවශ්‍ය වියදම්, නින්දට බාධා හෝ රෝහල් වියදම් අවම කරගැනීමට සැලකිලිමත් වන්න.',
        goodEn:'Strong promise for foreign travel, settlement abroad, smart investments, and spiritual peace.',
        midEn:'Moderate foreign connections; keep expenses balanced.',
        badEn:'Guard against unnecessary expenses, sleep disturbance, or hidden losses.' }
    ];

    window.kp12HousesTab = function () {
      var el = E('t24');
      if (!el || !c) return;
      var K = ok(kpw); if (!K) return;
      var W = K.W;

      var cards = H12_DEFS.map(function (df, idx) {
        var csLon = c.cs[idx], sg = Math.floor(csLon / 30);
        var cl = lords(csLon), cslCode = P[cl.sl], cslName = plLbl(cslCode);
        var cslCh = lords(c.pl[cslCode]);
        var nlName = plLbl(P[cslCh.nl]), sl2Name = plLbl(P[cslCh.sl]);
        var w = W[cslCode] || {};
        var hitFav = df.fav.filter(function (x) { return w[x]; });
        var stFav = df.fav.filter(function (x) { return w[x] >= 3; });
        var hitBad = df.bad.filter(function (x) { return w[x] >= 3; });
        var lv = (hitFav.length >= 2 && stFav.length) ? 0 : (hitFav.length >= 1 ? 1 : 2);
        var badge = lv === 0 ? T('✅ ප්‍රබලයි', '✅ Strong') : (lv === 1 ? T('🔸 මධ්‍යමයි', '🔸 Moderate') : T('🟠 සැලකිලිමත්', '🟠 Caution'));
        var desc = lv === 0 ? (SI ? df.goodSi : df.goodEn) : (lv === 1 ? (SI ? df.midSi : df.midEn) : (SI ? df.badSi : df.badEn));
        var sigAll = [];
        Object.keys(w).forEach(function (k) { if (w[k] > 0) sigAll.push(+k); });
        sigAll.sort(function (a, b) { return a - b; });

        return '<details class="adv"' + (idx < 3 ? ' open' : '') + '>' +
          '<summary>' + (SI ? df.si : df.en) + ' <span class="kp-tag-s">' + badge + '</span></summary>' +
          '<div style="padding:8px 10px;font-size:12.5px;line-height:1.7">' +
            '<div style="margin-bottom:5px;color:var(--mu)">' +
              '<b>' + SGN[sg] + ' ' + dms(csLon % 30) + '</b> · ' +
              T('උප-අධිපති (CSL): ', 'Cusp Sub-Lord: ') + '<span class="pc pc-' + cslCode + '">' + cslCode + '</span> <b>' + cslName + '</b> ' +
              '<small>(' + nlName + ' / ' + sl2Name + ')</small>' +
            '</div>' +
            '<div style="margin-bottom:6px">' + desc + '</div>' +
            '<small style="color:var(--mu)">' + T('CSL සම්බන්ධ කරන භාව: ', 'CSL Signifies Houses: ') + '<b>' + (sigAll.join(', ') || '—') + '</b>' +
              (hitBad.length ? ' · ⚠️ ' + T('බාධක: ', 'Opposing: ') + hitBad.join(', ') : '') +
            '</small>' +
          '</div>' +
        '</details>';
      }).join('');

      el.innerHTML =
        '<h3>🏠 ' + T('1 සිට 12 දක්වා සම්පූර්ණ KP භාව විශ්ලේෂණය', 'Complete 1–12 Houses KP Analysis') + '</h3>' +
        '<div class="sub">' + T('ක්‍රිෂ්ණමූර්ති පද්ධතිය (KP) අනුව සෑම භාවයකම උප-අධිපති (Cusp Sub-Lord), නැකත්-උප දාමය සහ සම්බන්ධිත භාව පරීක්ෂා කර සැකසූ සම්පූර්ණ විග්‍රහය.', 'Authentic Krishnamurti Paddhati (KP) analysis of all 12 House Cuspal Sub-Lords (CSL), Star/Sub chains, and signified house promises.') + '</div>' +
        cards;
    };

    /* ==========================================================================
       t25: KP MEDICAL ASTROLOGY (DISEASES, BODY PARTS, IMMUNITY & RECOVERY)
       ========================================================================== */
    var KP_MED_PL = {
      Su: { si:'හෘදය, ඇස්, හිස, රුධිර පීඩනය, උෂ්ණ රෝග, කොඳු ඇට පෙළ', en:'Heart, eyes, head, blood pressure, fever/vitality, spine' },
      Mo: { si:'මනස, නින්ද, පපුව, ආමාශය, ශරීර දියර, සෙම/පීනස', en:'Mind, sleep, chest, stomach, body fluids, cold/sinus' },
      Ma: { si:'රුධිරය, ශල්‍යකර්ම, තුවාල/අනතුරු, අධික රුධිර පීඩනය, මාංශ පේශි', en:'Blood, surgery, injuries/accidents, inflammation, muscles' },
      Me: { si:'ස්නායු පද්ධතිය, සමේ රෝග, පෙනහළු/හුස්ම ගැනීම, උගුර, මානසික ආතතිය', en:'Nervous system, skin, lungs/respiration, throat, anxiety' },
      Ju: { si:'අක්මාව (Liver), දියවැඩියාව/සීනි, කොලෙස්ටරෝල්, තරබාරුකම, කන්', en:'Liver, diabetes/sugar, cholesterol, obesity, ears' },
      Ve: { si:'වකුගඩු (Kidneys), මුත්‍රා පද්ධතිය, ප්‍රජනක/හෝමෝන, උගුර, ඇස්', en:'Kidneys, urinary tract, reproductive/hormones, throat, eyes' },
      Sa: { si:'අස්ථි, දණහිස්/සන්ධි, දත්, වාත රෝග, දිගුකාලීන (Chronic) රෝග', en:'Bones, knees/joints, teeth, arthritis, chronic ailments' },
      Ra: { si:'අසාත්මිකතා (Allergies), වෛරස්, හඳුනාගැනීමට අපහසු රෝග, විෂ/ආහාර විෂවීම්', en:'Allergies, viral/hidden infections, hard-to-diagnose issues, toxins' },
      Ke: { si:'හදිසි ආසාදන, ස්නායු/වේදනා, අබිරහස් රෝග, කුඩා ශල්‍යකර්ම', en:'Sudden infections, nerve pain, mysterious ailments, minor surgery' }
    };
    var KP_MED_SIGN = [
      { si:'හිස, මොළය, ඇස්', en:'Head, brain, eyes' },
      { si:'උගුර, බෙල්ල, තයිරොයිඩ්', en:'Throat, neck, thyroid' },
      { si:'පෙනහළු, උරහිස්, අත්, ස්නායු', en:'Lungs, shoulders, arms, nerves' },
      { si:'පපුව, ආමාශය, ආහාර ජීර්ණය', en:'Chest, stomach, digestion' },
      { si:'හෘදය, කොඳු ඇට පෙළ, පිට', en:'Heart, spine, upper back' },
      { si:'බඩවැල්, ආහාර ජීර්ණ පද්ධතිය', en:'Intestines, digestive tract' },
      { si:'වකුගඩු, කොන්දේ පහළ කොටස', en:'Kidneys, lower back' },
      { si:'මුත්‍රා/ප්‍රජනක පද්ධතිය, ගුද මාර්ගය', en:'Urinary/reproductive system, pelvis' },
      { si:'කලවා, අක්මාව, රුධිර නාල', en:'Thighs, liver, arteries' },
      { si:'දණහිස්, සන්ධි, අස්ථි, සම', en:'Knees, joints, bones, skin' },
      { si:'වළලුකර, රුධිර සංසරණය', en:'Ankles, blood circulation' },
      { si:'පාද, වසා පද්ධතිය, නින්ද', en:'Feet, lymphatic system, sleep' }
    ];

    window.kpMedicalTab = function () {
      var el = E('t25');
      if (!el || !c) return;
      var K = ok(kpw); if (!K) return;
      var W = K.W;

      // 1. 6th Cusp Sub-Lord (Disease) & 1st Cusp Sub-Lord (Immunity/Vitality)
      var c6 = lords(c.cs[5]), p6 = P[c6.sl], w6 = W[p6] || {};
      var c1 = lords(c.cs[0]), p1 = P[c1.sl], w1 = W[p1] || {};
      var bad6 = [6, 8, 12].filter(function (h) { return w6[h]; });
      var cure6 = [5, 11].filter(function (h) { return w6[h]; });
      var vit1 = [1, 5, 11].filter(function (h) { return w1[h]; });
      var bad1 = [6, 8, 12].filter(function (h) { return w1[h]; });

      var riskLvl = (bad6.length >= 2 || (bad6.length >= 1 && bad1.length >= 1 && !cure6.length)) ? 2 : (bad6.length === 1 ? 1 : 0);

      // 2. Identify Top Disease-Signifying Planets (signifying 6, 8, or 12 strongly)
      var disPl = ASP_PL.map(function (pl) {
        var wp = W[pl] || {};
        var sc = (wp[6] || 0) * 1.3 + (wp[8] || 0) * 1.4 + (wp[12] || 0) * 1.2;
        var hs = [1, 6, 8, 12].filter(function (h) { return wp[h]; });
        var sg = Math.floor(c.pl[pl] / 30);
        return { pl: pl, sc: sc, hs: hs, sg: sg, chronic: !!(wp[8] && wp[6]), hosp: !!wp[12] };
      }).filter(function (x) { return x.sc >= 3; }).sort(function (a, b) { return b.sc - a.sc; }).slice(0, 4);

      // 3. Current Dasha Health Check & Upcoming Caution / Recovery Windows (next 5 years)
      var now = kNow(), dl = dashL(now) || [];
      var curRisk = dl.filter(function (p) { var wp = W[p] || {}; return wp[6] || wp[8] || wp[12]; });
      var curCure = dl.filter(function (p) { var wp = W[p] || {}; return wp[1] || wp[5] || wp[11]; });

      var setBad = new Set(ASP_PL.filter(function (p) { var wp = W[p] || {}; return (wp[6] || 0) + (wp[8] || 0) + (wp[12] || 0) >= 4; }));
      var setGood = new Set(ASP_PL.filter(function (p) { var wp = W[p] || {}; return (wp[1] || 0) + (wp[5] || 0) + (wp[11] || 0) >= 4; }));
      var badWins = ok(function () { return kdWin(setBad, now, now + 5 * 365.25, 4); }) || [];
      var goodWins = ok(function () { return kdWin(setGood, now, now + 5 * 365.25, 4); }) || [];

      el.innerHTML =
        '<h3>🩺 ' + T('KP වෛද්‍ය ජ්‍යොතිෂය (ලෙඩරෝග විශ්ලේෂණය)', 'KP Medical Astrology (Health & Disease Analysis)') + '</h3>' +
        '<div class="sub">' + T('ක්‍රිෂ්ණමූර්ති පද්ධතියේ 1 වන භාව උප-අධිපති (ප්‍රතිශක්තිය) සහ 6 වන භාව උප-අධිපති (රෝග ස්වභාවය) අනුව 6, 8, 12 සහ 5, 11 භාව සම්බන්ධතා විග්‍රහය.', 'Authentic KP Medical analysis using the 1st Cusp Sub-Lord (vitality) and 6th Cusp Sub-Lord (disease vs 5/11 recovery).') + '</div>' +

        '<div class="kp-narr">' +
          '<div class="kp-narr-hd"><span>📋 ' + T('1️⃣ සමස්ත සෞඛ්‍ය සහ රෝග තත්ත්වය', '1️⃣ Overall Health & Disease Verdict') + '</span></div>' +
          '<p>' +
            (riskLvl === 0
              ? T('✅ <b>ප්‍රබල ප්‍රතිශක්තියක් ඇත:</b> 6 වන භාව උප-අධිපති <b>' + plLbl(p6) + '</b> රෝග භාව (6, 8, 12) ප්‍රබලව සම්බන්ධ නොකරන බැවින් දරුණු රෝගාබාධ සඳහා අවදානම අඩුයි. සුළු අසනීප ඇති වුවත් ඉක්මනින් සුවය ලැබේ.',
                  '✅ <b>Strong Immunity:</b> Your 6th Cusp Sub-Lord <b>' + plLbl(p6) + '</b> does not strongly trigger 6, 8, 12, indicating low chronic disease risk and quick recovery.')
              : riskLvl === 1
                ? T('🔸 <b>මධ්‍යස්ථ සෞඛ්‍ය අවදානම:</b> 6 වන භාව උප-අධිපති <b>' + plLbl(p6) + '</b> (' + bad6.join(', ') + ') භාව සම්බන්ධ කරයි' + (cure6.length ? ', නමුත් සුවය දෙන ' + cure6.join(', ') + ' භාවද සම්බන්ධ බැවින් නිසි ප්‍රතිකාරවලින් සුවය ලැබේ.' : '. රෝග දශා කාලවලදී ආහාර සහ විවේකය ගැන සැලකිලිමත් වන්න.'),
                    '🔸 <b>Moderate Sensitivity:</b> 6th CSL <b>' + plLbl(p6) + '</b> links to house(s) ' + bad6.join(', ') + (cure6.length ? ', balanced by recovery house(s) ' + cure6.join(', ') + '.' : '. Stay proactive during sensitive dasha periods.'))
                : T('⚠️ <b>සෞඛ්‍යය ගැන වැඩි සැලකිල්ලක් අවශ්‍යයි:</b> 6 වන භාව උප-අධිපති <b>' + plLbl(p6) + '</b> රෝග/බාධක භාව (' + bad6.join(', ') + ') ප්‍රබලව සම්බන්ධ කරයි. 8 වන භාවය දිගුකාලීන/ශල්‍ය තත්ත්වද, 12 වන භාවය රෝහල්ගත වීම්/වියදම්ද පෙන්වන බැවින් කල්තියා වෛද්‍ය පරීක්ෂණ කරගැනීම ඉතා වැදගත්.',
                    '⚠️ <b>Proactive Health Care Advised:</b> 6th CSL <b>' + plLbl(p6) + '</b> strongly activates ' + bad6.join(', ') + ' (6=acute, 8=chronic/surgical, 12=hospitalization). Regular checkups are recommended.')) +
          '</p>' +
          '<p><small>' +
            T('• 1 වන භාව උප-අධිපති (ශරීර ශක්තිය): ', '• 1st CSL (Vitality): ') + '<b>' + plLbl(p1) + '</b> · ' + T('සුව භාව (1,5,11): ', 'Vitality (1,5,11): ') + (vit1.join(', ') || '—') + (bad1.length ? ' · ⚠️ ' + bad1.join(', ') : '') + '<br>' +
            T('• දැන් දශාව: ', '• Current Dasha: ') + '<b>' + (dl.map(plLbl).join(' → ') || '—') + '</b> (' +
            (curRisk.length >= 2 ? T('⚠️ සෞඛ්‍යය ගැන සැලකිලිමත් වන්න', '⚠️ Caution Period') : (curCure.length >= 2 ? T('💚 සුව/ශක්තිමත් කාලයක්', '💚 Strong Recovery Period') : T('🔸 සාමාන්‍ය කාලයක්', '🔸 Balanced Period'))) + ')' +
          '</small></p>' +
        '</div>' +

        '<div class="kb-subhd">🎯 ' + T('2️⃣ අවධානය යොමු කළ යුතු ශරීර අංග සහ රෝග ස්වභාව (6, 8, 12 ප්‍රබල ග්‍රහයන්)', '2️⃣ Sensitive Body Parts & Tendencies (Strong 6, 8, 12 Significators)') + '</div>' +
        (disPl.length
          ? disPl.map(function (x) {
              var mp = KP_MED_PL[x.pl], ms = KP_MED_SIGN[x.sg];
              return '<div class="r">' +
                '<div class="kp-drow"><span><span class="pc pc-' + x.pl + '">' + x.pl + '</span> <b>' + plLbl(x.pl) + '</b> (' + SGN[x.sg] + ')</span><span class="kp-tag-s">' + T('භාව: ', 'H: ') + x.hs.join(', ') + '</span></div>' +
                '<div style="font-size:12px;margin-top:4px;line-height:1.6">' +
                  '• <b>' + T('ග්‍රහ රෝග ස්වභාවය:', 'Planet Tendency:') + '</b> ' + (SI ? mp.si : mp.en) + '<br>' +
                  '• <b>' + T('රාශි ශරීර අංග:', 'Sign Body Area:') + '</b> ' + (SI ? ms.si : ms.en) +
                  (x.chronic ? '<br><small style="color:var(--warn)">⚠️ ' + T('6 සහ 8 සම්බන්ධ බැවින් නොසලකා හැරියහොත් දිගුකාලීන විය හැක.', '6 + 8 link: treat early to prevent chronicity.') + '</small>' : '') +
                  (x.hosp ? '<br><small style="color:var(--hn)">🏥 ' + T('12 සම්බන්ධ බැවින් රෝහල් ප්‍රතිකාර / විවේකය අවශ්‍ය විය හැක.', '12 link: rest or hospital care may be needed during its dasha.') + '</small>' : '') +
                '</div>' +
              '</div>';
            }).join('')
          : '<div class="r">' + T('✅ 6, 8, 12 භාව ඉතා ප්‍රබලව පීඩා කරන විශේෂ රෝග ග්‍රහයෙකු නොපෙනේ.', '✅ No planet severely afflicts 6, 8, and 12 simultaneously.') + '</div>') +

        '<div class="kb-subhd">⏳ ' + T('3️⃣ ඉදිරි අවුරුදු 5 — සැලකිලිමත් කාල & සුවවන කාල', '3️⃣ Next 5 Years — Caution & Recovery Windows') + '</div>' +
        '<div class="r"><b>⚠️ ' + T('සෞඛ්‍යය ගැන සැලකිලිමත් විය යුතු කාල (6, 8, 12)', 'Health Caution Windows (6, 8, 12)') + '</b>' +
          (badWins.length ? badWins.map(function (o) { return '<div style="margin-top:4px;font-size:12px">• <b>' + dt(o.s) + ' → ' + dt(o.e) + '</b> (' + FULL[o.m] + ' – ' + FULL[o.a] + ')</div>'; }).join('') : '<div class="sub" style="margin:4px 0 0">' + T('ඉදිරි වසර 5 තුළ දැඩි අවදානම් දශා කාලයක් නොපෙනේ.', 'No severe joint caution dasha in the next 5 years.') + '</div>') +
        '</div>' +
        '<div class="r"><b>💚 ' + T('සුවය සහ ශක්තිය ලැබෙන කාල (1, 5, 11)', 'Recovery & Vitality Windows (1, 5, 11)') + '</b>' +
          (goodWins.length ? goodWins.map(function (o) { return '<div style="margin-top:4px;font-size:12px">• <b>' + dt(o.s) + ' → ' + dt(o.e) + '</b> (' + FULL[o.m] + ' – ' + FULL[o.a] + ')</div>'; }).join('') : '<div class="sub" style="margin:4px 0 0">' + T('සාමාන්‍ය සුවදායී කාල පවතී.', 'Steady general health periods.') + '</div>') +
        '</div>' +
        '<div class="sub">⚕️ ' + T('සටහන: මෙය ක්‍රිෂ්ණමූර්ති පද්ධති ජ්‍යොතිෂ විශ්ලේෂණයක් පමණි — වෛද්‍ය උපදෙසක් නොවේ. සෞඛ්‍ය ගැටලුවක් ඇත්නම් සුදුසුකම් ලත් වෛද්‍යවරයෙකු හමුවන්න.', 'Note: This is a KP astrological analysis, not medical advice. Always consult a qualified doctor for health concerns.') + '</div>';
    };

    /* ==========================================================================
       t26: SPIRITUAL REMEDIES, OFFLINE SOUND STUDIO & SATIPATTHANA MEDITATION
       ========================================================================== */
    var SP_FREQS = [
      { hz: 136.1, tag: 'OM',     si: 'ඕම් නාදය (OM)',     en: 'OM Tone (Earth Year)',  sSi: 'ගැඹුරු භාවනාව & ප්‍රාණ ශක්තිය',   sEn: 'Deep meditation & Prana balance',    col: '#38bdf8' },
      { hz: 174,   tag: 'Heal',   si: 'වේදනා සමනය',       en: 'Pain & Stress Relief',  sSi: 'ශාරීරික ආතතිය & වේදනා අඩු කරයි', sEn: 'Eases physical tension & discomfort', col: '#2dd4bf' },
      { hz: 285,   tag: 'Vital',  si: 'ශක්ති ප්‍රකෘතිමත්', en: 'Vitality & Renewal',    sSi: 'වෙහෙස & ශරීර ප්‍රකෘතිමත් බව',    sEn: 'Restores energy & cellular renewal',  col: '#34d399' },
      { hz: 396,   tag: 'Root',   si: 'මූලාධාර චක්‍රය',    en: 'Root Chakra (396 Hz)',  sSi: 'බිය, ණය & අපල බාධා දුරලයි',      sEn: 'Releases fear, guilt & obstacles',    col: '#f87171' },
      { hz: 417,   tag: 'Sacral', si: 'ස්වාධිෂ්ඨාන',      en: 'Sacral Chakra (417 Hz)',sSi: 'ඍණාත්මක බව & කර්ම බාධා මකයි',    sEn: 'Clears negative blocks & stagnation', col: '#fb923c' },
      { hz: 432,   tag: 'Earth',  si: 'ස්වභාවික රිද්මය',  en: 'Natural Rhythm (432 Hz)',sSi: 'සන්සුන් මනස & සමබරතාව',         sEn: 'Calms mind & harmonizes emotions',    col: '#4ade80' },
      { hz: 528,   tag: 'Solar',  si: 'මණිපූර චක්‍රය',     en: 'Solar Plexus (528 Hz)', sSi: 'ධනය, ජවය & ආත්ම ශක්තිය',         sEn: 'Abundance, vitality & inner power',   col: '#facc15' },
      { hz: 639,   tag: '★ Best', si: 'හෘද (අනාහත)',       en: 'Heart Anahata (639 Hz)',sSi: 'විවාහය, මෛත්‍රිය & Coherence',   sEn: 'Marriage, loving-kindness & harmony', col: '#10b981' },
      { hz: 741,   tag: 'Throat', si: 'විශුද්ධි චක්‍රය',   en: 'Throat Chakra (741 Hz)',sSi: 'වෘත්තිය & පැහැදිලි බුද්ධිය',      sEn: 'Career clarity & problem solving',    col: '#60a5fa' },
      { hz: 852,   tag: '3rdEye', si: 'ආඥා (තෙවන ඇස)',     en: 'Third Eye (852 Hz)',    sSi: 'අන්තර්ඥානය & සිහිනුවණ',          sEn: 'Intuition & spiritual awakening',     col: '#818cf8' },
      { hz: 963,   tag: 'Crown',  si: 'සහස්‍රාර (කිරීට)',  en: 'Crown Chakra (963 Hz)', sSi: 'පරම ශාන්තිය & ඒකත්වය',           sEn: 'Supreme peace & pure stillness',      col: '#c084fc' }
    ];

    var SP_BIN = [
      { hz: 0,  si: 'Off',               en: 'Off' },
      { hz: 2,  si: '🌙 Delta 2Hz (ගැඹුරු විවේකය)', en: '🌙 Delta 2Hz (Deep Rest)' },
      { hz: 6,  si: '🧘 Theta 6Hz (භාවනාව)',  en: '🧘 Theta 6Hz (Meditation)' },
      { hz: 10, si: '✨ Alpha 10Hz (සන්සුන්)', en: '✨ Alpha 10Hz (Calm)' },
      { hz: 18, si: '⚡ Beta 18Hz (අවධානය)',   en: '⚡ Beta 18Hz (Focus)' },
      { hz: 40, si: '💎 Gamma 40Hz (ප්‍රඥාව)', en: '💎 Gamma 40Hz (Insight)' }
    ];

    var SP_NAT = [
      { id: 'off',   si: 'Off',                en: 'Off' },
      { id: 'rain',  si: '🌧️ වැස්ස (Rain)',   en: '🌧️ Rain' },
      { id: 'ocean', si: '🌊 මුහුදු රළ (Ocean)', en: '🌊 Ocean' },
      { id: 'wind',  si: '🍃 සුළඟ (Wind)',    en: '🍃 Wind' },
      { id: 'brown', si: '🟤 Brown Noise',     en: '🟤 Brown Noise' }
    ];

    // 100% Offline Web Audio Sound Studio Engine
    var KPS = {
      ctx: null, master: null, vol: 0.45,
      solOsc: null, solGain: null, solHz: 0,
      binL: null, binR: null, binGain: null, binHz: 0,
      natSrc: null, natGain: null, natLfo: null, natId: 'off',
      sleepEnd: 0, sleepIv: null,
      medRem: 0, medTotal: 600, medIv: null, medRun: false,
      brIv: null, brRun: false, brMode: 'coh', brStep: 0, brPhaseEnd: 0, brCycles: 0
    };

    function kpsEnsureCtx() {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      if (!KPS.ctx) {
        KPS.ctx = new AC();
        KPS.master = KPS.ctx.createGain();
        KPS.master.gain.value = KPS.vol;
        KPS.master.connect(KPS.ctx.destination);
      }
      if (KPS.ctx.state === 'suspended') {
        try { KPS.ctx.resume(); } catch (e) {}
      }
      return KPS.ctx;
    }

    function kpsSetVol(v) {
      KPS.vol = Math.max(0, Math.min(1, +v));
      if (KPS.master && KPS.ctx) {
        try { KPS.master.gain.setTargetAtTime(KPS.vol, KPS.ctx.currentTime, 0.05); } catch (e) { KPS.master.gain.value = KPS.vol; }
      }
    }

    function kpsStopSol() {
      if (KPS.solOsc) {
        try { KPS.solOsc.stop(); KPS.solOsc.disconnect(); } catch (e) {}
        KPS.solOsc = null;
      }
      if (KPS.solGain) { try { KPS.solGain.disconnect(); } catch (e) {} KPS.solGain = null; }
      KPS.solHz = 0;
    }

    function kpsPlaySol(hz) {
      if (KPS.solHz === hz) { kpsStopSol(); return; }
      kpsStopSol();
      var ctx = kpsEnsureCtx(); if (!ctx) return;
      var osc = ctx.createOscillator();
      var g = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = hz;
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.28, ctx.currentTime + 0.35);
      osc.connect(g); g.connect(KPS.master);
      osc.start();
      KPS.solOsc = osc; KPS.solGain = g; KPS.solHz = hz;
    }

    function kpsStopBin() {
      ['binL', 'binR', 'binGain'].forEach(function (k) {
        if (KPS[k]) {
          try { if (KPS[k].stop) KPS[k].stop(); KPS[k].disconnect(); } catch (e) {}
          KPS[k] = null;
        }
      });
      KPS.binHz = 0;
    }

    function kpsPlayBin(beatHz) {
      kpsStopBin();
      if (!beatHz) return;
      var ctx = kpsEnsureCtx(); if (!ctx) return;
      var base = 200;
      var oL = ctx.createOscillator(), oR = ctx.createOscillator();
      var g = ctx.createGain();
      oL.type = 'sine'; oR.type = 'sine';
      oL.frequency.value = base;
      oR.frequency.value = base + beatHz;
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + 0.35);
      if (ctx.createStereoPanner) {
        var pL = ctx.createStereoPanner(), pR = ctx.createStereoPanner();
        pL.pan.value = -0.9; pR.pan.value = 0.9;
        oL.connect(pL); pL.connect(g);
        oR.connect(pR); pR.connect(g);
      } else {
        oL.connect(g); oR.connect(g);
      }
      g.connect(KPS.master);
      oL.start(); oR.start();
      KPS.binL = oL; KPS.binR = oR; KPS.binGain = g; KPS.binHz = beatHz;
    }

    function kpsStopNat() {
      ['natSrc', 'natLfo', 'natGain'].forEach(function (k) {
        if (KPS[k]) {
          try { if (KPS[k].stop) KPS[k].stop(); KPS[k].disconnect(); } catch (e) {}
          KPS[k] = null;
        }
      });
      KPS.natId = 'off';
    }

    function kpsPlayNat(id) {
      kpsStopNat();
      if (!id || id === 'off') return;
      var ctx = kpsEnsureCtx(); if (!ctx) return;
      var sr = ctx.sampleRate, len = sr * 3;
      var buf = ctx.createBuffer(1, len, sr);
      var data = buf.getChannelData(0);
      var last = 0;
      for (var i = 0; i < len; i++) {
        var w = Math.random() * 2 - 1;
        if (id === 'brown' || id === 'ocean') {
          last = (last + 0.02 * w) / 1.02;
          data[i] = last * 3.2;
        } else {
          last = 0.7 * last + 0.3 * w;
          data[i] = last * 1.4;
        }
      }
      var src = ctx.createBufferSource();
      src.buffer = buf; src.loop = true;

      var filt = ctx.createBiquadFilter();
      var g = ctx.createGain();
      var lfo = null;
      if (id === 'rain') {
        filt.type = 'bandpass'; filt.frequency.value = 1250; filt.Q.value = 0.6;
        g.gain.value = 0.25;
      } else if (id === 'ocean') {
        filt.type = 'lowpass'; filt.frequency.value = 420;
        g.gain.value = 0.26;
        lfo = ctx.createOscillator();
        var lg = ctx.createGain();
        lfo.frequency.value = 0.11; lg.gain.value = 0.16;
        lfo.connect(lg); lg.connect(g.gain); lfo.start();
      } else if (id === 'wind') {
        filt.type = 'bandpass'; filt.frequency.value = 480; filt.Q.value = 2.4;
        g.gain.value = 0.24;
        lfo = ctx.createOscillator();
        var lg2 = ctx.createGain();
        lfo.frequency.value = 0.16; lg2.gain.value = 180;
        lfo.connect(lg2); lg2.connect(filt.frequency); lfo.start();
      } else {
        filt.type = 'lowpass'; filt.frequency.value = 260;
        g.gain.value = 0.34;
      }
      src.connect(filt); filt.connect(g); g.connect(KPS.master);
      src.start();
      KPS.natSrc = src; KPS.natGain = g; KPS.natLfo = lfo; KPS.natId = id;
    }

    function kpsChime() {
      var ctx = kpsEnsureCtx(); if (!ctx) return;
      [432, 864, 1296].forEach(function (f, idx) {
        var o = ctx.createOscillator(), g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        var a = idx === 0 ? 0.32 : (idx === 1 ? 0.12 : 0.05);
        g.gain.setValueAtTime(a, ctx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 2.8);
        o.connect(g); g.connect(KPS.master);
        o.start(); o.stop(ctx.currentTime + 2.9);
      });
    }

    function kpsStopAll() {
      kpsStopSol(); kpsStopBin(); kpsStopNat();
      if (KPS.sleepIv) { clearInterval(KPS.sleepIv); KPS.sleepIv = null; }
      KPS.sleepEnd = 0;
    }

    function kpsSetSleep(mins) {
      if (KPS.sleepIv) { clearInterval(KPS.sleepIv); KPS.sleepIv = null; }
      if (!mins) { KPS.sleepEnd = 0; updateSndLabels(); return; }
      KPS.sleepEnd = Date.now() + mins * 60000;
      KPS.sleepIv = setInterval(function () {
        var rem = KPS.sleepEnd - Date.now();
        if (rem <= 0) {
          kpsStopAll();
          if (window.kpSpiritualTab && E('t26') && E('t26').style.display === 'block') window.kpSpiritualTab();
        } else {
          updateSndLabels();
        }
      }, 1000);
      updateSndLabels();
    }

    function fmtMMSS(sec) {
      var s = Math.max(0, Math.floor(sec));
      return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    }

    function updateSndLabels() {
      var st = E('kp-slp-lbl');
      if (st) {
        st.textContent = KPS.sleepEnd > Date.now()
          ? ('⏱ ' + fmtMMSS((KPS.sleepEnd - Date.now()) / 1000))
          : ('Timer: Off');
      }
      var mc = E('kp-med-clk');
      if (mc) mc.textContent = fmtMMSS(KPS.medRun ? KPS.medRem : KPS.medTotal);
    }

    // Build Personalized KP Chart Spiritual & Frequency Remedies
    function buildChartRemedies() {
      if (!c) {
        return '<div class="r">' +
          '<b>📌 ' + T('ඔබේ ජන්ම පත්‍රයටම ගැළපෙන ශබ්ද සහ භාවනා සහන ලබාගැනීමට', 'Cast your KP Birth Chart for personalized frequency remedies') + '</b><br>' +
          '<small>' + T('පළමුව ජන්ම පත්‍රය සාදන්න — එවිට ධනය, විවාහය, රැකියාව, සෞඛ්‍යය සහ දැන් දශාවේ ඇති බාධා ස්වයංක්‍රීයව හඳුනාගෙන සුදුසුම ශබ්ද සංඛ්‍යාතය (Hz) සහ භාවනාව නිර්දේශ කෙරේ. පහත ශබ්ද Studio සහ සතිපට්ඨාන භාවනා දැන්ම භාවිත කළ හැකිය.', 'Create your Birth Chart to auto-detect Wealth, Marriage, Career, Health & Dasha blocks. Meanwhile, you can use the Sound Studio and Satipatthana Meditation Guide freely right now.') + '</small>' +
        '</div>';
      }
      var K = ok(kpw); if (!K) return '';
      var W = K.W;
      var recs = [];

      function checkArea(hc, fav, bad) {
        var o = lords(c.cs[hc - 1]), p = P[o.sl], w = W[p] || {};
        var hf = fav.filter(function (x) { return w[x]; });
        var hb = bad.filter(function (x) { return w[x] >= 3; });
        return { weak: hf.length < 2 || hb.length >= 1, csl: plLbl(p), hb: hb };
      }

      var money = checkArea(2, [2, 6, 11], [5, 8, 12]);
      var gains = checkArea(11, [2, 6, 10, 11], [6, 8, 12]);
      if (money.weak || gains.weak) {
        recs.push({
          ico: '💰', hz: 528, hz2: 417, bin: 10,
          tSi: 'ධනය & ආර්ථික බාධා සමනය (2 / 11 භාව සහනය)',
          tEn: 'Wealth & Financial Flow Support (2nd / 11th House)',
          dSi: '2/11 භාව උප-අධිපති (' + money.csl + ') මත යම් ආර්ථික ප්‍රමාද හෝ වියදම් බාධා පෙනේ. <b>528 Hz (මණිපූර)</b> ආත්ම ශක්තිය හා සමෘද්ධි චින්තනය වඩවන අතර <b>417 Hz</b> ඍණාත්මක බාධා ඉවත් කරයි. <b>ධර්ම පිළිවෙත:</b> ලෝභය අඩු කර හැකි පමණින් දන්දීම (දානය) සහ නිතිපතා සීලය රැකීමෙන් පෙර ධන කුසල් ඉක්මනින් පෑදේ.',
          dEn: 'Your 2nd/11th CSL (' + money.csl + ') shows financial hurdles. Listen to <b>528 Hz</b> (vitality & abundance mindset) and <b>417 Hz</b> (clearing blocks). <b>Dhamma practice:</b> Cultivate generosity (Dana) and non-greed to awaken past wholesome merit.'
        });
      }

      var mar = checkArea(7, [2, 7, 11], [1, 6, 10, 12]);
      if (mar.weak) {
        recs.push({
          ico: '💍', hz: 639, hz2: 432, bin: 10,
          tSi: 'විවාහය & සබඳතා බාධා සමනය (7 භාව සහනය)',
          tEn: 'Marriage & Relationship Harmony (7th House)',
          dSi: '7 වන භාව උප-අධිපති (' + mar.csl + ') අනුව විවාහ ප්‍රමාද හෝ සබඳතා බාධා පෙනේ. <b>639 Hz (හෘද අනාහත)</b> හදවතේ සමගිය, ආදරය සහ ආකර්ෂණය වඩවයි. <b>ධර්ම පිළිවෙත:</b> දිනපතා විනාඩි 10ක් <b>මෛත්‍රී භාවනාව</b> වැඩීමෙන් ද්වේෂය හා පෙර සබඳතා කර්ම බාධා සමනය වී යහපත් සහකරුවෙකු සමීප වේ.',
          dEn: 'Your 7th CSL (' + mar.csl + ') shows relationship delays. Listen to <b>639 Hz (Heart Anahata)</b> for emotional harmony, and practice <b>Metta (Loving-Kindness)</b> daily to dissolve interpersonal kamma blocks.'
        });
      }

      var job = checkArea(10, [2, 6, 10, 11], [5, 8, 12]);
      if (job.weak) {
        recs.push({
          ico: '💼', hz: 741, hz2: 396, bin: 18,
          tSi: 'රැකියාව, වෘත්තිය & තීරණ ශක්තිය (10 භාව සහනය)',
          tEn: 'Career, Focus & Obstacle Clearing (10th House)',
          dSi: '10 වන භාව උප-අධිපති (' + job.csl + ') අනුව වෘත්තීය බාධා හෝ ස්ථාවරත්වය ප්‍රමාද විය හැක. <b>741 Hz (විශුද්ධි)</b> පැහැදිලි බුද්ධිය ලබා දෙන අතර <b>396 Hz (මූලාධාර)</b> බිය හා අවිනිශ්චිතතාව දුරලයි. <b>ධර්ම පිළිවෙත:</b> සක්මන් භාවනාවෙන් වීර්යය සහ සිහිය වඩවන්න.',
          dEn: 'Your 10th CSL (' + job.csl + ') shows career hurdles. Use <b>741 Hz</b> for clarity + <b>396 Hz</b> to release fear, paired with Walking Meditation for steady energy.'
        });
      }

      var hl = checkArea(6, [1, 5, 11], [6, 8, 12]);
      var lag = checkArea(1, [1, 5, 11], [6, 8, 12]);
      if (hl.hb.length || lag.hb.length) {
        recs.push({
          ico: '🩺', hz: 174, hz2: 285, bin: 6,
          tSi: 'සෞඛ්‍යය, ශරීර වෙහෙස & අපල සමනය (1 / 6 භාව)',
          tEn: 'Health, Vitality & Immunity Relief (1st / 6th House)',
          dSi: '1/6 භාව උප-අධිපතීන් 6, 8, 12 සමඟ සම්බන්ධ බැවින් ශරීර සෞඛ්‍යයට <b>174 Hz (වේදනා සමනය)</b> සහ <b>285 Hz (ශක්ති ප්‍රකෘතිමත්)</b> සුදුසුයි. <b>ධර්ම පිළිවෙත:</b> නිතිපතා ආනාපානසති සහ 5.5–5.5 සන්සුන් හුස්ම ව්‍යායාමය මඟින් ශරීර ආතතිය අඩු කර සුවය වේගවත් කරන්න.',
          dEn: '1st/6th house links to 6, 8, 12 benefit from <b>174 Hz</b> & <b>285 Hz</b> for deep rest, paired with Anapanasati & Coherent 5.5-5.5 breathing.'
        });
      }

      // Always add Current Running Dasha Planet Frequency + Universal Spiritual Peace
      var dl = dashL(kNow()) || [];
      var mPl = dl[0] || 'Ju';
      var PL_FREQ = {
        Su: { hz: 528, chSi: 'මණිපූර (Solar)', chEn: 'Solar Plexus' },
        Mo: { hz: 432, chSi: 'ස්වාධිෂ්ඨාන / සන්සුන් මනස', chEn: 'Emotional Calm' },
        Ma: { hz: 396, chSi: 'මූලාධාර (Root)', chEn: 'Root Chakra' },
        Me: { hz: 741, chSi: 'විශුද්ධි (Throat)', chEn: 'Throat Chakra' },
        Ju: { hz: 852, chSi: 'ආඥා (Third Eye)', chEn: 'Third Eye' },
        Ve: { hz: 639, chSi: 'හෘද අනාහත (Heart)', chEn: 'Heart Chakra' },
        Sa: { hz: 396, chSi: 'මූලාධාර & 136.1 Hz OM', chEn: 'Root & 136.1 Hz OM' },
        Ra: { hz: 852, chSi: 'ආඥා & 417 Hz බාධා මැකීම', chEn: 'Third Eye & 417 Hz' },
        Ke: { hz: 963, chSi: 'සහස්‍රාර (Crown) & නිවන් මඟ', chEn: 'Crown Chakra' }
      };
      var pf = PL_FREQ[mPl] || PL_FREQ.Ju;
      recs.push({
        ico: '⏳', hz: pf.hz, hz2: 136.1, bin: 6,
        tSi: 'දැන් ක්‍රියාත්මක මහා දශාව (' + plLbl(mPl) + ') සඳහා විශේෂ ශබ්දය',
        tEn: 'Running Mahadasha (' + plLbl(mPl) + ') Balancing Frequency',
        dSi: 'දැන් ඔබට <b>' + (dl.map(plLbl).join(' → ') || plLbl(mPl)) + '</b> දශාව ක්‍රියාත්මකයි. ' + plLbl(mPl) + ' දශාවේ මානසික සමබරතාවට <b>' + pf.hz + ' Hz (' + pf.chSi + ')</b> සහ <b>136.1 Hz (ඕම් නාදය)</b> සමඟ දිනපතා සතිපට්ඨාන භාවනාව වැඩීම ඉතා සුබයි.',
        dEn: 'Your active dasha is <b>' + (dl.map(plLbl).join(' → ') || plLbl(mPl)) + '</b>. Balance this period with <b>' + pf.hz + ' Hz (' + pf.chEn + ')</b> + <b>136.1 Hz OM</b> and daily mindfulness.'
      });

      if (recs.length === 1) {
        recs.unshift({
          ico: '🌟', hz: 639, hz2: 963, bin: 6,
          tSi: 'ඔබේ ප්‍රධාන භාව සුබයි — ආධ්‍යාත්මික දියුණුවට ඉහළම සංඛ්‍යාතය',
          tEn: 'Strong Natal Chart — Elevate Spiritual Awareness',
          dSi: 'ඔබේ ජන්ම පත්‍රයේ ප්‍රධාන භාව යහපත්ය. පෙර කුසල් තවදුරටත් බලවත් කරගැනීමට <b>639 Hz (මෛත්‍රිය)</b> සහ <b>963 Hz (පරම ශාන්තිය)</b> සමඟ සතර සතිපට්ඨාන භාවනාව වඩන්න.',
          dEn: 'Your major houses look supportive. Deepen your merit and peace with <b>639 Hz</b>, <b>963 Hz</b>, and Satipatthana meditation.'
        });
      }

      return recs.map(function (r) {
        return '<div class="kp-rem-card">' +
          '<b>' + r.ico + ' ' + (SI ? r.tSi : r.tEn) + '</b>' +
          '<div style="margin-top:4px">' + (SI ? r.dSi : r.dEn) + '</div>' +
          '<div class="kp-rem-acts">' +
            '<button type="button" class="p" data-playhz="' + r.hz + '" data-playbin="' + r.bin + '">▶ ' + r.hz + ' Hz ' + T('දැන් අහන්න', 'Play Now') + '</button>' +
            '<button type="button" data-playhz="' + r.hz2 + '" data-playbin="0">🎵 ' + r.hz2 + ' Hz</button>' +
            '<button type="button" data-gosp="med">☸️ ' + T('භාවනාව බලන්න', 'Meditation') + '</button>' +
          '</div>' +
        '</div>';
      }).join('');
    }

    var spTab = 'rem';
    window.kpSpiritualTab = function () {
      var el = E('t26');
      if (!el) return;

      var body = '';
      if (spTab === 'rem') {
        body =
          '<div class="kp-dhamma-hero">' +
            '<b class="dh-hd">☸️ ' + T('කෙලෙස් දියවෙන තරමට පෙර කුසල් පෑදේ!', 'As Defilements Dissolve, Past Wholesome Merit Awakens!') + '</b>' +
            T('ජ්‍යොතිෂයෙන් (KP) පෙන්වන්නේ පෙර කළ <b>කර්ම විපාක</b> පමණි. එහෙත් සක්මන් හා සතිපට්ඨාන භාවනාව තුළින් <b>කයේ ධාතු ගුණවලට ඇලෙන්නේත් නැතිව, ගැටෙන්නේත් නැතිව</b> සිහියෙන් සිටින විට ලෝභ–ද්වේෂ–මෝහ (කෙලෙස්) ස්වභාවිකවම දියවීමට පටන් ගනී. කෙලෙස් දියවෙන තරමට අකුසල විපාක දුර්වල වී <b>ඔබේ පෙර කුසල් ශක්තිය ඉක්මනින් පෑදී සැබෑ සහනය ලැබේ.</b>',
              'KP Astrology reflects past kamma patterns. Yet when you practice effortless mindfulness — remaining present with the <b>body’s elemental qualities (Dhatu) without clinging or resisting</b> — greed, hatred, and delusion naturally begin to dissolve. As defilements dissolve, unwholesome effects weaken and your <b>past wholesome merits awaken</b>.') +
          '</div>' +
          buildChartRemedies();
      } else if (spTab === 'snd') {
        body =
          '<div class="kp-snd-box">' +
            '<div class="kp-snd-top">' +
              '<b>🎧 ' + T('Sound, Binaural & Nature Mixer (100% Offline)', 'Sound, Binaural & Nature Mixer (Offline)') + '</b>' +
              '<span class="kp-tag-s" id="kp-slp-lbl">' + (KPS.sleepEnd > Date.now() ? '⏱ ' + fmtMMSS((KPS.sleepEnd - Date.now()) / 1000) : 'Timer: Off') + '</span>' +
            '</div>' +
            '<div class="kp-snd-vol">' +
              '<span>🔊</span>' +
              '<input type="range" id="kp-vol" min="0" max="1" step="0.02" value="' + KPS.vol + '">' +
              '<button type="button" id="kp-stop-all" style="margin:0;min-height:32px;padding:4px 10px;background:rgba(244,63,94,0.18);border-color:rgba(244,63,94,0.45);color:#fda4af">🔇 Stop All</button>' +
            '</div>' +

            '<div style="font-size:12px;font-weight:700;color:var(--ac)">⏰ ' + T('ස්වයංක්‍රීයව නවතින ටයිමරය (Auto-Stop)', 'Auto-Stop Timer') + '</div>' +
            '<div class="kp-chips" id="kp-slp-row">' +
              [0, 5, 10, 15, 30, 60].map(function (m) {
                return '<button type="button" class="kp-chip" data-slp="' + m + '">' + (m ? m + ' min' : 'Off') + '</button>';
              }).join('') +
            '</div>' +

            '<div style="font-size:12px;font-weight:700;color:var(--ac)">🎧 ' + T('Binaural Beats (හෙඩ්ෆෝන් සඳහා Brainwaves)', 'Binaural Beats (Use Headphones)') + '</div>' +
            '<div class="kp-chips" id="kp-bin-row">' +
              SP_BIN.map(function (b) {
                return '<button type="button" class="kp-chip' + (KPS.binHz === b.hz ? ' on' : '') + '" data-bin="' + b.hz + '">' + (SI ? b.si : b.en) + '</button>';
              }).join('') +
            '</div>' +

            '<div style="font-size:12px;font-weight:700;color:var(--ac)">🌧️ ' + T('ස්වාභාවික ශබ්ද මිශ්‍රණය (Nature Mixer — Offline)', 'Offline Nature Sound Mixer') + '</div>' +
            '<div class="kp-chips" id="kp-nat-row">' +
              SP_NAT.map(function (n) {
                return '<button type="button" class="kp-chip' + (KPS.natId === n.id ? ' on' : '') + '" data-nat="' + n.id + '">' + (SI ? n.si : n.en) + '</button>';
              }).join('') +
            '</div>' +
          '</div>' +

          '<div class="kb-subhd">🎵 ' + T('Solfeggio & Chakra ෆ්‍රීකුවන්සි (11)', 'Solfeggio & Chakra Frequencies (11)') + '</div>' +
          '<div class="kp-hz-grid" id="kp-hz-grid">' +
            SP_FREQS.map(function (f) {
              var on = KPS.solHz === f.hz;
              return '<button type="button" class="kp-hz-card' + (on ? ' on' : '') + '" data-hz="' + f.hz + '">' +
                '<div class="kp-hz-top"><span class="kp-hz-num" style="color:' + f.col + '">' + f.hz + ' Hz</span><span class="kp-hz-tag">' + (on ? '▶ ON' : f.tag) + '</span></div>' +
                '<div class="kp-hz-t">' + (SI ? f.si : f.en) + '</div>' +
                '<div class="kp-hz-s">' + (SI ? f.sSi : f.sEn) + '</div>' +
              '</button>';
            }).join('') +
          '</div>' +

          '<div class="kp-br-wrap">' +
            '<b style="font-size:13px;color:var(--pl)">🫁 ' + T('හෘද-මනස සමබර කරන හුස්ම ව්‍යායාමය', 'Heart-Mind Guided Breathing') + '</b>' +
            '<div class="kp-chips" style="justify-content:center;margin-top:8px" id="kp-br-modes">' +
              '<button type="button" class="kp-chip' + (KPS.brMode === 'coh' ? ' on' : '') + '" data-bm="coh">5.5–5.5 ' + T('සමබර', 'Coherent') + '</button>' +
              '<button type="button" class="kp-chip' + (KPS.brMode === '478' ? ' on' : '') + '" data-bm="478">4–7–8 ' + T('සන්සුන්', 'Relax') + '</button>' +
              '<button type="button" class="kp-chip' + (KPS.brMode === 'box' ? ' on' : '') + '" data-bm="box">4–4–4–4 Box</button>' +
            '</div>' +
            '<div class="kp-br-orb" id="kp-br-orb">' +
              '<span id="kp-br-ph">' + (KPS.brRun ? T('ආශ්වාස', 'Inhale') : T('ආරම්භ කරන්න', 'Ready')) + '</span>' +
              '<b class="kp-br-sec" id="kp-br-sec">' + (KPS.brRun ? '...' : (KPS.brMode === 'coh' ? '5.5s' : '4.0s')) + '</b>' +
            '</div>' +
            '<div id="kp-br-cyc" style="font-size:11.5px;color:var(--mu);margin-bottom:6px">' + T('වට ගණන: ', 'Cycles: ') + KPS.brCycles + '</div>' +
            '<div class="kp-chips">' +
              '<button type="button" class="p" id="kp-br-tog">' + (KPS.brRun ? '⏹ ' + T('නවතන්න', 'Stop') : '▶ ' + T('හුස්ම අභ්‍යාසය අරඹන්න', 'Start Breathing')) + '</button>' +
            '</div>' +
          '</div>';
      } else if (spTab === 'med') {
        body =
          '<div class="kp-dhamma-hero">' +
            '<b class="dh-hd">☸️ ' + T('නිවන් දැකීමේ ඒකායන මාර්ගය — සතර සතිපට්ඨානය', 'The Direct Path to Liberation — Four Foundations of Mindfulness') + '</b>' +
            T('බුදුරජාණන් වහන්සේ <b>මහා සතිපට්ඨාන සූත්‍රයේදී</b> දේශනා කළ පරිදි, සත්ත්වයන්ගේ විශුද්ධිය පිණිසත්, ශෝක-වැළපීම් දුරු කිරීම පිණිසත්, දුක්-දොම්නස් අහෝසි කිරීම පිණිසත්, නිවන සාක්ෂාත් කිරීම පිණිසත් ඇති <b>එකම මාර්ගය සතර සතිපට්ඨානයයි</b>. සිහිය දියුණු වී කෙලෙස් සංසිඳෙන විට පෙර කුසල්ද ස්වභාවිකවම බලවත් වේ.',
              'As taught by the Buddha in the <b>Maha Satipatthana Sutta (DN 22 / MN 10)</b>, the Four Foundations of Mindfulness are the direct path for the purification of beings, overcoming sorrow and lamentation, and realizing Nibbana.') +
          '</div>' +

          '<div class="kp-med-tmr">' +
            '<b style="font-size:12.5px;color:var(--hl)">🔔 ' + T('භාවනා ටයිමරය (Singing Bowl Bell)', 'Meditation Timer (Singing Bowl Bell)') + '</b>' +
            '<div class="kp-med-clk" id="kp-med-clk">' + fmtMMSS(KPS.medRun ? KPS.medRem : KPS.medTotal) + '</div>' +
            '<div class="kp-chips" style="justify-content:center" id="kp-med-mins">' +
              [5, 10, 15, 20, 30, 45, 60].map(function (m) {
                return '<button type="button" class="kp-chip' + (KPS.medTotal === m * 60 ? ' on' : '') + '" data-mm="' + m + '">' + m + 'm</button>';
              }).join('') +
            '</div>' +
            '<div style="display:flex;gap:8px;justify-content:center;margin-top:6px">' +
              '<button type="button" class="p" id="kp-med-go">' + (KPS.medRun ? '⏸ ' + T('නවතන්න', 'Stop') : '▶ ' + T('භාවනාව අරඹන්න (Bell)', 'Start Meditation')) + '</button>' +
              '<button type="button" id="kp-med-bell">🔔 ' + T('සීනුව', 'Bell') + '</button>' +
            '</div>' +
          '</div>' +

          '<details class="adv" open><summary>1️⃣ ' + T('සතර සතිපට්ඨාන භාවනාව (කාය · වේදනා · චිත්ත · ධම්ම)', 'Four Foundations of Mindfulness (Satipatthana)') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.75">' +
            T('<b>① කායානුපස්සනාව (කය දෙස සිහියෙන් බැලීම):</b> හුස්ම රැල්ල (ආනාපානසති), ඇවිදීම-සිටීම-හිඳීම-නිදීම යන ඉරියව් 4 (ඉරියාපථ), එදිනෙදා ක්‍රියාවල සිහිය (සම්පජඤ්ඤ), ශරීරයේ අසුබ ස්වභාවය (කෙස්, ලොම්, නිය, දත්, සම — පටිකූලමනසිකාරය) සහ පඨවි-ආපෝ-තේජෝ-වායෝ යන සතර මහා ධාතු ලෙස කය දැකීම.<br><br>' +
              '<b>② වේදනානුපස්සනාව (වේදනා දෙස සිහියෙන් බැලීම):</b> කයට හෝ සිතට සැප වේදනාවක්, දුක් වේදනාවක් හෝ උපේක්ෂා (මධ්‍යස්ථ) වේදනාවක් දැනෙන මොහොතේම <i>"මෙය සැප/දුක්/මධ්‍යස්ථ වේදනාවක්, මෙය හටගෙන නැතිවී යන අනිත්‍ය දෙයක්"</i> යැයි ඇලීමකින් හෝ ගැටීමකින් තොරව දැකීම.<br><br>' +
              '<b>③ චිත්තානුපස්සනාව (සිත දෙස සිහියෙන් බැලීම):</b> සිතේ රාගය (ඇලීම), ද්වේෂය (තරහ/අමනාපය), මෝහය (මුළාව), සන්සුන් බව හෝ විසිරුණු බව ඇතිවූ සැණින් <i>"දැන් මගේ සිතේ මෙවැනි සිතුවිල්ලක් ඇතිවී තිබේ"</i> යැයි සාක්ෂිකරුවෙකු මෙන් හඳුනාගැනීම. එවිට කෙලෙස් සිතට බලපෑම් නොකර සංසිඳී යයි.<br><br>' +
              '<b>④ ධම්මානුපස්සනාව (ධර්මතා දෙස සිහියෙන් බැලීම):</b> සිත ආවරණය කරන <b>පංච නීවරණ</b> (කාමච්ඡන්ද, ව්‍යාපාද, ථීනමිද්ධ, උද්ධච්ච-කුක්කුච්ච, විචිකිච්ඡා), පංච උපාදානස්කන්ධ, ඇස-කන ආදී ආයතන, සප්ත බොජ්ඣංග සහ චතුරාර්ය සත්‍යය තුළින් සියල්ල <b>අනිත්‍ය – දුක්ඛ – අනාත්ම</b> බව ප්‍රඥාවෙන් දැකීම.',
              '<b>① Kayanupassana (Body):</b> Breath (Anapanasati), 4 postures (walking, standing, sitting, lying), clear comprehension, body parts, and the 4 elements (earth, water, fire, air).<br><br>' +
              '<b>② Vedananupassana (Feelings):</b> Observing pleasant, unpleasant, and neutral feelings arising and passing away without craving or aversion.<br><br>' +
              '<b>③ Cittanupassana (Mind):</b> Recognizing states of mind (with lust, anger, delusion, calm, distracted) objectively the moment they arise.<br><br>' +
              '<b>④ Dhammanupassana (Dhamma/Phenomena):</b> Observing the 5 Hindrances, 5 Aggregates, 6 Sense Bases, 7 Factors of Enlightenment, and the Four Noble Truths (Impermanence, Suffering, Non-Self).') +
          '</div></details>' +

          '<details class="adv" open><summary>2️⃣ ' + T('ආනාපානසති භාවනාව (නිවැරදිව වඩන පියවර — MN 118)', 'Anapanasati Breath Meditation (Step-by-Step Guide)') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.75">' +
            T('<b>පියවර 1 — නිවැරදි ඉරියව්ව:</b> නිහඬ තැනක පලඟ බැඳ (හෝ පුටුවක පහසුවෙන්) හිඳ, <b>කොන්ද සහ බෙල්ල සෘජුව</b> තබා, දෑත් උකුළ මත තබා ඇස් මෘදුව පියාගන්න. මුළු ශරීරයම සැහැල්ලු කරන්න.<br>' +
              '<b>පියවර 2 — සිහිය පිහිටුවීම (පරිමුඛං සතිං):</b> හුස්ම බලෙන් ඇදීම හෝ පිට කිරීම නොකර, ස්වභාවිකව හුස්ම ඇතුළුවන සහ පිටවන <b>නාස්පුඩු අග හෝ උඩු තොලේ ස්පර්ශය</b> වෙත සිහිය යොමු කරන්න.<br>' +
              '<b>පියවර 3 — දීර්ඝ හා කෙටි හුස්ම දැනීම:</b> දිගට හුස්ම ගනිද්දී <i>"දිග ආශ්වාසයක්"</i> බවත්, කෙටි හුස්මක් ගනිද්දී <i>"කෙටි ආශ්වාසයක්"</i> බවත් සිහියෙන් දැනගන්න.<br>' +
              '<b>පියවර 4 — මුළු හුස්ම පෙළ & සංසිඳීම:</b> හුස්ම ආරම්භය, මැද සහ අවසානය මුළුමනින්ම දැනෙමින්, ශරීරය සහ හුස්ම ඉතා සියුම්ව සංසිඳෙන ආකාරය අත්විඳින්න.<br>' +
              '<b>පියවර 5 — සිත විසිරුණු විට:</b> සිත වෙනත් කල්පනාවකට ගිය බව දැනුණු සැණින් තරහ නොගෙන, මෘදුව සිනාසී නැවත හුස්ම ස්පර්ශය වෙත සිහිය ගෙන එන්න.<br>' +
              '<b>පියවර 6 — විදර්ශනාවට යොමු කිරීම:</b> සිත සමාධිගත වූ පසු, සෑම හුස්ම රැල්ලක්ම හටගෙන ඒ මොහොතේම නැතිවී යන <b>අනිත්‍ය ස්වභාවය</b> දකිමින් ඇලීම අත්හරින්න.',
              '<b>Step 1 — Posture:</b> Sit comfortably with your back straight, shoulders relaxed, and eyes gently closed.<br>' +
              '<b>Step 2 — Anchor Attention:</b> Do not force the breath. Gently rest awareness on the natural touch of air at the nostrils/upper lip.<br>' +
              '<b>Step 3 — Long & Short Breaths:</b> Simply know when a breath is long and when it is short.<br>' +
              '<b>Step 4 — Calming:</b> Feel the entire breath cycle from start to finish as body and breath grow calm and subtle.<br>' +
              '<b>Step 5 — Wandering Mind:</b> Whenever thoughts arise, gently notice them without frustration and return softly to the breath.<br>' +
              '<b>Step 6 — Insight (Vipassana):</b> Observe how every breath arises and vanishes — directly seeing impermanence (Anicca) and letting go.') +
          '</div></details>' +

          '<details class="adv" open><summary>3️⃣ ' + T('සක්මන් භාවනාව (යටි පතුලේ ස්පර්ශයෙන් නිරායාස සිහියට)', 'Walking Meditation (Foot Sole Touch to Effortless Mindfulness)') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.78">' +
            T('<b>සූදානම:</b> පියවර 15–25ක් පමණ සමතලා මාවතක සැහැල්ලුවෙන් සිටගන්න. දෑත් පහසුවෙන් තබා, ඇස් අඩි 4–6ක් ඉදිරියෙන් බිම දෙසට මෘදුව යොමු කරන්න. සාමාන්‍ය සැහැල්ලු වේගයෙන් ඇවිදින්න (වැඩියෙන් සෙමින් හෝ කෘත්‍රිමව ඇවිදීම අවශ්‍ය නැත).<br><br>' +
              '<b>① මුලින්ම කරන ආකාරය (යටි පතුල පොළොවේ වදින මොහොත):</b><br>' +
              'ඇවිදින විට <i>"වම–දකුණ"</i> හෝ <i>"ඔසවනවා–තබනවා"</i> යැයි වචනවලින් සිතීම අවශ්‍ය නැත. ඒ වෙනුවට <b>ඒ ඒ පාදයේ යටි පතුල පොළොවේ වදින අවස්ථාවේදී එතැනට සැහැල්ලුවෙන් සිහිය තබන්න</b>. පතුල පොළොවේ ස්පර්ශ වන දැනීම සෘජුවම දැනගන්න.<br><br>' +
              '<b>② සිත බාහිර අරමුණකට ගිය විට:</b><br>' +
              'අවට ශබ්දයකට හෝ සිතුවිල්ලකට සිත ගියාට තරහ නොගෙන, බලෙන් සිත ඇදගන්න උත්සාහ නොකර, ඒ බව දැනගෙන ක්‍රමයෙන් නැවත පාදයේ යටි පතුල පොළොවේ වදින තැනට සිහිය යොමු කරන්න.<br><br>' +
              '<b>③ ඉන් පසුව — නිරායාස සිහිය (Effortless Awareness):</b><br>' +
              'යටි පතුලට සිහිය තැබීම අවශ්‍ය වන්නේ <b>මුලින් සිහිය පුහුණු වන තුරු පමණි</b>. ක්‍රමයෙන් සිහිය පිහිටා පුරුදු වූ පසු, උත්සාහයෙන් පතුලට සිහිය තැබීමට අවශ්‍ය නොවේ — සිහිය <b>නිරායාසයෙන්ම</b> පවතින්නට පටන් ගනී. සක්මනේදී පමණක් නොව එදිනෙදා කටයුතුවලදීත් කයේ සිහිය ස්වභාවිකවම පිහිටයි.<br><br>' +
              '<b>🌟 සක්මන් භාවනාවේ ආනිසංස 5 (චංකම සූත්‍රය):</b> ① දුර ගමන් ඔරොත්තු දීම, ② වීර්යය වැඩීම, ③ නිරෝගී බව, ④ ආහාර හොඳින් ජීර්ණය වීම, ⑤ සක්මනින් වැඩෙන සමාධිය දිගු කාලයක් නොබිඳී පැවතීම.',
              '<b>Setup:</b> Choose a flat 15–25 step path. Stand relaxed, keep hands comfortable, eyes softly cast 4–6 feet ahead, and walk at a natural, unforced pace.<br><br>' +
              '<b>① At the Beginning (Exact Moment the Sole Touches the Ground):</b><br>' +
              'You do not need to mentally repeat words like <i>"left, right"</i> or <i>"lifting, placing"</i>. Simply <b>rest gentle mindfulness directly on the sole of each foot at the exact moment it touches the ground</b>.<br><br>' +
              '<b>② When the Mind Wanders:</b><br>' +
              'Do not force or fight thoughts or outside sounds. Gently notice the wandering and let awareness softly return to the contact of the sole touching the ground.<br><br>' +
              '<b>③ Afterwards — Effortless Mindfulness:</b><br>' +
              'Deliberately placing awareness on the sole is <b>only needed at the start</b>. Once mindfulness settles, it becomes completely <b>effortless and natural</b> — staying present on its own during walking and throughout daily life.<br><br>' +
              '<b>🌟 5 Benefits (Cankama Sutta, AN 5.29):</b> Endurance for travel, endurance for effort, good health, good digestion, and long-lasting concentration.') +
          '</div></details>' +

          '<details class="adv" open><summary>✨ ' + T('කයේ ධාතු ගුණ & ඇලීමෙන්–ගැටීමෙන් තොරව කෙලෙස් දියවන හැටි', 'Body Elemental Qualities (Dhatu) & How Defilements Dissolve') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.78">' +
            T('සක්මන් හා සතිපට්ඨාන භාවනාව පුහුණු වන විට, ශරීරය තුළ <b>සතර මහා ධාතු ගුණ</b> (සියුම් හෝ ප්‍රකට ශාරීරික දැනීම්) ස්වභාවිකවම දැනෙන්නට පටන් ගනී:<br>' +
              '• <b>පඨවි ධාතු ගුණ:</b> තද බව, බර බව, මොළොක් බව, හිරි ගතිය, තෙරපුම හෝ ඇදෙන ගති.<br>' +
              '• <b>ආපෝ ධාතු ගුණ:</b> බැඳෙන ගතිය, වැගිරෙන/දියර ස්වභාවය.<br>' +
              '• <b>තේජෝ ධාතු ගුණ:</b> උණුසුම, ගිනියම් ගතිය, දැවිල්ල හෝ සිසිලස.<br>' +
              '• <b>වායෝ ධාතු ගුණ:</b> සියුම් කම්පන, මස් නටන ගති, කිතිකැවෙන/විදින ස්පර්ශ, සෙලවීම, පිම්බීම හා ඇකිළීම.<br><br>' +
              '<b>💎 කෙලෙස් දියවෙන සැබෑ මූලධර්මය (ඇලෙන්නේත් නැතිව · ගැටෙන්නේත් නැතිව):</b><br>' +
              '• සුවදායක, සැහැල්ලු ධාතු ගුණයක් හෝ සතුටක් දැනුණු විට <b>එයට ඇලෙන්නේ නැතිව</b> (තව ඕනෑ යැයි රඳවා ගැනීමට නොයා) සිටින්න.<br>' +
              '• අපහසු, උණුසුම්, බර හෝ වේදනාකාරී ධාතු ගුණයක් දැනුණු විට <b>එයට ගැටෙන්නේ නැතිව</b> (තරහ හෝ අමනාපයෙන් එය නැති කරන්නට නොයා) සිටින්න.<br>' +
              '• මේවා හුදෙක් <b>කයේ ධාතු ගුණ පමණක්</b> බව දැන, <b>ඇලෙන්නේත් නැතිව ගැටෙන්නේත් නැතිව උපේක්ෂාවෙන්</b> දකිමින් සිටින විට, සිතේ මුල් බැස ඇති ලෝභ–ද්වේෂ–මෝහ <b>(කෙලෙස්) ක්‍රමයෙන් දියවීමට පටන් ගනී</b>.<br>' +
              '• කෙලෙස් දියවෙන තරමට අකුසල කර්ම බලය හීන වී, ඔබේ පෙර කුසල් පෑදෙමින් සිත සැබෑ නිවන් ශාන්තිය දෙසට යොමු වේ.',
              'As mindfulness settles in walking and daily life, the <b>four elemental qualities (Dhatu)</b> of the body become naturally felt:<br>' +
              '• <b>Earth (Pathavi):</b> Hardness, heaviness, softness, numbness, pressure, or tension.<br>' +
              '• <b>Water (Apo):</b> Cohesion, fluidity, or moisture.<br>' +
              '• <b>Fire (Tejo):</b> Warmth, heat, burning sensations, or coolness.<br>' +
              '• <b>Air (Vayo):</b> Subtle vibration, twitching, tingling, movement, expansion, or contraction.<br><br>' +
              '<b>💎 The Key to Dissolving Defilements (Neither Clinging Nor Resisting):</b><br>' +
              '• When pleasant sensations or ease arise — <b>do not cling</b> or try to hold onto them.<br>' +
              '• When unpleasant sensations (heat, heaviness, aches) arise — <b>do not resist</b> or react with irritation.<br>' +
              '• Simply remain aware of them as natural elemental qualities arising and passing away — <b>without clinging and without resisting</b>. In that balanced equanimity, deep-rooted greed, hatred, and delusion (<b>Kilesa</b>) naturally begin to dissolve, awakening your wholesome merits and opening the path to peace.') +
          '</div></details>' +

          '<details class="adv"><summary>4️⃣ ' + T('මෛත්‍රී භාවනාව & කර්ම සමනය (විවාහ, සබඳතා සහ ආරක්ෂාවට)', 'Metta (Loving-Kindness) Meditation & 11 Blessings') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.75">' +
            T('<b>වඩන නිවැරදි පිළිවෙළ:</b><br>' +
              '1. <b>පළමුව තමාට:</b> <i>"මම නිදුක් වෙම්වා, නිරෝගී වෙම්වා, සුවපත් වෙම්වා, දුකින් මිදෙම්වා!"</i><br>' +
              '2. <b>මව්පියන්ට හා ගුරුවරුන්ට:</b> ඒ ආකාරයෙන්ම හදවතින්ම සුබ පතන්න.<br>' +
              '3. <b>හිතවතුන්ට සහ මධ්‍යස්ථ අයට</b> මෛත්‍රිය පතුරුවන්න.<br>' +
              '4. <b>අමනාප / තරහ අයට:</b> <i>"ඔවුන්ද කර්ම දායාද කරගත් සත්ත්වයන්ය; ඔවුන්ද වෛර නැත්තෝ වෙත්වා, සුවපත් වෙත්වා!"</i> (මෙයින් පෙර අමනාප කර්ම වේගයෙන් සමනය වේ).<br>' +
              '5. <b>දස දිසාවේ සියලු සත්ත්වයන්ට</b> සීමා රහිතව මෛත්‍රිය පතුරුවා, තමා කළ සියලු පින් දෙවියන්ට, මළගිය ඥාතීන්ට සහ සියලු සත්ත්වයන්ට අනුමෝදන් කරන්න.<br><br>' +
              '<b>✨ මෛත්‍රී ආනිසංස 11 (මෙත්තානිසංස සූත්‍රය):</b> සුවසේ නින්ද යාම, සුවසේ අවදි වීම, නපුරු සිහින නොපෙනීම, මිනිසුන්ට හා අමනුෂ්‍යයන්ට ප්‍රිය වීම, දෙවියන්ගේ රැකවරණය, ගිනි-විෂ-ආයුධවලින් ආරක්ෂාව, ඉක්මනින් සිත සමාධිගත වීම, මුහුණ පැහැපත් වීම, නොමුළාව මරණයට මුහුණ දීම.',
              '<b>Step-by-Step Sequence:</b><br>' +
              '1. <b>Self:</b> <i>"May I be free from anger, free from illness, peaceful and happy."</i><br>' +
              '2. <b>Parents & Mentors</b> → 3. <b>Loved & Neutral people</b> → 4. <b>Difficult people</b> (dissolves deep karmic friction) → 5. <b>All beings in all directions</b>, followed by sharing merits.<br><br>' +
              '<b>✨ 11 Blessings (AN 11.16):</b> Peaceful sleep, peaceful waking, no bad dreams, dear to humans & non-humans, protected by devas, calm quick concentration, serene countenance, unconfused mind.') +
          '</div></details>' +

          '<details class="adv"><summary>5️⃣ ' + T('කර්ම අපල දුරුකර පෙර කුසල් පාදාගන්නා දිනපතා පිළිවෙත', 'Daily Routine to Awaken Past Merits & Calm Apala') + '</summary><div style="padding:8px 10px;font-size:12.5px;line-height:1.75">' +
            T('• <b>උදෑසන (විනාඩි 15):</b> පන්සිල් සමාදන් වීම → විනාඩි 5ක් මෛත්‍රී භාවනාව → විනාඩි 10ක් ආනාපානසති (හෝ 639/528 Hz සමඟ 5.5–5.5 හුස්ම).<br>' +
              '• <b>දහවල් (විනාඩි 10):</b> සක්මන් භාවනාව + අනුන්ට කරුණාවෙන් වචනයක් කතා කිරීම / හැකි උපකාරයක් කිරීම.<br>' +
              '• <b>රාත්‍රී නින්දට පෙර (විනාඩි 10):</b> දවසේ කළ යහපත් දේ සිහිපත් කර සතුටු වී (මුදිතාව), සියලු සත්ත්වයන්ට පින් අනුමෝදන් කර, දුරකථනය කාමරයෙන් ඉවතට තබා මෛත්‍රී සිතින් සුවසේ නින්දට යන්න.',
              '• <b>Morning (15m):</b> Five Precepts → 5 min Metta → 10 min Anapanasati (or 5.5-5.5 breathing).<br>' +
              '• <b>Daytime (10m):</b> Mindful walking + kind speech & small acts of generosity.<br>' +
              '• <b>Night (10m):</b> Reflect on wholesome deeds with joy (Mudita), share merits with all beings, keep your phone away from the bedroom, and rest peacefully with a calm mind.') +
          '</div></details>';
      } else {
        // Tab 4: 7 Chakras & Planetary Remedies
        var chks = [
          { hz: 396, pl: 'Ma / Sa', nSi: '1. මූලාධාර චක්‍රය (Root)', nEn: '1. Root Chakra (Muladhara)', pSi: 'කුජ / ශනි · ණය, බිය, ආරක්ෂාව & ස්ථාවරත්වය', pEn: 'Mars / Saturn · Stability, courage, clearing debt & fear', mSi: 'කායානුපස්සනා & සක්මන් භාවනාව', mEn: 'Kayanupassana & Walking Meditation' },
          { hz: 417, pl: 'Mo / Ra', nSi: '2. ස්වාධිෂ්ඨාන චක්‍රය (Sacral)', nEn: '2. Sacral Chakra (Svadhisthana)', pSi: 'චන්ද්‍ර / රාහු · ඍණාත්මක කර්ම බාධා & හැඟීම් පාලනය', pEn: 'Moon / Rahu · Releasing negative blocks & emotional balance', mSi: 'වේදනානුපස්සනා (වේදනා අනිත්‍ය දැකීම)', mEn: 'Vedananupassana (Mindfulness of feelings)' },
          { hz: 528, pl: 'Su',      nSi: '3. මණිපූර චක්‍රය (Solar Plexus)', nEn: '3. Solar Plexus (Manipura)', pSi: 'රවි · ධනය, ආත්ම විශ්වාසය, ජීව ශක්තිය & නායකත්වය', pEn: 'Sun · Wealth flow, willpower, confidence & vitality', mSi: 'දානය (ලෝභය අඩු කිරීම) & ආනාපානසති', mEn: 'Generosity (Dana) & Anapanasati' },
          { hz: 639, pl: 'Ve',      nSi: '4. අනාහත හෘද චක්‍රය (Heart)', nEn: '4. Heart Chakra (Anahata)', pSi: 'සිකුරු · විවාහය, ආදරය, පවුල් සමගිය & කරුණාව', pEn: 'Venus · Marriage, relationships, harmony & compassion', mSi: 'මෛත්‍රී භාවනාව & 5.5–5.5 හුස්ම', mEn: 'Metta Meditation & Coherent Breathing' },
          { hz: 741, pl: 'Me',      nSi: '5. විශුද්ධි චක්‍රය (Throat)', nEn: '5. Throat Chakra (Vishuddha)', pSi: 'බුධ · වෘත්තිය, අධ්‍යාපනය, සත්‍ය වචනය & පැහැදිලි බුද්ධිය', pEn: 'Mercury · Career, study, truthful speech & clarity', mSi: 'සම්මා වාචා & චිත්තානුපස්සනා', mEn: 'Right Speech & Cittanupassana' },
          { hz: 852, pl: 'Ju',      nSi: '6. ආඥා චක්‍රය (Third Eye)', nEn: '6. Third Eye Chakra (Ajna)', pSi: 'ගුරු · ප්‍රඥාව, අන්තර්ඥානය, නිවැරදි තීරණ & ධර්ම අවබෝධය', pEn: 'Jupiter · Wisdom, intuition, clear decisions & insight', mSi: 'ධම්මානුපස්සනා (අනිත්‍ය-දුක්ඛ-අනාත්ම)', mEn: 'Dhammanupassana (Vipassana Insight)' },
          { hz: 963, pl: 'Ke',      nSi: '7. සහස්‍රාර කිරීට චක්‍රය (Crown)', nEn: '7. Crown Chakra (Sahasrara)', pSi: 'කේතු · පරම ශාන්තිය, අත්හැරීම & නිවන් මඟ', pEn: 'Ketu · Supreme stillness, detachment & liberation', mSi: 'සතර සතිපට්ඨාන සමාධි–විදර්ශනා', mEn: 'Satipatthana Samadhi-Vipassana' }
        ];
        body =
          '<div class="sub">' + T('සෑම චක්‍රයකම ▶ බොත්තම ඔබා අදාළ සංඛ්‍යාතය 100% ඕෆ්ලයින් අසන්න.', 'Tap ▶ on any Chakra to play its pure offline frequency immediately.') + '</div>' +
          chks.map(function (ck) {
            return '<div class="r">' +
              '<div class="kp-drow"><span><b>' + (SI ? ck.nSi : ck.nEn) + '</b></span><button type="button" class="kp-minia" data-playhz="' + ck.hz + '" data-playbin="6">▶ ' + ck.hz + ' Hz</button></div>' +
              '<small>' + (SI ? ck.pSi : ck.pEn) + '<br>☸️ <b>' + T('භාවනාව:', 'Practice:') + '</b> ' + (SI ? ck.mSi : ck.mEn) + '</small>' +
            '</div>';
          }).join('');
      }

      el.innerHTML =
        '<h3>🧘 ' + T('ආධ්‍යාත්මික සහන, ශබ්ද Studio & භාවනා', 'Spiritual Remedies, Sound Studio & Meditation') + '</h3>' +
        '<div class="bar" id="kp-sp-tabs">' +
          '<button type="button" class="' + (spTab === 'rem' ? 'p' : '') + '" data-st="rem">🎯 ' + T('කේන්දර සහන', 'My Remedies') + '</button>' +
          '<button type="button" class="' + (spTab === 'snd' ? 'p' : '') + '" data-st="snd">🎵 ' + T('ශබ්ද Studio', 'Sound Studio') + '</button>' +
          '<button type="button" class="' + (spTab === 'med' ? 'p' : '') + '" data-st="med">☸️ ' + T('සතිපට්ඨාන', 'Meditation') + '</button>' +
          '<button type="button" class="' + (spTab === 'chk' ? 'p' : '') + '" data-st="chk">🌈 ' + T('චක්‍ර 7', '7 Chakras') + '</button>' +
        '</div>' +
        body;

      // Wire top 4 sub-tabs
      E('kp-sp-tabs').onclick = function (e) {
        var b = e.target.closest('button[data-st]');
        if (!b) return;
        spTab = b.dataset.st;
        window.kpSpiritualTab();
      };

      // Wire 1-tap play buttons inside Remedies & 7 Chakras
      $$('button[data-playhz]', el).forEach(function (btn) {
        btn.onclick = function () {
          var hz = +btn.dataset.playhz, bin = +(btn.dataset.playbin || 0);
          kpsPlaySol(hz);
          if (bin) kpsPlayBin(bin);
          spTab = 'snd';
          window.kpSpiritualTab();
          if (window.KPB && window.KPB.mnToast) window.KPB.mnToast('🎵 ' + hz + ' Hz ' + T('ක්‍රියාත්මකයි', 'Playing'));
        };
      });
      $$('button[data-gosp]', el).forEach(function (btn) {
        btn.onclick = function () { spTab = btn.dataset.gosp; window.kpSpiritualTab(); };
      });

      // Wire Sound Studio controls
      if (E('kp-vol')) E('kp-vol').oninput = function () { kpsSetVol(this.value); };
      if (E('kp-stop-all')) E('kp-stop-all').onclick = function () { kpsStopAll(); window.kpSpiritualTab(); };
      if (E('kp-slp-row')) E('kp-slp-row').onclick = function (e) {
        var b = e.target.closest('button[data-slp]'); if (!b) return;
        kpsSetSleep(+b.dataset.slp);
        $$('#kp-slp-row .kp-chip', el).forEach(function (x) { x.classList.toggle('on', x === b); });
      };
      if (E('kp-bin-row')) E('kp-bin-row').onclick = function (e) {
        var b = e.target.closest('button[data-bin]'); if (!b) return;
        kpsPlayBin(+b.dataset.bin);
        window.kpSpiritualTab();
      };
      if (E('kp-nat-row')) E('kp-nat-row').onclick = function (e) {
        var b = e.target.closest('button[data-nat]'); if (!b) return;
        kpsPlayNat(b.dataset.nat);
        window.kpSpiritualTab();
      };
      if (E('kp-hz-grid')) E('kp-hz-grid').onclick = function (e) {
        var b = e.target.closest('button[data-hz]'); if (!b) return;
        kpsPlaySol(+b.dataset.hz);
        window.kpSpiritualTab();
      };

      // Wire Guided Breathing Pacer with LIVE 0.1s Seconds Countdown!
      var BR_PAT = {
        coh: [
          { si: 'ආශ්වාස', en: 'Inhale', s: 5.5, sc: 1.26 },
          { si: 'ප්‍රශ්වාස', en: 'Exhale', s: 5.5, sc: 0.78 }
        ],
        '478': [
          { si: 'ආශ්වාස', en: 'Inhale', s: 4.0, sc: 1.26 },
          { si: 'රඳවාගන්න', en: 'Hold',   s: 7.0, sc: 1.26 },
          { si: 'ප්‍රශ්වාස', en: 'Exhale', s: 8.0, sc: 0.78 }
        ],
        box: [
          { si: 'ආශ්වාස', en: 'Inhale', s: 4.0, sc: 1.26 },
          { si: 'රඳවාගන්න', en: 'Hold',   s: 4.0, sc: 1.26 },
          { si: 'ප්‍රශ්වාස', en: 'Exhale', s: 4.0, sc: 0.78 },
          { si: 'නිසලව',   en: 'Hold',   s: 4.0, sc: 0.78 }
        ]
      };
      if (E('kp-br-modes')) E('kp-br-modes').onclick = function (e) {
        var b = e.target.closest('button[data-bm]'); if (!b) return;
        if (KPS.brIv) { clearInterval(KPS.brIv); KPS.brIv = null; }
        KPS.brRun = false; KPS.brMode = b.dataset.bm; KPS.brCycles = 0; KPS.brStep = 0;
        window.kpSpiritualTab();
      };
      if (E('kp-br-tog')) E('kp-br-tog').onclick = function () {
        if (KPS.brRun) {
          if (KPS.brIv) { clearInterval(KPS.brIv); KPS.brIv = null; }
          KPS.brRun = false;
          window.kpSpiritualTab();
          return;
        }
        KPS.brRun = true; KPS.brStep = 0; KPS.brCycles = 0;
        window.kpSpiritualTab();
        var seq = BR_PAT[KPS.brMode] || BR_PAT.coh;
        function startPhase() {
          var ph = seq[KPS.brStep % seq.length];
          KPS.brPhaseEnd = Date.now() + ph.s * 1000;
          var orb = E('kp-br-orb'), phEl = E('kp-br-ph'), cycEl = E('kp-br-cyc');
          if (orb) {
            orb.style.transition = 'transform ' + ph.s + 's ease-in-out';
            orb.style.transform = 'scale(' + ph.sc + ')';
          }
          if (phEl) phEl.textContent = SI ? ph.si : ph.en;
          if (cycEl) cycEl.textContent = T('වට ගණන: ', 'Cycles: ') + KPS.brCycles;
        }
        startPhase();
        KPS.brIv = setInterval(function () {
          if (!KPS.brRun) { clearInterval(KPS.brIv); KPS.brIv = null; return; }
          var rem = (KPS.brPhaseEnd - Date.now()) / 1000;
          if (rem <= 0) {
            KPS.brStep++;
            if (KPS.brStep % seq.length === 0) KPS.brCycles++;
            startPhase();
            rem = (KPS.brPhaseEnd - Date.now()) / 1000;
          }
          var secEl = E('kp-br-sec');
          if (secEl) secEl.textContent = Math.max(0, rem).toFixed(1) + 's';
        }, 100);
      };

      // Wire Meditation Timer (Singing Bowl Bell)
      if (E('kp-med-mins')) E('kp-med-mins').onclick = function (e) {
        var b = e.target.closest('button[data-mm]'); if (!b) return;
        if (KPS.medRun) { clearInterval(KPS.medIv); KPS.medIv = null; KPS.medRun = false; }
        KPS.medTotal = (+b.dataset.mm) * 60;
        KPS.medRem = KPS.medTotal;
        window.kpSpiritualTab();
      };
      if (E('kp-med-bell')) E('kp-med-bell').onclick = function () { kpsChime(); };
      if (E('kp-med-go')) E('kp-med-go').onclick = function () {
        if (KPS.medRun) {
          clearInterval(KPS.medIv); KPS.medIv = null; KPS.medRun = false;
          window.kpSpiritualTab();
          return;
        }
        KPS.medRem = KPS.medTotal; KPS.medRun = true;
        kpsChime();
        window.kpSpiritualTab();
        KPS.medIv = setInterval(function () {
          KPS.medRem--;
          if (KPS.medRem <= 0) {
            clearInterval(KPS.medIv); KPS.medIv = null; KPS.medRun = false;
            kpsChime();
            if (window.KPB && window.KPB.mnToast) window.KPB.mnToast('☸️ ' + T('සාධු! භාවනා කාලය සාර්ථකව අවසන් විය.', 'Sadhu! Meditation session complete.'));
            if (E('t26') && E('t26').style.display === 'block') window.kpSpiritualTab();
          } else {
            updateSndLabels();
          }
        }, 1000);
      };
    };

    /* ---------- WhatsApp Share Card ---------- */
    function share() {
      var go = function () { ok(drawShare); };
      if (document.fonts && document.fonts.load) document.fonts.load('700 40px "Noto Sans Sinhala"').then(go, go);
      else go();
    }
    function drawShare() {
      var W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      var x = cv.getContext('2d'), F = '"Noto Sans Sinhala","Inter",system-ui,sans-serif';
      var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#060d14'); g.addColorStop(1, '#0c2436');
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      var d = S.day || dayScore(today()), nm = (E('nm') && E('nm').value) || '', lg = Math.floor(c.cs[0] / 30), mn = Math.floor(c.pl.Mo / 30), nk = Math.floor(c.pl.Mo / (40 / 3)) % 27;
      function tx(s, px, py, sz, col, w, al, mx) {
        x.font = (w || 600) + ' ' + sz + 'px ' + F; x.fillStyle = col; x.textAlign = al || 'left'; s = String(s);
        if (mx) while (x.measureText(s).width > mx && s.length > 2) s = s.slice(0, -2);
        x.fillText(s, px, py);
      }
      tx('✦ KP ASTROLOGY AI PRO', 60, 100, 44, '#38bdf8', 800);
      tx(today() + (nm ? '  ·  ' + nm : ''), 60, 158, 30, '#82a4b8', 500, 'left', 960);
      var cx = 215, cy = 380, r = 118, p = d.avg, col = p >= 55 ? '#10b981' : p >= 40 ? '#38bdf8' : '#f43f5e';
      x.lineWidth = 22; x.lineCap = 'round'; x.strokeStyle = 'rgba(125,211,252,0.18)'; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.stroke();
      x.strokeStyle = col; x.beginPath(); x.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p / 100); x.stroke();
      tx(p + '%', cx, cy + 22, 62, '#eef7fb', 700, 'center');
      tx(T('අද ලකුණු', 'TODAY'), cx, cy + r + 58, 28, '#82a4b8', 600, 'center');
      var ds = ok(curDashaObj) || { names: [] };
      var rows = [
        [T('ලග්නය', 'Lagna'), SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°'],
        [T('චන්ද්‍ර රාශිය', 'Moon'), SGN[mn]],
        [T('නැකත', 'Nakshatra'), NKN[nk]],
        [T('දශාව', 'Dasha'), ds.names.join(' - ') || '—']
      ];
      rows.forEach(function (r2, i) { var y = 290 + i * 58; tx(r2[0], 440, y, 26, '#82a4b8', 500); tx(r2[1], 650, y, 30, '#eef7fb', 700, 'left', 370); });
      tx(T('අද ප්‍රබල ක්ෂේත්‍ර', 'TOP FIELDS TODAY'), 60, 640, 34, '#38bdf8', 800);
      var top = d.r.map(function (v, i) { return [v, i]; }).sort(function (a, b) { return b[0] - a[0]; }).slice(0, 6);
      top.forEach(function (t, i) {
        var y = 705 + i * 86;
        tx(TOP[t[1]][0], 60, y, 30, '#eef7fb', 500, 'left', 550);
        x.fillStyle = 'rgba(125,211,252,0.16)'; x.fillRect(640, y - 24, 240, 16);
        x.fillStyle = t[0] >= 55 ? '#10b981' : t[0] >= 40 ? '#38bdf8' : '#f43f5e';
        x.fillRect(640, y - 24, 240 * t[0] / 100, 16);
        tx(t[0] + '%', 1020, y, 28, '#eef7fb', 700, 'right');
      });
      tx(T('ක්‍රිෂ්ණමූර්ති පද්ධතිය (KP) අනුව ගණනය කරන ලදී', 'Calculated with Krishnamurti Paddhati (KP)'), W / 2, H - 48, 24, '#648599', 500, 'center');
      cv.toBlob(function (b) {
        if (!b) return;
        var f; try { f = new File([b], 'kp-ai-pro-forecast.png', { type: 'image/png' }); } catch (e) {}
        var dl = function () {
          var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'kp-ai-pro-forecast.png';
          document.body.appendChild(a); a.click(); a.remove();
          mnToast(T('පින්තූරය සුරැකිණි — WhatsApp එකෙන් යවන්න', 'Image saved — share on WhatsApp'));
        };
        if (f && navigator.canShare && navigator.canShare({ files: [f] })) {
          navigator.share({ files: [f], title: 'KP Astrology AI Pro' }).catch(function (e) { if (!e || e.name !== 'AbortError') dl(); });
        } else dl();
      }, 'image/png');
    }

    /* ---------- Fixed Bottom Icon Bar (Like Classic KP App — 6 Crisp Icons) ---------- */
    function buildBar() {
      var b = document.createElement('nav'); b.id = 'kbar';
      var it = [
        ['🏠', T('මුල්', 'Home'), '__home'],
        ['🪐', T('ලග්න', 'Lagna'), 't1'],
        ['📐', T('භාව', 'Cusps'), 't2'],
        ['⭐', 'Signif.', 't3'],
        ['⏳', T('පලාපල', 'Forecast'), 't5'],
        ['🤖', 'AI', 't18']
      ];
      b.innerHTML = it.map(function (x) { return '<button data-t="' + x[2] + '"><i>' + x[0] + '</i>' + x[1] + '</button>'; }).join('');
      b.onclick = function (e) {
        var q = e.target.closest('button'); if (!q) return;
        var t = q.dataset.t;
        if (t === '__home') { goScr('home'); return; }
        if (window.KPLic && !window.KPLic.allow(t, '')) return;
        if (!c) { goScr('form'); return; }
        nvB(t, '');
        openPage(t);
      };
      document.body.appendChild(b);
    }
    function barState(t) {
      $$('#kbar button').forEach(function (b) { b.classList.toggle('on', !!b.dataset.t && b.dataset.t === t); });
    }

    /* ---------- Clean Vertical "Choose Sections" Drawer (#dw) ---------- */
    var ICO = { t1:'🪐',t2:'📐',t3:'⭐',t4:'⏳',t9:'🕰️',t5:'🔮',t12:'📊',t6:'🌍',t7:'🍀',t15:'💼',t8:'💍',t10:'📅',t11:'📜',t16:'🔱',t13:'🎯',t18:'🤖',t19:'💎',t20:'📐',t21:'⏱',t22:'📚',t23:'📋',t24:'🏠',t25:'🩺',t26:'🧘',pdf:'📄',kpPlus:'🧰' };
    function tiles() {
      var pn = E('dw') && E('dw').querySelector('.pn');
      if (!pn) return;
      // Add top "🏠 මුල් පිටුව" button inside drawer once
      if (!pn.querySelector('.dw-home-btn')) {
        var ph = pn.querySelector('.ph');
        var hb = document.createElement('button');
        hb.type = 'button'; hb.className = 'dw-home-btn';
        hb.innerHTML = '<span class="ti">🏠</span><span>' + T('මුල් පිටුව (Home)', 'Home Dashboard') + '</span>';
        hb.onclick = function () { mnC(); goScr('home'); };
        if (ph) ph.insertAdjacentElement('afterend', hb);
      }
      $$('button[onclick^="mnB"]', pn).forEach(function (b) {
        if (b.querySelector('.ti')) return;
        var m = /mnB\('([^']*)','([^']*)'\)/.exec(b.getAttribute('onclick') || '');
        var k = m && (m[1] || m[2]), tx = b.textContent.trim().replace(/\s*🔒\s*$/, '');
        var em = /^(\p{Extended_Pictographic}\uFE0F?)\s*/u.exec(tx), ic = em ? em[1] : (ICO[k] || '✦');
        if (em) tx = tx.slice(em[0].length);
        b.innerHTML = '<span class="ti">' + ic + '</span><span>' + tx + '</span>';
      });
    }

    /* ---------- Tables, Charts (South/North + Zoom), 42-Day Heatmap, Chips, Wizard ---------- */
    var RX = /^(AS|Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)(\(R\))?$/;
    function tables(root) {
      if (!root) return;
      $$('table', root).forEach(function (t) {
        if (!t.parentNode.classList.contains('tw')) {
          var w = document.createElement('div'); w.className = 'tw'; t.parentNode.insertBefore(w, t); w.appendChild(t);
        }
        if (t.dataset.kDone === String(t.rows.length)) return;
        t.dataset.kDone = String(t.rows.length);
        $$('td', t).forEach(function (td) {
          if (td.dataset.k) return; td.dataset.k = 1;
          var m = RX.exec(td.textContent.trim());
          if (m && td.children.length === 0) td.innerHTML = '<span class="pc pc-' + m[1] + '">' + m[1] + (m[2] ? '<sup>R</sup>' : '') + '</span>';
        });
      });
    }

    var SPOS = { 11:[0,0],0:[1,0],1:[2,0],2:[3,0],10:[0,1],3:[3,1],9:[0,2],4:[3,2],8:[0,3],7:[1,3],6:[2,3],5:[3,3] };
    function paint(sv) {
      $$('text', sv).forEach(function (t) {
        var m = /^(Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)/.exec(t.textContent);
        if (m && t.getAttribute('fill') !== 'var(--hn)') t.style.fill = PC[m[1]];
      });
    }
    function south() {
      var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 400 400'); s.setAttribute('class', 'ks');
      var lg = Math.floor(c.cs[0] / 30), by = {}, h = '<g fill="none" stroke="rgba(125,211,252,0.34)">';
      Object.keys(c.pl).forEach(function (p) { var sg = Math.floor(c.pl[p] / 30); (by[sg] = by[sg] || []).push([p, Math.floor(c.pl[p] % 30), !!(c.rt[p] || p == 'Ra' || p == 'Ke')]); });
      for (var sg = 0; sg < 12; sg++) { var q = SPOS[sg]; h += '<rect x="' + (q[0] * 100) + '" y="' + (q[1] * 100) + '" width="100" height="100"' + (sg == lg ? ' stroke="#38bdf8" stroke-width="2.8"' : '') + '/>'; }
      h += '</g>';
      for (sg = 0; sg < 12; sg++) {
        q = SPOS[sg]; var x0 = q[0] * 100 + 7, y0 = q[1] * 100;
        h += '<text x="' + (x0 + 86) + '" y="' + (y0 + 14) + '" text-anchor="end" fill="#82a4b8" style="font-size:9px;font-weight:500">' + SGN[sg].slice(0, 3) + '</text>';
        var L = (sg == lg ? [['As', null, 0]] : []).concat(by[sg] || []);
        L.forEach(function (e, i) {
          h += '<text x="' + x0 + '" y="' + (y0 + 30 + i * 14) + '" fill="' + (e[0] == 'As' ? '#38bdf8' : (PC[e[0]] || '#eef7fb')) + '" style="font-size:12px;font-weight:700">' + e[0] + (e[2] ? '*' : '') + (e[1] != null && e[0] != 'As' ? ' ' + e[1] : '') + '</text>';
        });
      }
      h += '<text x="200" y="196" text-anchor="middle" fill="#38bdf8" style="font-size:14px;font-weight:800">' + T('රාශි සටහන', 'Rasi Chart') + '</text>';
      h += '<text x="200" y="216" text-anchor="middle" fill="#82a4b8" style="font-size:11px;font-weight:500">' + SGN[lg] + ' ' + Math.floor(c.cs[0] % 30) + '°</text>';
      s.innerHTML = h; return s;
    }
    function charts() {
      var t1 = E('t1');
      if (t1 && c) {
        var sv = t1.querySelector('svg:not(.ks)');
        if (sv && !t1.querySelector('.kct')) {
          var bar = document.createElement('div'); bar.className = 'kct';
          bar.innerHTML = '<button data-s="S">▦ South (KP)</button><button data-s="N">◇ North</button>';
          sv.parentNode.insertBefore(bar, sv); var so = south(); sv.parentNode.insertBefore(so, sv.nextSibling);
          var ap = function (m) { sv.style.display = m == 'S' ? 'none' : ''; so.style.display = m == 'S' ? '' : 'none'; $$('button', bar).forEach(function (b) { b.className = b.dataset.s == m ? 'p' : ''; }); };
          bar.onclick = function (e) { var b = e.target.closest('button'); if (!b) return; try { localStorage.setItem('kpCs', b.dataset.s); } catch (x) {} ap(b.dataset.s); };
          ap((function () { try { return localStorage.getItem('kpCs') || 'S'; } catch (x) { return 'S'; } })());
        }
      }
      $$('.tab svg').forEach(function (sv) {
        if (sv.dataset.k || sv.getAttribute('viewBox') !== '0 0 400 400') return;
        sv.dataset.k = 1; paint(sv);
        sv.addEventListener('click', function () {
          var z = E('czm');
          if (!z) { z = document.createElement('div'); z.id = 'czm'; z.onclick = function () { z.classList.remove('on'); }; document.body.appendChild(z); }
          z.innerHTML = '<i>✕</i>'; var cl = sv.cloneNode(true); cl.style.display = ''; cl.removeAttribute('class'); z.appendChild(cl); z.classList.add('on');
        });
      });
    }

    var HM = { c: null, d: {}, busy: 0 };
    function days42() { var n = new Date(), a = []; for (var i = 0; i < 42; i++) a.push(new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate() + i)).toISOString().slice(0, 10)); return a; }
    function heatRender() {
      var box = E('khm'); if (!box) return;
      var ds = days42(), v = ds.map(function (x) { return HM.d[x]; }).filter(function (z) { return z != null; });
      var mn = Math.min.apply(0, v), mx = Math.max.apply(0, v), first = new Date(ds[0] + 'T00:00:00Z').getUTCDay();
      var h = '<h3>' + T('දින 42 සුබ-අසුබ සිතියම', '42-Day KP Heatmap') + '</h3><div class="khw">' + WD.map(function (w) { return '<i>' + w + '</i>'; }).join('');
      for (var i = 0; i < first; i++) h += '<b class="e"></b>';
      ds.forEach(function (x, i) {
        var s = HM.d[x]; if (s == null) { h += '<b class="sk"></b>'; return; }
        var t = mx > mn ? (s - mn) / (mx - mn) : 0.5;
        h += '<b class="' + (i == 0 ? 'td' : '') + '" data-d="' + x + '" data-v="' + s + '" style="background:hsl(' + Math.round(4 + 145 * t) + ' 65% var(--kl))">' + (+x.slice(8)) + '<small>' + s + '%</small></b>';
      });
      box.innerHTML = h + '</div><div class="khl"><span>' + T('අඩු', 'Low') + '</span><i></i><span>' + T('ඉහළ', 'High') + '</span></div>';
    }
    function heat() {
      var t7 = E('t7'); if (!t7 || t7.style.display !== 'block' || !c) return;
      if (!E('khm')) {
        var b = document.createElement('div'); b.id = 'khm'; b.className = 'card';
        b.onclick = function (e) { var q = e.target.closest('b[data-d]'); if (q) mnToast(q.dataset.d + ' — ' + q.dataset.v + '%'); };
        t7.insertBefore(b, t7.firstChild); heatRender();
      }
      if (HM.c !== c) HM = { c: c, d: {}, busy: 0 };
      var h = HM; if (h.busy) return;
      var todo = days42().filter(function (x) { return h.d[x] == null; }); if (!todo.length) return;
      h.busy = 1;
      var sched = window.requestIdleCallback ? function (fn) { window.requestIdleCallback(fn, { timeout: 60 }); } : function (fn) { requestAnimationFrame(fn); };
      (function step() {
        if (h.c !== c) return;
        if (scrolling) { setTimeout(step, 90); return; }
        var x = todo.shift();
        if (x != null) {
          h.d[x] = ok(function () { return dayScore(x).avg; });
          if (h.d[x] == null) h.d[x] = 50;
          if (!todo.length || todo.length % 4 === 0) heatRender();
        }
        if (todo.length) sched(step); else { heatRender(); h.busy = 0; }
      })();
    }

    function chips() {
      var box = E('pfc');
      if (!box) {
        box = document.createElement('div'); box.id = 'pfc';
        var anchor = E('kp-scr-bar') || E('tp');
        anchor.insertAdjacentElement('afterend', box);
      }
      var a = []; try { a = pg(); } catch (e) {}
      box.innerHTML = a.length ? '<div class="kpl">' + a.map(function (x, i) { return '<button class="kc" onclick="pfl(' + i + ')">👤 ' + esc(x.nm || '—') + '</button>'; }).join('') + '</div>' : '';
    }

    function wizard() {
      var card = $$('body > .card').find(function (el) { return $$('.sec', el).length >= 3; });
      if (!card || card.dataset.w) return;
      card.dataset.w = 1;
      card.classList.add('kp-form-card');
      var P3 = [0, 1, 2].map(function () { var d = document.createElement('div'); d.className = 'kstep'; return d; }), cur = 0, seen = 0;
      Array.prototype.slice.call(card.childNodes).forEach(function (n) {
        if (n.nodeType == 1 && n.classList.contains('sec')) cur = Math.min(seen++, 2);
        P3[cur].appendChild(n);
      });
      var nm = [T('පුද්ගල', 'Person'), T('දිනය/වේලාව', 'Date & Time'), T('ස්ථානය', 'Place')], pr = document.createElement('div');
      pr.className = 'kprog';
      pr.innerHTML = nm.map(function (n, i) { return '<span data-i="' + i + '"><b>' + (i + 1) + '</b>' + n + '</span>'; }).join('');
      card.appendChild(pr);
      P3.forEach(function (p, i) {
        var k = document.createElement('div'); k.className = 'kn';
        if (i > 0) k.innerHTML += '<button type="button" data-g="' + (i - 1) + '">⬅ ' + T('ආපසු', 'Back') + '</button>';
        if (i < 2) k.innerHTML += '<button type="button" class="p" data-g="' + (i + 1) + '">' + T('ඊළඟ', 'Next') + ' ➜</button>';
        p.appendChild(k); card.appendChild(p);
      });
      function set(n) {
        P3.forEach(function (p, i) { p.classList.toggle('on', i == n); });
        $$('span', pr).forEach(function (s, i) { s.className = i == n ? 'on' : i < n ? 'done' : ''; });
      }
      card.addEventListener('click', function (e) {
        var g = e.target.closest('[data-g]'), s = e.target.closest('.kprog span');
        if (g) set(+g.dataset.g); else if (s) set(+s.dataset.i);
      });
      set(0);
    }

    function skeleton() {
      var sk = document.createElement('div'); sk.id = 'ksk'; sk.innerHTML = '<div class="ksb"></div><div class="ksb"></div><div class="ksb"></div>'; document.body.appendChild(sk);
      document.addEventListener('click', function (e) {
        var b = e.target.closest && e.target.closest('#b1'); if (!b || b.dataset.go) return;
        e.stopImmediatePropagation(); e.preventDefault(); sk.classList.add('on');
        requestAnimationFrame(function () { setTimeout(function () { b.dataset.go = 1; try { b.click(); } finally { delete b.dataset.go; sk.classList.remove('on'); } }, 30); });
      }, true);
    }

    /* ---------- 120Hz Passive Scroll Guard & Lightweight Observer ---------- */
    var ob, tm, curTab = null, activeEl = null, pfSig = '', scrolling = false, scTm = null;
    window.addEventListener('scroll', function () {
      scrolling = true; clearTimeout(scTm); scTm = setTimeout(function () { scrolling = false; }, 110);
    }, { passive: true });

    function sync() {
      if (c && S.c !== c) { S.c = c; ok(buildSum); }
      var el0 = null, tabs = document.getElementsByClassName('tab');
      for (var i = 0; i < tabs.length; i++) { if (tabs[i].style.display === 'block') { el0 = tabs[i]; break; } }
      activeEl = el0;
      var t = el0 ? el0.id : '';
      if (t !== curTab) {
        curTab = t; barState(t);
        if (el0) { el0.classList.remove('kfade'); requestAnimationFrame(function () { el0.classList.add('kfade'); }); }
      }
    }
    function pfSync() {
      if (S.scr !== 'form') return;
      var s = ''; try { s = JSON.stringify(pg().map(function (x) { return x.nm; })); } catch (e) {}
      if (s !== pfSig) { pfSig = s; chips(); }
    }
    var OBC = { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] };
    function tick() {
      if (scrolling) { clearTimeout(tm); tm = setTimeout(tick, 120); return; }
      if (ob) ob.disconnect();
      ok(sync);
      var dw = E('dw'); if (dw && !dw.querySelector('.ti')) ok(tiles);
      ok(pfSync);
      if (activeEl && S.scr === 'page') { ok(function () { tables(activeEl); }); ok(charts); }
      if (curTab === 't7' && S.scr === 'page') ok(heat);
      if (ob) ob.observe(document.body, OBC);
    }

    if (window.KPDesktop && window.KPDesktop.isDesktop) {
      document.documentElement.classList.add('kp-pc');
    }
    function ensureDesktopSidebar() {
      if (window.innerWidth >= 960 && !E('dw') && typeof window.mnR === 'function') {
        try { window.mnR(''); } catch (e) {}
      }
      if (E('dw') && !E('dw').querySelector('.ti')) ok(tiles);
    }
    window.addEventListener('resize', function () { ok(ensureDesktopSidebar); });
    // Professional Desktop Keyboard Shortcuts (Ctrl+N New Chart, Ctrl+H Horary, Ctrl+P A4 PDF, Esc Close Modals)
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') {
        ['kp-pdf-modal', 'kp-lic-modal', 'kp-eng-modal'].forEach(function (id) {
          var m = E(id); if (m) m.classList.remove('on');
        });
        return;
      }
      if (!(ev.ctrlKey || ev.metaKey)) return;
      var k = String(ev.key || '').toLowerCase();
      if (k === 'n') { ev.preventDefault(); goScr('form'); }
      else if (k === 'h') { ev.preventDefault(); if (window.KPLic && !window.KPLic.allow('t13', '')) return; goScr('horary'); }
      else if (k === 'p' && c) {
        ev.preventDefault();
        if (window.KPLic && !window.KPLic.allow('', 'pdf')) return;
        if (typeof window.pdf === 'function') window.pdf();
      }
    });
    ok(buildScreens); ok(buildBar); ok(chips); ok(wizard); ok(skeleton);
    ok(ensureDesktopSidebar);
    goScr('home', true);

    // Live Home clock (30s interval, zero DOM churn)
    S.clockTimer = setInterval(function () {
      var ck = E('kw-clk');
      if (!ck || S.scr !== 'home') return;
      var nt = fmtLiveTime().clock;
      if (ck.textContent !== nt) {
        if (ob) ob.disconnect();
        ck.textContent = nt;
        if (ob) ob.observe(document.body, OBC);
      }
    }, 30000);

    document.addEventListener('click', function (e) {
      if (e.target && e.target.closest && e.target.closest('.hbt')) {
        requestAnimationFrame(function () { var dw = E('dw'); if (dw) ok(tiles); });
      }
    });

    // Preserve active chart & screen across SI <-> EN toggle
    var RSK = ['g','nm','dt','tm','pl','la','lo','tz','ay','ao'];
    document.addEventListener('click', function (e) {
      if (!(e.target.closest && e.target.closest('#lgb')) || !c) return;
      var o = { t: curTab, scr: S.scr }; RSK.forEach(function (k) { if (E(k)) o[k] = E(k).value; });
      try { sessionStorage.setItem('kpRs', JSON.stringify(o)); } catch (x) {}
    }, true);
    ok(function () {
      var r = null; try { r = JSON.parse(sessionStorage.getItem('kpRs') || 'null'); sessionStorage.removeItem('kpRs'); } catch (x) {}
      if (!r) return;
      RSK.forEach(function (k) { if (E(k) && r[k] != null) E(k).value = r[k]; });
      ['la', 'lo'].forEach(function (k) { if (E(k)) E(k).dispatchEvent(new Event('input')); });
      setTimeout(function () {
        if (E('b1')) E('b1').click();
        var n = 0, iv = setInterval(function () {
          if (c || ++n > 60) {
            clearInterval(iv);
            if (c) ok(function () {
              if (r.scr === 'page' && r.t) { nvB(r.t, ''); openPage(r.t); }
              else if (r.scr && r.scr !== 'home') goScr(r.scr);
            });
          }
        }, 100);
      }, 60);
    });

    ob = new MutationObserver(function (muts) {
      var real = false;
      for (var i = 0; i < muts.length; i++) {
        var tg = muts[i].target;
        if (tg && tg.id === 'kw-clk') continue;
        real = true; break;
      }
      if (!real) return;
      clearTimeout(tm); tm = setTimeout(tick, 80);
    });
    tick();
  }
})();
